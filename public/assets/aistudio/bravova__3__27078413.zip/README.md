# BravoVa — Supermercados Bravo & El Arca Petshop (Android / Jetpack Compose)

Aplicación nativa Android desarrollada en **Kotlin** y **Jetpack Compose (Material 3)** para **Supermercados Bravo** y **El Arca Petshop**, con asistente inteligente **Brav IA**, **Tarjeta Bravísima** digital y seguimiento de entregas en vivo.

## Arquitectura y Módulos (`app/src/main/java/com/example/`)

- `MainActivity.kt` — Punto de entrada, configuración de pantalla a 120 Hz, navegación con físicas elásticas (`spring`) e iluminación ambiental para el sistema *Liquid Glass* (`Haze`).
- `model/BravoModels.kt` — Modelos de datos del catálogo, carrito, órdenes, telemetría de entrega y perfiles nutricionales.
- `data/` — Catálogos oficiales de Supermercados Bravo (`BravoCatalogData.kt`) y El Arca Petshop (`ArcaCatalogData.kt`), base de datos local con Room (`BravoDatabase.kt`) y sincronización en vivo con Firebase Firestore (`BravoFirestoreRepository.kt`).
- `viewmodel/BravoViewModel.kt` — Estado reactivo (`StateFlow`), planificación de presupuesto, listas de compras, simulación de ruta en Santo Domingo e integración con Gemini.
- `ui/components/` — Componentes translúcidos (`CommonComponents.kt`), recorte inteligente de fondo de productos (`StudioCutoutCenterTransformation`), tarjetas interactivas (`VerticalProductCard`), dock inferior (`TranslucentBottomDock`), escáner `CameraX` (`BarcodeScannerModal.kt`) y feedback háptico/acústico (`HapticFeedbackManager.kt`).
- `ui/screens/` — Pantallas de Inicio, Catálogo, Categorías, Detalle de Producto (`HomeAndCatalogScreens.kt`), Carrito, Tarjeta Bravísima, Seguimiento en Vivo (`BravisimaAndCartScreens.kt`), Chat con Brav IA y Cuenta (`BravIaAndAccountScreens.kt`).

## Ejecución en Android Studio

1. Abre **Android Studio** y selecciona **Open** en la carpeta raíz del proyecto.
2. Espera a que Gradle sincronice las dependencias.
3. Crea un archivo `.env` en la raíz (usando `.env.example` como guía) con tu `GEMINI_API_KEY`.
4. Ejecuta el módulo `app` en tu dispositivo Android o emulador.
