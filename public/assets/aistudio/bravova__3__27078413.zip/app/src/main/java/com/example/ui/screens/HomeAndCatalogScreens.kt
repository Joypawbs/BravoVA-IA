package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.text.style.TextDecoration
import com.example.model.CatalogSection
import com.example.model.DailyRotatingOffer
import com.example.model.Product
import com.example.model.StoreMode
import com.example.model.nutritionProfile
import com.example.ui.components.AnimatedPurchaseButton
import com.example.ui.components.BravoArcaHeaderSwitcher
import com.example.ui.components.BravoArcaSelectorMenuOverlay
import com.example.ui.components.BravoUnderline
import com.example.ui.components.BravoUnifiedIcon
import com.example.ui.components.DiagonalMetadataStrip
import com.example.ui.components.FloatingHeaderCapsule
import com.example.ui.components.HapticFeedbackManager
import com.example.ui.components.HapticStyle
import com.example.ui.components.LocalTranslucentHazeState
import com.example.ui.components.PredictiveCatalogSearchBar
import com.example.ui.components.ProductArtworkView
import com.example.ui.components.SectionLineIcon
import com.example.ui.components.TranslucentCard
import com.example.ui.components.VerticalProductCard
import com.example.ui.components.performCrispHaptic
import com.example.ui.components.translucentBackdropEffect
import com.example.ui.components.translucentBackdropSource
import com.example.ui.theme.ArcaTeal
import com.example.ui.theme.PlusJakartaSans
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale

private fun formatCurrency(amount: Int): String {
    return NumberFormat.getNumberInstance(Locale.US).format(amount)
}

private fun buildProductTrustDescription(product: Product): String {
    val cat = product.category.lowercase()
    return when {
        cat.contains("embutido") || product.artType == "salami" ->
            "Embutido seleccionado con control continuo de cadena de frío (0°C a 4°C). Elaborado bajo estándares de calidad certificada con textura firme, curado uniforme y empaque sellado que preserva todo su sabor tradicional dominicano."
        cat.contains("carne") || cat.contains("pescado") ->
            "Corte fresco supervisado diariamente en nuestras cámaras refrigeradas. Seleccionado por expertos carniceros de Bravo para garantizar suavidad, frescura e higiene total desde la sucursal hasta tu cocina."
        cat.contains("fruta") || cat.contains("vegetal") ->
            "Cosecha fresca recibida directamente de productores locales dominicanos cada mañana. Clasificado a mano para asegurar el punto óptimo de maduración, firmeza y nutrientes naturales."
        cat.contains("lácteo") || cat.contains("lacteo") || cat.contains("huevo") ->
            "Producto refrigerado de rotación diaria con garantía de frescura Bravo. Almacenado a temperatura controlada para conservar intactas sus propiedades nutricionales y sabor."
        cat.contains("panadería") || cat.contains("panaderia") || cat.contains("repostería") ->
            "Horneado diariamente con ingredientes seleccionados. Textura suave y aroma fresco garantizado en cada empaque para el desayuno o la cena familiar."
        cat.contains("limpieza") || cat.contains("hogar") ->
            "Fórmula de alto rendimiento probada para la higiene profunda del hogar. Máximo poder desinfectante y ahorro garantizado por unidad."
        cat.contains("alimento") || cat.contains("mascota") || cat.contains("húmedo") || cat.contains("farmacia") ->
            "Nutrición y cuidado respaldado por especialistas de El Arca Petshop. Ingredientes balanceados con vitaminas y minerales esenciales para la vitalidad, digestión y pelaje saludable de tu mascota."
        else ->
            "Producto con garantía de calidad y frescura Supermercados Bravo («Los expertos en vender barato»). Lote verificado en sucursal con disponibilidad inmediata para entrega express."
    }
}

@Composable
fun HomeScreen(
    storeMode: StoreMode,
    darkMode: Boolean,
    sections: List<CatalogSection>,
    allProducts: List<Product>,
    searchQuery: String,
    cartQtyProvider: (String) -> Int,
    isFavoriteProvider: (String) -> Boolean = { false },
    onToggleFavorite: ((String) -> Unit)? = null,
    isOfflineMode: Boolean = false,
    isGuestMode: Boolean = false,
    cacheStatusLabel: String = "Catálogo oficial al día",
    areMenusVisible: Boolean = true,
    dailyRotatingOffers: List<DailyRotatingOffer> = emptyList(),
    onRotateOfferDay: (Int) -> Unit = {},
    onTriggerDailyOfferPush: () -> Unit = {},
    onSearchQueryChange: (String) -> Unit,
    onSelectStoreMode: (StoreMode) -> Unit,
    onOpenScanner: () -> Unit,
    onNavigateToBravIa: (String?) -> Unit,
    onNavigateToDelivery: () -> Unit,
    onOpenMyLists: () -> Unit = {},
    onOpenCategory: (String) -> Unit,
    onOpenProduct: (String) -> Unit,
    onChangeQty: (String, Int) -> Unit
) {
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary

    var localSearchInput by rememberSaveable { mutableStateOf(searchQuery) }
    var debouncedQuery by rememberSaveable { mutableStateOf(searchQuery) }
    var showMiniSearchPreview by remember { mutableStateOf(false) }

    val productsByCategory = remember(allProducts) {
        allProducts.groupBy { it.category }
    }

    LaunchedEffect(searchQuery) {
        if (searchQuery != localSearchInput && searchQuery.isEmpty()) {
            localSearchInput = ""
            debouncedQuery = ""
            showMiniSearchPreview = false
        }
    }

    LaunchedEffect(localSearchInput) {
        if (localSearchInput.isBlank()) {
            debouncedQuery = ""
            onSearchQueryChange("")
            showMiniSearchPreview = false
        } else {
            delay(300L)
            debouncedQuery = localSearchInput.trim()
            onSearchQueryChange(debouncedQuery)
            showMiniSearchPreview = true
        }
    }

    val filteredProducts = remember(debouncedQuery, allProducts) {
        val q = debouncedQuery.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else allProducts.filter { p ->
            p.name.lowercase().contains(q) ||
                p.category.lowercase().contains(q) ||
                p.badge.lowercase().contains(q)
        }
    }

    val searchRows = remember(filteredProducts) {
        filteredProducts.chunked(3)
    }

    val miniSearchSuggestions = remember(isArca) {
        if (isArca) {
            listOf("Alimento", "Salmón", "Arena", "Snacks", "Antipulgas")
        } else {
            listOf("Salami", "Arroz", "Plátano", "Queso", "Leche", "Papel")
        }
    }

    val hazeState = LocalTranslucentHazeState.current
    val storeMenuHazeState = rememberHazeState(blurEnabled = true)
    var isStoreMenuExpanded by remember { mutableStateOf(false) }
    val showTopHeader = areMenusVisible

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(
                    hazeState = storeMenuHazeState,
                    zIndex = 0f,
                    enabled = isStoreMenuExpanded && showTopHeader
                )
        ) {
            AnimatedVisibility(
                visible = showTopHeader,
                enter = expandVertically(animationSpec = tween(220)) + fadeIn(animationSpec = tween(180)),
                exit = shrinkVertically(animationSpec = tween(220)) + fadeOut(animationSpec = tween(160)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BravoArcaHeaderSwitcher(
                            activeStore = storeMode,
                            darkMode = darkMode,
                            onSelectStore = onSelectStoreMode,
                            expanded = isStoreMenuExpanded,
                            onExpandedChange = { isStoreMenuExpanded = it }
                        )

                    Surface(
                        onClick = {
                            HapticFeedbackManager.onNavigationClick(view)
                            onNavigateToDelivery()
                        },
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFF059669).copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Color(0xFF059669).copy(alpha = 0.35f)),
                        modifier = Modifier.testTag("home_delivery_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            BravoUnifiedIcon(
                                iconKey = "delivery",
                                tint = Color(0xFF059669),
                                size = 15.dp
                            )
                            Text(
                                text = "En ruta",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = Color(0xFF059669),
                                maxLines = 1
                            )
                        }
                    }
                }

                PredictiveCatalogSearchBar(
                    query = localSearchInput,
                    onQueryChange = { newText ->
                        localSearchInput = newText
                    },
                    catalogProducts = allProducts,
                    onSelectPredictedProduct = { prod ->
                        localSearchInput = prod.name
                        debouncedQuery = prod.name
                        onSearchQueryChange(prod.name)
                    },
                    placeholderText = if (isArca) "Buscar en El Arca (ej. croquetas, arena, snacks)..." else "Buscar en Bravo (ej. salami, arroz, leche)...",
                    darkMode = darkMode,
                    isArca = isArca,
                    testTag = "home_search_input",
                    trailingActionContent = {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onOpenScanner()
                                }
                                .testTag("home_scanner_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Escanear código de barras",
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .translucentBackdropSource(hazeState, zIndex = 1f)
                .testTag("home_screen_list"),
            contentPadding = PaddingValues(top = 4.dp, bottom = 132.dp)
        ) {
            if (debouncedQuery.isNotEmpty()) {
                item(key = "search_header", contentType = "header") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "Resultados para \"$debouncedQuery\"",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        BravoUnderline(isArca = isArca)
                    }
                }

                if (filteredProducts.isEmpty()) {
                    item(key = "search_empty", contentType = "empty") {
                        TranslucentCard(
                            darkMode = darkMode,
                            isArca = isArca,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Sin resultados para \"$debouncedQuery\"",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Prueba otra palabra clave o consulta opciones disponibles en el catálogo con Brav IA.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                AnimatedPurchaseButton(
                                    text = "Consultar sustitutos en Brav IA",
                                    icon = Icons.Default.AutoAwesome,
                                    primaryColor = primaryColor,
                                    onClick = { onNavigateToBravIa("¿Qué producto del catálogo me recomiendas como alternativa a $debouncedQuery?") }
                                )
                            }
                        }
                    }
                } else {
                    items(
                        items = searchRows,
                        key = { row -> row.first().sku },
                        contentType = { "search_row" }
                    ) { rowItems ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { prod ->
                                Box(modifier = Modifier.weight(1f)) {
                                    VerticalProductCard(
                                        product = prod,
                                        qtyInCart = cartQtyProvider(prod.sku),
                                        isArca = isArca,
                                        darkMode = darkMode,
                                        onOpenDetail = { onOpenProduct(prod.sku) },
                                        onIncrement = { onChangeQty(prod.sku, 1) },
                                        onDecrement = { onChangeQty(prod.sku, -1) },
                                        isFavorite = isFavoriteProvider(prod.sku),
                                        onToggleFavorite = onToggleFavorite?.let { fn -> { fn(prod.sku) } },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            repeat(3 - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            } else {
                items(
                    items = sections,
                    key = { it.id },
                    contentType = { "section_carousel" }
                ) { section ->
                    val sectionProducts = productsByCategory[section.name].orEmpty()
                    if (sectionProducts.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 8.dp)
                                ) {
                                    SectionLineIcon(
                                        iconType = section.iconType,
                                        isArca = isArca
                                    )
                                    Column(
                                        horizontalAlignment = Alignment.Start,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = section.name,
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 17.sp,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        BravoUnderline(isArca = isArca)
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .clickable {
                                            HapticFeedbackManager.onNavigationClick(view)
                                            onOpenCategory(section.name)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                        .testTag("see_all_${section.id}"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Ver todos",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = primaryColor,
                                        maxLines = 1
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 14.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(
                                    items = sectionProducts,
                                    key = { it.sku },
                                    contentType = { "product_card" }
                                ) { product ->
                                    VerticalProductCard(
                                        product = product,
                                        qtyInCart = cartQtyProvider(product.sku),
                                        isArca = isArca,
                                        darkMode = darkMode,
                                        onOpenDetail = { onOpenProduct(product.sku) },
                                        onIncrement = { onChangeQty(product.sku, 1) },
                                        onDecrement = { onChangeQty(product.sku, -1) },
                                        isFavorite = isFavoriteProvider(product.sku),
                                        onToggleFavorite = onToggleFavorite?.let { fn -> { fn(product.sku) } },
                                        modifier = Modifier.width(126.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item(key = "home_ai_footer", contentType = "ai_banner") {
                    TranslucentCard(
                        darkMode = darkMode,
                        isArca = isArca,
                        cornerRadius = 22.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 18.dp)
                            .testTag("home_ai_hero_banner"),
                        onClick = {
                            HapticFeedbackManager.onAssistantTrigger(view)
                            onNavigateToBravIa(null)
                        }
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = if (isArca) {
                                        "Asesoría Nutricional Brav IA"
                                    } else {
                                        "Compra y Pedidos con Brav IA"
                                    },
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                BravoUnderline(isArca = isArca)
                            }
                            Text(
                                text = "Tu asistente para armar la compra según tu presupuesto, descubrir recetas paso a paso y preparar tu pedido en segundos.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            AnimatedPurchaseButton(
                                text = "Abrir Asistente Brav IA",
                                icon = Icons.Default.AutoAwesome,
                                primaryColor = primaryColor,
                                onClick = {
                                    HapticFeedbackManager.onAssistantTrigger(view)
                                    onNavigateToBravIa(null)
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Surface(
                                onClick = {
                                    HapticFeedbackManager.onNavigationClick(view)
                                    onOpenMyLists()
                                },
                                shape = RoundedCornerShape(999.dp),
                                color = primaryColor.copy(alpha = 0.10f),
                                border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.35f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_open_smart_lists_button")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    BravoUnifiedIcon(
                                        iconKey = "list",
                                        tint = primaryColor,
                                        size = 16.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Mis Listas de Compras",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.sp,
                                        color = primaryColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        }

        BravoArcaSelectorMenuOverlay(
            expanded = isStoreMenuExpanded && showTopHeader,
            activeStore = storeMode,
            darkMode = darkMode,
            menuHazeState = storeMenuHazeState,
            onDismiss = { isStoreMenuExpanded = false },
            onSelectStore = { mode ->
                isStoreMenuExpanded = false
                onSelectStoreMode(mode)
            }
        )
    }
}

@Composable
fun CatalogScreen(
    storeMode: StoreMode,
    darkMode: Boolean,
    sections: List<CatalogSection>,
    allProducts: List<Product>,
    filterQuery: String,
    isOfflineMode: Boolean = false,
    cacheStatusLabel: String = "Catálogo oficial al día",
    areMenusVisible: Boolean = true,
    dailyRotatingOffers: List<DailyRotatingOffer> = emptyList(),
    onRotateOfferDay: (Int) -> Unit = {},
    onTriggerDailyOfferPush: () -> Unit = {},
    onOpenProduct: (String) -> Unit = {},
    onChangeQty: (String, Int) -> Unit = { _, _ -> },
    onFilterQueryChange: (String) -> Unit,
    onToggleStoreMode: () -> Unit,
    onSelectStoreMode: (StoreMode) -> Unit = { onToggleStoreMode() },
    onOpenCategory: (String) -> Unit
) {
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary

    var localFilter by rememberSaveable { mutableStateOf(filterQuery) }
    var debouncedFilter by rememberSaveable { mutableStateOf(filterQuery) }

    val countsByCategory = remember(allProducts) {
        allProducts.groupingBy { it.category }.eachCount()
    }

    LaunchedEffect(filterQuery) {
        if (filterQuery.isEmpty() && localFilter.isNotEmpty()) {
            localFilter = ""
            debouncedFilter = ""
        }
    }

    LaunchedEffect(localFilter) {
        if (localFilter.isBlank()) {
            debouncedFilter = ""
            onFilterQueryChange("")
        } else {
            delay(300L)
            debouncedFilter = localFilter.trim()
            onFilterQueryChange(debouncedFilter)
        }
    }

    val filteredSections = remember(debouncedFilter, sections, allProducts) {
        val q = debouncedFilter.trim().lowercase()
        if (q.isEmpty()) sections
        else sections.filter { sec ->
            sec.name.lowercase().contains(q) ||
                allProducts.any { it.category == sec.name && it.name.lowercase().contains(q) }
        }
    }

    val hazeState = LocalTranslucentHazeState.current
    val density = LocalDensity.current
    var headerHeightPx by remember { mutableIntStateOf(0) }
    val showTopHeader = areMenusVisible
    val headerTopPadding by animateDpAsState(
        targetValue = if (showTopHeader) with(density) { headerHeightPx.toDp() } else 8.dp,
        animationSpec = tween(durationMillis = 220),
        label = "catalog_header_padding"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f)
                .testTag("catalog_screen_list"),
            contentPadding = PaddingValues(top = headerTopPadding + 4.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (debouncedFilter.isEmpty() && dailyRotatingOffers.isNotEmpty()) {
                item(key = "catalog_daily_rotating_offers_carousel", contentType = "daily_offers") {
                    val activeDayLabel = dailyRotatingOffers.firstOrNull()?.dayLabel ?: "Hoy"
                    val activeThemeSubtitle = dailyRotatingOffers.firstOrNull()?.subtitle?.substringBefore("•")?.trim()
                        ?: "Ofertas Especiales del Día"

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, bottom = 4.dp)
                            .testTag("daily_rotating_offers_section"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocalOffer,
                                    contentDescription = "Ofertas del día",
                                    tint = primaryColor,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(
                                    text = "Ofertas que Rotan Día a Día",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                            }
                            BravoUnderline(isArca = isArca)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$activeDayLabel • $activeThemeSubtitle",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.TICK)
                                        onRotateOfferDay(1)
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = primaryColor.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.32f)),
                                    modifier = Modifier.testTag("rotate_daily_offer_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Refresh,
                                            contentDescription = "Ver siguiente día",
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Rotar Día",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = primaryColor
                                        )
                                    }
                                }

                                Surface(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onTriggerDailyOfferPush()
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.testTag("daily_offer_push_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.NotificationsActive,
                                            contentDescription = "Enviar alerta de oferta del día",
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Alerta Push",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = primaryColor
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(
                                items = dailyRotatingOffers,
                                key = { it.id },
                                contentType = { "daily_offer_card" }
                            ) { offer ->
                                val prod = allProducts.find { it.sku == offer.sku }
                                TranslucentCard(
                                    darkMode = darkMode,
                                    isArca = isArca,
                                    cornerRadius = 20.dp,
                                    modifier = Modifier
                                        .width(215.dp)
                                        .testTag("daily_offer_card_${offer.sku}"),
                                    onClick = { onOpenProduct(offer.sku) }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(999.dp),
                                                color = primaryColor
                                            ) {
                                                Text(
                                                    text = "-${offer.discountPct}% ${offer.dayLabel.uppercase()}",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.5.sp,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                            Text(
                                                text = "RD$${offer.originalPrice}",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                textDecoration = TextDecoration.LineThrough
                                            )
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier.size(56.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (prod != null) {
                                                    ProductArtworkView(product = prod)
                                                }
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = offer.title,
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "RD$ ${offer.offerPrice}",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = primaryColor
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .size(28.dp)
                                                            .clip(CircleShape)
                                                            .background(primaryColor)
                                                            .clickable {
                                                                HapticFeedbackManager.onAddToCart(view)
                                                                onChangeQty(offer.sku, 1)
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Add,
                                                            contentDescription = "Agregar oferta",
                                                            tint = MaterialTheme.colorScheme.onPrimary,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item(key = "catalog_pasillos_header", contentType = "header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isArca) "Departamentos El Arca Petshop" else "Pasillos Oficiales Supermercados Bravo",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                    BravoUnderline(isArca = isArca)
                }
            }

            items(
                items = filteredSections,
                key = { it.id },
                contentType = { "catalog_section_card" }
            ) { sec ->
                val count = countsByCategory[sec.name] ?: 0
                TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    cornerRadius = 18.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("catalog_section_${sec.id}"),
                    onClick = { onOpenCategory(sec.name) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            SectionLineIcon(iconType = sec.iconType, isArca = isArca)
                            Column {
                                Text(
                                    text = sec.name,
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                DiagonalMetadataStrip(
                                    items = listOf("Pasillo oficial", "Calidad y frescura"),
                                    slashColor = primaryColor,
                                    fontSizeSp = 11f
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Abrir sección",
                            tint = primaryColor
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showTopHeader,
            enter = expandVertically(animationSpec = tween(240)) + fadeIn(animationSpec = tween(200)),
            exit = shrinkVertically(animationSpec = tween(240)) + fadeOut(animationSpec = tween(170)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .onSizeChanged { headerHeightPx = it.height }
        ) {
            FloatingHeaderCapsule(darkMode = darkMode) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isArca) "Catálogo El Arca Petshop" else "Catálogo Supermercados Bravo",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.5.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        BravoUnderline(isArca = isArca)
                    }

                    PredictiveCatalogSearchBar(
                        query = localFilter,
                        onQueryChange = { localFilter = it },
                        catalogProducts = allProducts,
                        onSelectPredictedProduct = { prod ->
                            localFilter = prod.name
                            debouncedFilter = prod.name
                            onFilterQueryChange(prod.name)
                        },
                        placeholderText = "Buscar pasillo o producto...",
                        darkMode = darkMode,
                        isArca = isArca,
                        testTag = "catalog_filter_input"
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryGridScreen(
    categoryName: String,
    products: List<Product>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    storeMode: StoreMode,
    darkMode: Boolean,
    cartQtyProvider: (String) -> Int,
    isFavoriteProvider: (String) -> Boolean = { false },
    onToggleFavorite: ((String) -> Unit)? = null,
    areMenusVisible: Boolean = true,
    onBack: () -> Unit,
    onOpenProduct: (String) -> Unit,
    onChangeQty: (String, Int) -> Unit
) {
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary

    var localQuery by rememberSaveable { mutableStateOf(searchQuery) }
    var debouncedQuery by rememberSaveable { mutableStateOf(searchQuery) }

    LaunchedEffect(searchQuery) {
        if (searchQuery.isEmpty() && localQuery.isNotEmpty()) {
            localQuery = ""
            debouncedQuery = ""
        }
    }

    LaunchedEffect(localQuery) {
        if (localQuery.isBlank()) {
            debouncedQuery = ""
            onSearchQueryChange("")
        } else {
            delay(300L)
            debouncedQuery = localQuery.trim()
            onSearchQueryChange(debouncedQuery)
        }
    }

    val catProducts = remember(categoryName, products) {
        products.filter { it.category == categoryName }
    }

    val filteredItems = remember(debouncedQuery, catProducts) {
        val q = debouncedQuery.trim().lowercase()
        if (q.isEmpty()) catProducts
        else catProducts.filter {
            it.name.lowercase().contains(q) || it.badge.lowercase().contains(q)
        }
    }

    val rows = remember(filteredItems) {
        filteredItems.chunked(3)
    }

    val hazeState = LocalTranslucentHazeState.current
    val density = LocalDensity.current
    var headerHeightPx by remember { mutableIntStateOf(0) }
    val showTopHeader = areMenusVisible
    val headerTopPadding by animateDpAsState(
        targetValue = if (showTopHeader) with(density) { headerHeightPx.toDp() } else 8.dp,
        animationSpec = tween(durationMillis = 220),
        label = "category_header_padding"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f)
                .testTag("category_grid_screen"),
            contentPadding = PaddingValues(top = headerTopPadding + 6.dp, bottom = 128.dp)
        ) {
            items(
                items = rows,
                key = { row -> row.first().sku },
                contentType = { "category_row" }
            ) { rowItems ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowItems.forEach { prod ->
                        Box(modifier = Modifier.weight(1f)) {
                            VerticalProductCard(
                                product = prod,
                                qtyInCart = cartQtyProvider(prod.sku),
                                isArca = isArca,
                                darkMode = darkMode,
                                onOpenDetail = { onOpenProduct(prod.sku) },
                                onIncrement = { onChangeQty(prod.sku, 1) },
                                onDecrement = { onChangeQty(prod.sku, -1) },
                                isFavorite = isFavoriteProvider(prod.sku),
                                onToggleFavorite = onToggleFavorite?.let { fn -> { fn(prod.sku) } },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    repeat(3 - rowItems.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showTopHeader,
            enter = expandVertically(animationSpec = tween(240)) + fadeIn(animationSpec = tween(200)),
            exit = shrinkVertically(animationSpec = tween(240)) + fadeOut(animationSpec = tween(170)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .onSizeChanged { headerHeightPx = it.height }
        ) {
            FloatingHeaderCapsule(darkMode = darkMode) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                HapticFeedbackManager.onNavigationClick(view)
                                onBack()
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("category_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Volver al catálogo",
                                tint = primaryColor
                            )
                        }

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = categoryName,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = isArca)
                        }

                        Spacer(modifier = Modifier.size(38.dp))
                    }

                    PredictiveCatalogSearchBar(
                        query = localQuery,
                        onQueryChange = { localQuery = it },
                        catalogProducts = catProducts,
                        onSelectPredictedProduct = { prod ->
                            localQuery = prod.name
                            debouncedQuery = prod.name
                            onSearchQueryChange(prod.name)
                        },
                        placeholderText = "Buscar dentro de $categoryName...",
                        darkMode = darkMode,
                        isArca = isArca,
                        testTag = "category_search_input"
                    )
                }
            }
        }
    }
}

@Composable
fun ProductDetailScreen(
    product: Product,
    qtyInCart: Int,
    totalCartCount: Int,
    isFavorite: Boolean,
    storeMode: StoreMode,
    darkMode: Boolean,
    onBack: () -> Unit,
    onOpenCart: () -> Unit,
    onOpenCategoryFilter: (String) -> Unit,
    onToggleFavorite: () -> Unit,
    onShare: () -> Unit,
    onChangeQty: (Int) -> Unit,
    onRemoveCompletely: () -> Unit,
    onAskBravIa: () -> Unit
) {
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val effectiveQty = if (qtyInCart > 0) qtyInCart else 1
    val accumulatedPrice = product.price * effectiveQty
    val trustDescription = remember(product.sku) { buildProductTrustDescription(product) }

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("product_detail_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 132.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "detail_main_card", contentType = "product_card") {
                TranslucentCard(
                darkMode = darkMode,
                isArca = isArca,
                cornerRadius = 24.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            onClick = {
                                performCrispHaptic(view, HapticStyle.TICK)
                                onOpenCategoryFilter(product.category)
                            },
                            shape = RoundedCornerShape(999.dp),
                            color = primaryColor.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f)),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FilterList,
                                    contentDescription = "Filtrar por categoría",
                                    tint = primaryColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                DiagonalMetadataStrip(
                                    items = listOf(
                                        product.category,
                                        if (product.isBravo) "Marca Bravo" else product.badge.ifBlank { "Oficial" }
                                    ),
                                    slashColor = primaryColor,
                                    fontSizeSp = 11f
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onShare()
                                },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Compartir producto",
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }
                            }

                            Surface(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onToggleFavorite()
                                },
                                shape = CircleShape,
                                color = if (isFavorite) Color(0xFFFFE4E6) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isFavorite) BorderStroke(1.dp, Color(0xFFE11D48).copy(alpha = 0.4f)) else null,
                                modifier = Modifier
                                    .size(38.dp)
                                    .testTag("detail_favorite_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorito",
                                        tint = if (isFavorite) Color(0xFFE11D48) else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ProductArtworkView(
                            product = product,
                            modifier = Modifier.size(168.dp)
                        )
                    }

                    DiagonalMetadataStrip(
                        items = listOf(product.category, product.unit, "ITBIS Incluido", "1% Retorno Bravísima"),
                        slashColor = primaryColor,
                        fontSizeSp = 10.5f
                    )

                    Text(
                        text = product.name,
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 21.sp,
                        lineHeight = 26.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "RD$ ${formatCurrency(product.price)}.00",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 25.sp,
                                color = primaryColor
                            )
                            Text(
                                text = "/ ${product.unit}",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 3.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "Descripción y Garantía de Calidad (${product.category})",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                        }
                        BravoUnderline(isArca = isArca)
                        Text(
                            text = trustDescription,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        item(key = "detail_nutrition_ingredients_card", contentType = "nutrition_card") {
            val nut = remember(product.sku) { product.nutritionProfile() }
            TranslucentCard(
                darkMode = darkMode,
                isArca = isArca,
                cornerRadius = 22.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
                    .testTag("detail_nutrition_card")
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Información Nutricional e Ingredientes",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.5.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                        BravoUnderline(isArca = isArca)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = primaryColor.copy(alpha = if (darkMode) 0.20f else 0.10f),
                            border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.35f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                BravoUnifiedIcon(
                                    iconKey = "sparkle",
                                    tint = primaryColor,
                                    size = 15.dp
                                )
                                Text(
                                    text = if (nut.caloriesKcal != null) {
                                        "${nut.caloriesKcal} kcal • ${nut.caloriesPortionLabel}"
                                    } else {
                                        nut.caloriesPortionLabel
                                    },
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }
                        }

                        if (nut.proteinG != null && nut.carbsG != null && nut.fatG != null) {
                            DiagonalMetadataStrip(
                                items = listOf(
                                    "Prot: ${nut.proteinG}",
                                    "Carb: ${nut.carbsG}",
                                    "Grasa: ${nut.fatG}"
                                ),
                                slashColor = primaryColor,
                                fontSizeSp = 10f
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = "Ingredientes:",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = nut.ingredients,
                            fontFamily = PlusJakartaSans,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        nut.allergens.forEach { allergen ->
                            val isFree = allergen.contains("Libre", ignoreCase = true)
                            val badgeColor = if (isFree) Color(0xFF059669) else Color(0xFFD97706)
                            Surface(
                                shape = CircleShape,
                                color = badgeColor.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.38f))
                            ) {
                                Text(
                                    text = if (isFree) "✓ $allergen" else "Alérgeno: $allergen",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = badgeColor,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        nut.dietaryTags.forEach { diet ->
                            Surface(
                                shape = CircleShape,
                                color = primaryColor.copy(alpha = 0.10f),
                                border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.30f))
                            ) {
                                Text(
                                    text = diet,
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = primaryColor,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item(key = "detail_purchase_card", contentType = "purchase_card") {
            TranslucentCard(
                darkMode = darkMode,
                isArca = isArca,
                cornerRadius = 22.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            DiagonalMetadataStrip(
                                items = listOf(
                                    "CANTIDAD",
                                    if (qtyInCart > 0) "$qtyInCart en carrito" else "Selecciona unidades"
                                ),
                                slashColor = primaryColor,
                                fontSizeSp = 10.5f
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Total: RD$ ${formatCurrency(accumulatedPrice)}.00",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 19.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    HapticFeedbackManager.onDecrementOrRemove(view, isFullRemove = qtyInCart <= 1)
                                    if (qtyInCart > 0) onChangeQty(-1)
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surface)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "Disminuir",
                                    tint = primaryColor,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            Text(
                                text = "$effectiveQty",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            IconButton(
                                onClick = {
                                    HapticFeedbackManager.onAddToCart(view)
                                    onChangeQty(1)
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(primaryColor)
                                    .testTag("detail_increment_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Aumentar",
                                    tint = Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (qtyInCart > 0) {
                            Surface(
                                onClick = {
                                    HapticFeedbackManager.onDecrementOrRemove(view, isFullRemove = true)
                                    onRemoveCompletely()
                                },
                                shape = RoundedCornerShape(999.dp),
                                color = if (darkMode) Color(0xFF4C0519) else Color(0xFFFFE4E6),
                                border = BorderStroke(1.5.dp, Color(0xFFE11D48)),
                                modifier = Modifier
                                    .weight(0.95f)
                                    .testTag("detail_remove_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Remover",
                                        tint = if (darkMode) Color(0xFFFDA4AF) else Color(0xFFBE123C),
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "Remover",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.5.sp,
                                        color = if (darkMode) Color(0xFFFDA4AF) else Color(0xFFBE123C)
                                    )
                                }
                            }
                        }

                        AnimatedPurchaseButton(
                            text = if (qtyInCart == 0) "Agregar • RD$ ${formatCurrency(product.price)}" else "Ir al pago • RD$ ${formatCurrency(accumulatedPrice)}",
                            icon = Icons.Default.ShoppingCart,
                            primaryColor = primaryColor,
                            onClick = {
                                if (qtyInCart == 0) {
                                    HapticFeedbackManager.onAddToCart(view)
                                    onChangeQty(1)
                                } else {
                                    HapticFeedbackManager.onNavigationClick(view)
                                    onOpenCart()
                                }
                            },
                            modifier = Modifier.weight(1.4f),
                            testTag = "detail_primary_cart_action"
                        )
                    }
                }
            }
        }

        item(key = "detail_ai_option", contentType = "ai_option") {
            Surface(
                onClick = {
                    HapticFeedbackManager.onAssistantTrigger(view)
                    onAskBravIa()
                },
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
                    .testTag("detail_ask_bravia_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = primaryColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            DiagonalMetadataStrip(
                                items = listOf("OPCIÓN SUGERIDA", "Brav IA"),
                                slashColor = primaryColor,
                                fontSizeSp = 10f
                            )
                            Text(
                                text = "Consultar recetas, alergias o dietas con este producto",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = primaryColor
                    )
                }
            }
        }
    }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        HapticFeedbackManager.onNavigationClick(view)
                        onBack()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        tint = primaryColor
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Detalle del Producto",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = isArca)
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("detail_cart_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable {
                                HapticFeedbackManager.onNavigationClick(view)
                                onOpenCart()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Ver carrito",
                            tint = primaryColor,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                    if (totalCartCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(17.dp)
                                .clip(CircleShape)
                                .background(primaryColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = totalCartCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}
