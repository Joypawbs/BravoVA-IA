package com.example

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appcheck.configureAppCheck
import com.example.model.AccountSubScreen
import com.example.model.AppScreen
import com.example.model.StoreMode
import com.example.notifications.BravoPushNotificationCenter
import androidx.compose.ui.draw.clip
import com.example.ui.components.AppStartupSkeletonScreen
import com.example.ui.components.BarcodeScannerModal
import com.example.ui.components.BravoUnifiedIcon
import com.example.ui.components.DeviceSupportsGpuBlur
import com.example.ui.components.FloatingActionFabs
import com.example.ui.components.HapticFeedbackManager
import com.example.ui.components.LocalTranslucentHazeState
import com.example.ui.components.OrderSuccessCelebrationOverlay
import com.example.ui.components.TranslucentBottomDock
import com.example.ui.components.UniformBackdropBlurRadius
import com.example.ui.components.realGpuBlur
import com.example.ui.components.translucentBackdropEffect
import com.example.ui.components.translucentBackdropSource
import dev.chrisbanes.haze.rememberHazeState
import com.example.ui.screens.AccountGridScreen
import com.example.ui.screens.AccountSubScreenView
import com.example.ui.screens.BravIaChatScreen
import com.example.ui.screens.BravisimaScreen
import com.example.ui.screens.BravoGoogleAuthScreen
import com.example.ui.screens.CartCheckoutScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.CategoryGridScreen
import com.example.ui.screens.DeliveryTrackingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.authStateFlow
import com.example.ui.screens.signOutGoogleUser
import com.example.ui.screens.verifiedGoogleSessionFallback
import com.example.ui.theme.BravoAmber
import com.example.ui.theme.BravoVaTheme
import com.example.ui.theme.PlusJakartaSans
import com.example.viewmodel.BravoViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private fun configureHighRefreshRateAndHdr(activity: ComponentActivity) {
    runCatching {
        val window = activity.window ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = ActivityInfo.COLOR_MODE_HDR
        }
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display
        } else {
            @Suppress("DEPRECATION")
            activity.windowManager.defaultDisplay
        }
        val supportedModes = display?.supportedModes
        val currentMode = display?.mode
        val highestRateMode = supportedModes
            ?.filter { mode ->
                currentMode == null ||
                    (mode.physicalWidth == currentMode.physicalWidth &&
                        mode.physicalHeight == currentMode.physicalHeight)
            }
            ?.maxByOrNull { it.refreshRate }
            ?: supportedModes?.maxByOrNull { it.refreshRate }

        val params = window.attributes
        if (highestRateMode != null) {
            params.preferredDisplayModeId = highestRateMode.modeId
            params.preferredRefreshRate = highestRateMode.refreshRate
        } else {
            params.preferredRefreshRate = 120f
        }
        window.attributes = params
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        configureHighRefreshRateAndHdr(this)
        val initialFcmScreen = intent?.getStringExtra(BravoPushNotificationCenter.EXTRA_OPEN_SCREEN)
        val initialFcmSku = intent?.getStringExtra(BravoPushNotificationCenter.EXTRA_PRODUCT_SKU)
        val instantPrefs = getSharedPreferences("bravova_instant_prefs", Context.MODE_PRIVATE)
        val initialGuestPref = instantPrefs.getBoolean("guest_mode_enabled", false)
        val appPrefs = getSharedPreferences("bravova_prefs", Context.MODE_PRIVATE)

        setContent {
            val systemDark = isSystemInDarkTheme()
            var authScreenDarkMode by remember(systemDark) {
                mutableStateOf(systemDark)
            }
            val auth = remember { Firebase.auth }
            val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
            val fallbackGoogleActive by verifiedGoogleSessionFallback.collectAsStateWithLifecycle()
            val user = currentUser
            var isGuestSession by rememberSaveable { mutableStateOf(initialGuestPref) }

            if (user == null && !isGuestSession && !fallbackGoogleActive) {
                BravoVaTheme(
                    darkTheme = authScreenDarkMode,
                    isArcaStore = false,
                    paletteId = "material_you"
                ) {
                    BravoGoogleAuthScreen(
                        darkMode = authScreenDarkMode,
                        isMaterialYouPalette = true,
                        onToggleDarkMode = {
                            val nextDark = !authScreenDarkMode
                            authScreenDarkMode = nextDark
                            appPrefs.edit().putBoolean("dark_mode", nextDark).apply()
                        },
                        onContinueAsGuest = {
                            isGuestSession = true
                        }
                    )
                }
            } else {
                val sessionKey = user?.uid ?: if (fallbackGoogleActive) "google_verified_user" else "guest_local_session"
                key(sessionKey) {
                    val viewModel: BravoViewModel = viewModel(key = sessionKey)
                    val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
                    val activeStore by viewModel.activeStore.collectAsStateWithLifecycle()
                    val selectedPaletteId by viewModel.selectedPaletteId.collectAsStateWithLifecycle()

                    LaunchedEffect(darkMode) {
                        authScreenDarkMode = darkMode
                    }

                    LaunchedEffect(user?.uid, user?.displayName, user?.email, isGuestSession, fallbackGoogleActive) {
                        when {
                            user != null -> {
                                isGuestSession = false
                                viewModel.bindAuthenticatedUser(user.uid, user.displayName, user.email)
                            }
                            fallbackGoogleActive -> {
                                isGuestSession = false
                                val savedName = instantPrefs.getString("google_fallback_name", "Cliente Google BravoVa")
                                val savedEmail = instantPrefs.getString("google_fallback_email", "cliente.google@bravova.do")
                                viewModel.bindAuthenticatedUser("google_verified_user", savedName, savedEmail)
                            }
                            isGuestSession -> {
                                viewModel.bindGuestUser()
                            }
                        }
                    }

                    LaunchedEffect(initialFcmScreen, initialFcmSku) {
                        viewModel.handleFcmDeepLinkIntent(initialFcmScreen, initialFcmSku)
                    }

                    BravoVaTheme(
                        darkTheme = darkMode,
                        isArcaStore = activeStore == StoreMode.ARCA,
                        paletteId = selectedPaletteId
                    ) {
                        BravoVaApp(
                            viewModel = viewModel,
                            onExitSession = {
                                viewModel.exitGuestMode()
                                isGuestSession = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BravoVaApp(
    viewModel: BravoViewModel,
    onExitSession: () -> Unit = {}
) {
    val isAppBooting by viewModel.isAppBooting.collectAsStateWithLifecycle()
    val activeStore by viewModel.activeStore.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeCategory by viewModel.activeCategory.collectAsStateWithLifecycle()
    val activeProductSku by viewModel.activeProductSku.collectAsStateWithLifecycle()
    val activeAccountSub by viewModel.activeAccountSub.collectAsStateWithLifecycle()
    val homeSearchQuery by viewModel.homeSearchQuery.collectAsStateWithLifecycle()
    val catalogFilterQuery by viewModel.catalogFilterQuery.collectAsStateWithLifecycle()
    val categorySearchQuery by viewModel.categorySearchQuery.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val bravisimaBalance by viewModel.accumulatedBravisimaBalance.collectAsStateWithLifecycle()
    val bravisimaCard by viewModel.bravisimaCard.collectAsStateWithLifecycle()
    val bravisimaMovements by viewModel.bravisimaMovements.collectAsStateWithLifecycle()
    val isSavingBravisima by viewModel.isSavingBravisima.collectAsStateWithLifecycle()
    val redeemBravisima by viewModel.redeemBravisimaInCart.collectAsStateWithLifecycle()
    val isScannerOpen by viewModel.isScannerOpen.collectAsStateWithLifecycle()
    val scannedSku by viewModel.scannedSku.collectAsStateWithLifecycle()
    val toast by viewModel.toast.collectAsStateWithLifecycle()
    val cartPulseTrigger by viewModel.cartPulseTrigger.collectAsStateWithLifecycle()
    val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
    val selectedPaletteId by viewModel.selectedPaletteId.collectAsStateWithLifecycle()
    val pushNotifications by viewModel.pushNotifications.collectAsStateWithLifecycle()
    val fcmToken by viewModel.fcmToken.collectAsStateWithLifecycle()
    val fcmTopics by viewModel.fcmTopics.collectAsStateWithLifecycle()
    val pushFeed by viewModel.pushFeed.collectAsStateWithLifecycle()
    val activeBranch by viewModel.activeBranch.collectAsStateWithLifecycle()
    val userProfile by viewModel.profile.collectAsStateWithLifecycle()
    val paymentMethods by viewModel.paymentMethods.collectAsStateWithLifecycle()
    val addresses by viewModel.addresses.collectAsStateWithLifecycle()
    val shoppingLists by viewModel.lists.collectAsStateWithLifecycle()
    val aiPopulatingListId by viewModel.aiPopulatingListId.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val trackedOrder by viewModel.trackedOrder.collectAsStateWithLifecycle()
    val isUpdatingOrderStatus by viewModel.isUpdatingOrderStatus.collectAsStateWithLifecycle()
    val celebrationOrder by viewModel.celebrationOrder.collectAsStateWithLifecycle()
    val selectedOfferDayOffset by viewModel.selectedOfferDayOffset.collectAsStateWithLifecycle()
    val realLocationMetrics by viewModel.realLocationMetrics.collectAsStateWithLifecycle()
    val driverTelemetry by viewModel.driverTelemetry.collectAsStateWithLifecycle()
    val driverChatMessages by viewModel.driverChatMessages.collectAsStateWithLifecycle()
    val isDriverTyping by viewModel.isDriverTyping.collectAsStateWithLifecycle()
    val liveDeliveryBanner by viewModel.liveDeliveryBanner.collectAsStateWithLifecycle()
    val firestoreSyncStatus by viewModel.firestoreSyncStatus.collectAsStateWithLifecycle()
    val isGuestMode by viewModel.isGuestMode.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineMode.collectAsStateWithLifecycle()
    val cacheStatusLabel by viewModel.cacheStatusLabel.collectAsStateWithLifecycle()
    val sections by viewModel.activeStoreSections.collectAsStateWithLifecycle()
    val activeProducts by viewModel.activeStoreProducts.collectAsStateWithLifecycle()
    val allCatalogProducts by viewModel.allCachedProducts.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isAiGenerating by viewModel.isAiGenerating.collectAsStateWithLifecycle()
    val budgetAmount by viewModel.targetBudgetInChat.collectAsStateWithLifecycle()
    val npuStatus by viewModel.npuStatus.collectAsStateWithLifecycle()
    val pendingChatImageUri by viewModel.pendingChatImageUri.collectAsStateWithLifecycle()
    val submittedSuggestions by viewModel.submittedSuggestions.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isArca = activeStore == StoreMode.ARCA
    val dailyRotatingOffers = remember(activeStore, activeProducts, selectedOfferDayOffset) {
        viewModel.getDailyRotatingOffersForCurrentStore(selectedOfferDayOffset)
    }
    val frequentStats = remember(orders, shoppingLists, allCatalogProducts) {
        viewModel.getPurchaseHistoryStats()
    }
    val cartTotals = remember(cart, redeemBravisima, bravisimaBalance, allCatalogProducts) {
        viewModel.computeCartTotals(cart, redeemBravisima, bravisimaBalance)
    }
    val cartItemPairs = remember(cart, allCatalogProducts) {
        cart.mapNotNull { item ->
            val prod = viewModel.findProductBySku(item.sku)
            if (prod != null) prod to item.qty else null
        }
    }

    val view = LocalView.current

    val canInterceptBack = isScannerOpen ||
        currentScreen != AppScreen.HOME ||
        homeSearchQuery.isNotEmpty() ||
        catalogFilterQuery.isNotEmpty() ||
        categorySearchQuery.isNotEmpty()

    BackHandler(enabled = canInterceptBack) {
        HapticFeedbackManager.onNavigationClick(view)
        viewModel.navigateBack()
    }

    val scannerBlurRadius by animateFloatAsState(
        targetValue = if (isScannerOpen) 22f else 0f,
        animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
        label = "scanner_backdrop_blur"
    )
    val backdropBlurModifier = if (scannerBlurRadius > 0.5f && DeviceSupportsGpuBlur) {
        Modifier.realGpuBlur(scannerBlurRadius.dp)
    } else {
        Modifier
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary

    var areMenusVisible by remember { mutableStateOf(true) }
    LaunchedEffect(currentScreen, activeStore) {
        areMenusVisible = true
    }
    val menuScrollConnection = remember {
        object : NestedScrollConnection {
            private var accumulatedDelta = 0f

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                val dx = available.x
                if (kotlin.math.abs(dy) > kotlin.math.abs(dx)) {
                    if ((dy > 0f && accumulatedDelta < 0f) || (dy < 0f && accumulatedDelta > 0f)) {
                        accumulatedDelta = 0f
                    }
                    accumulatedDelta += dy
                    if (accumulatedDelta < -18f) {
                        areMenusVisible = false
                        accumulatedDelta = 0f
                    } else if (accumulatedDelta > 14f) {
                        areMenusVisible = true
                        accumulatedDelta = 0f
                    }
                }
                return Offset.Zero
            }
        }
    }

    Crossfade(
        targetState = isAppBooting,
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "startup_skeleton_crossfade"
    ) { booting ->
        if (booting) {
            AppStartupSkeletonScreen(darkMode = darkMode || isSystemInDarkTheme(), isArca = isArca)
        } else {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .then(backdropBlurModifier),
                contentWindowInsets = WindowInsets.safeDrawing,
                containerColor = MaterialTheme.colorScheme.background
            ) { innerPadding ->
                val hazeState = rememberHazeState(blurEnabled = true)
                CompositionLocalProvider(LocalTranslucentHazeState provides hazeState) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = innerPadding.calculateTopPadding())
                        .nestedScroll(menuScrollConnection)
                ) {
                    val isAiAmbientActive = currentScreen == AppScreen.BRAVIA || isAiGenerating
                    val aiAmbientAlpha by animateFloatAsState(
                        targetValue = when {
                            isAiGenerating -> if (darkMode) 0.14f else 0.24f
                            currentScreen == AppScreen.BRAVIA -> if (darkMode) 0.08f else 0.15f
                            else -> 0f
                        },
                        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
                        label = "global_ai_ambient_alpha"
                    )
                    val rootBgColor = MaterialTheme.colorScheme.background
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .translucentBackdropSource(hazeState, zIndex = 0f)
                    ) {
                        drawRect(color = rootBgColor)
                        val topGlowAlpha = if (darkMode) 0.12f else 0.16f
                        val midGlowAlpha = if (darkMode) 0.08f else 0.12f
                        val bottomGlowAlpha = if (darkMode) 0.10f else 0.14f
                        val topGlowColor = if (isAiAmbientActive) Color(0xFFF38B9B) else primaryColor
                        val midGlowColor = if (isAiAmbientActive) Color(0xFFF69E98) else BravoAmber
                        val bottomGlowColor = if (isAiAmbientActive) Color(0xFFE86A7C) else secondaryColor
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(topGlowColor.copy(alpha = topGlowAlpha + aiAmbientAlpha * 0.45f), Color.Transparent),
                                center = Offset(size.width * 0.84f, size.height * 0.08f),
                                radius = size.width * 0.72f
                            ),
                            radius = size.width * 0.72f,
                            center = Offset(size.width * 0.84f, size.height * 0.08f)
                        )
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(midGlowColor.copy(alpha = midGlowAlpha + aiAmbientAlpha * 0.40f), Color.Transparent),
                                center = Offset(size.width * 0.14f, size.height * 0.42f),
                                radius = size.width * 0.62f
                            ),
                            radius = size.width * 0.62f,
                            center = Offset(size.width * 0.14f, size.height * 0.42f)
                        )
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(bottomGlowColor.copy(alpha = bottomGlowAlpha + aiAmbientAlpha * 0.45f), Color.Transparent),
                                center = Offset(size.width * 0.80f, size.height * 0.84f),
                                radius = size.width * 0.68f
                            ),
                            radius = size.width * 0.68f,
                            center = Offset(size.width * 0.80f, size.height * 0.84f)
                        )
                    }

                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            val forward = targetState.ordinal >= initialState.ordinal
                            val slideOffset = { fullWidth: Int ->
                                if (forward) fullWidth / 16 else -fullWidth / 16
                            }
                            (fadeIn(animationSpec = tween(210, easing = FastOutSlowInEasing)) +
                                scaleIn(
                                    initialScale = 0.975f,
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) +
                                slideInHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    ),
                                    initialOffsetX = slideOffset
                                ))
                                .togetherWith(
                                    fadeOut(animationSpec = tween(150)) +
                                        scaleOut(targetScale = 0.985f, animationSpec = tween(150))
                                )
                        },
                        label = "main_screen_transition"
                    ) { screenState ->
                        when (screenState) {
                        AppScreen.HOME -> {
                            AnimatedContent(
                                targetState = activeStore,
                                transitionSpec = {
                                    val enteringArca = targetState == StoreMode.ARCA
                                    val direction = if (enteringArca) 1 else -1
                                    (fadeIn(animationSpec = tween(300, easing = FastOutSlowInEasing)) +
                                        scaleIn(initialScale = 0.96f, animationSpec = tween(300, easing = FastOutSlowInEasing)) +
                                        slideInHorizontally(animationSpec = tween(300, easing = FastOutSlowInEasing)) { fullWidth ->
                                            direction * (fullWidth / 8)
                                        })
                                        .togetherWith(
                                            fadeOut(animationSpec = tween(210)) +
                                                scaleOut(targetScale = 0.96f, animationSpec = tween(210)) +
                                                slideOutHorizontally(animationSpec = tween(210)) { fullWidth ->
                                                    -direction * (fullWidth / 10)
                                                }
                                        )
                                },
                                label = "store_home_transition"
                            ) { storeModeState ->
                                HomeScreen(
                                    storeMode = storeModeState,
                                    darkMode = darkMode,
                                    sections = sections,
                                    allProducts = activeProducts,
                                    searchQuery = homeSearchQuery,
                                    cartQtyProvider = { sku -> cart.find { it.sku == sku }?.qty ?: 0 },
                                    isFavoriteProvider = { sku ->
                                        val favList = shoppingLists.firstOrNull()
                                        favList?.skus?.contains(sku) == true
                                    },
                                    onToggleFavorite = { sku -> viewModel.toggleProductInFavList(sku) },
                                    isOfflineMode = isOfflineMode,
                                    isGuestMode = isGuestMode,
                                    cacheStatusLabel = cacheStatusLabel,
                                    areMenusVisible = areMenusVisible,
                                    dailyRotatingOffers = dailyRotatingOffers,
                                    onRotateOfferDay = { delta -> viewModel.rotateDailyOffersDay(delta) },
                                    onTriggerDailyOfferPush = { viewModel.triggerExclusiveOfferPush() },
                                    onSearchQueryChange = { viewModel.setHomeSearchQuery(it) },
                                    onSelectStoreMode = { viewModel.selectStore(it) },
                                    onOpenScanner = { viewModel.openBarcodeScanner() },
                                    onNavigateToBravIa = { prompt ->
                                        viewModel.navigateTo(AppScreen.BRAVIA)
                                        if (!prompt.isNullOrBlank()) {
                                            viewModel.sendCustomChatMsg(prompt)
                                        }
                                    },
                                    onNavigateToDelivery = { viewModel.openOrderTracking() },
                                    onOpenMyLists = { viewModel.openAccountSubScreen(AccountSubScreen.LISTAS) },
                                    onOpenCategory = { catName -> viewModel.openCategoryScreen(catName) },
                                    onOpenProduct = { sku -> viewModel.openProductDetail(sku) },
                                    onChangeQty = { sku, delta -> viewModel.changeProductQty(sku, delta) }
                                )
                            }
                        }

                        AppScreen.CATALOG -> {
                            AnimatedContent(
                                targetState = activeStore,
                                transitionSpec = {
                                    val enteringArca = targetState == StoreMode.ARCA
                                    val direction = if (enteringArca) 1 else -1
                                    (fadeIn(animationSpec = tween(280, easing = FastOutSlowInEasing)) +
                                        scaleIn(initialScale = 0.96f, animationSpec = tween(280, easing = FastOutSlowInEasing)) +
                                        slideInHorizontally(animationSpec = tween(280, easing = FastOutSlowInEasing)) { fullWidth ->
                                            direction * (fullWidth / 9)
                                        })
                                        .togetherWith(
                                            fadeOut(animationSpec = tween(200)) +
                                                scaleOut(targetScale = 0.96f, animationSpec = tween(200))
                                        )
                                },
                                label = "store_catalog_transition"
                            ) { storeModeState ->
                                CatalogScreen(
                                    storeMode = storeModeState,
                                    darkMode = darkMode,
                                    sections = sections,
                                    allProducts = activeProducts,
                                    filterQuery = catalogFilterQuery,
                                    isOfflineMode = isOfflineMode,
                                    cacheStatusLabel = cacheStatusLabel,
                                    areMenusVisible = areMenusVisible,
                                    dailyRotatingOffers = dailyRotatingOffers,
                                    onRotateOfferDay = { delta -> viewModel.rotateDailyOffersDay(delta) },
                                    onTriggerDailyOfferPush = { viewModel.triggerExclusiveOfferPush() },
                                    onFilterQueryChange = { viewModel.setCatalogFilterQuery(it) },
                                    onToggleStoreMode = { viewModel.toggleStoreMode() },
                                    onSelectStoreMode = { viewModel.selectStore(it) },
                                    onOpenCategory = { catName -> viewModel.openCategoryScreen(catName) },
                                    onOpenProduct = { sku -> viewModel.openProductDetail(sku) },
                                    onChangeQty = { sku, delta -> viewModel.changeProductQty(sku, delta) }
                                )
                            }
                        }

                        AppScreen.CATEGORY -> {
                            CategoryGridScreen(
                                categoryName = activeCategory,
                                products = activeProducts,
                                searchQuery = categorySearchQuery,
                                onSearchQueryChange = { viewModel.setCategorySearchQuery(it) },
                                storeMode = activeStore,
                                darkMode = darkMode,
                                areMenusVisible = areMenusVisible,
                                cartQtyProvider = { sku -> cart.find { it.sku == sku }?.qty ?: 0 },
                                isFavoriteProvider = { sku ->
                                    val favList = shoppingLists.firstOrNull()
                                    favList?.skus?.contains(sku) == true
                                },
                                onToggleFavorite = { sku -> viewModel.toggleProductInFavList(sku) },
                                onBack = { viewModel.navigateBack() },
                                onOpenProduct = { sku -> viewModel.openProductDetail(sku) },
                                onChangeQty = { sku, delta -> viewModel.changeProductQty(sku, delta) }
                            )
                        }

                        AppScreen.PRODUCT -> {
                            val prod = viewModel.findProductBySku(activeProductSku) ?: activeProducts.first()
                            val isFav = remember(shoppingLists, prod.sku) {
                                viewModel.isProductFavorite(prod.sku)
                            }
                            ProductDetailScreen(
                                product = prod,
                                qtyInCart = cart.find { it.sku == prod.sku }?.qty ?: 0,
                                totalCartCount = cartTotals.count,
                                isFavorite = isFav,
                                storeMode = activeStore,
                                darkMode = darkMode,
                                onBack = { viewModel.navigateBack() },
                                onOpenCart = { viewModel.navigateTo(AppScreen.CART) },
                                onToggleFavorite = { viewModel.toggleProductInFavList(prod.sku) },
                                onShare = { viewModel.showToast("🔗", "Enlace de ${prod.name} copiado") },
                                onChangeQty = { delta -> viewModel.changeProductQty(prod.sku, delta) },
                                onRemoveCompletely = { viewModel.removeProductCompletely(prod.sku) },
                                onOpenCategoryFilter = { catName -> viewModel.openCategoryScreen(catName) },
                                onAskBravIa = { viewModel.askAiAboutProduct(prod.sku) }
                            )
                        }

                        AppScreen.BRAVISIMA -> {
                            BravisimaScreen(
                                balance = bravisimaBalance,
                                cartTotals = cartTotals,
                                userProfile = userProfile,
                                bravisimaCard = bravisimaCard,
                                movements = bravisimaMovements,
                                isGuestMode = isGuestMode,
                                isSavingBravisima = isSavingBravisima,
                                darkMode = darkMode,
                                onRedeemInCart = {
                                    viewModel.setRedeemBravisimaInCart(true)
                                    viewModel.navigateTo(AppScreen.CART)
                                },
                                onOpenScanner = { viewModel.openBarcodeScanner() },
                                onToggleCardLock = { viewModel.toggleBravisimaCardLock() },
                                onToggleAutoRedeem = { viewModel.toggleBravisimaAutoRedeem() },
                                onSaveCardSettings = { holderName, monthlyGoal, preferredCategory ->
                                    viewModel.updateBravisimaCardSettings(holderName, monthlyGoal, preferredCategory)
                                },
                                onRedeemPromoCode = { code -> viewModel.redeemBravisimaPromoCode(code) },
                                onCopyCardNumber = { number ->
                                    viewModel.showToast("check", "Número $number copiado al portapapeles")
                                },
                                onSignOutGoogle = {
                                    scope.launch {
                                        signOutGoogleUser(context)
                                        onExitSession()
                                    }
                                }
                            )
                        }

                        AppScreen.CART -> {
                            CartCheckoutScreen(
                                cartItems = cartItemPairs,
                                cartTotals = cartTotals,
                                bravisimaBalance = bravisimaBalance,
                                redeemBravisima = redeemBravisima,
                                isBravisimaLocked = bravisimaCard.isLocked,
                                storeMode = activeStore,
                                darkMode = darkMode,
                                onBack = { viewModel.navigateBack() },
                                onEmptyCart = { viewModel.clearCart() },
                                onOpenProduct = { sku -> viewModel.openProductDetail(sku) },
                                onUpdateQty = { sku, delta -> viewModel.changeProductQty(sku, delta) },
                                onToggleRedeem = { enabled -> viewModel.setRedeemBravisimaInCart(enabled) },
                                onConfirmCheckout = { viewModel.completeCheckoutOrder() },
                                onExploreCatalog = { viewModel.navigateTo(AppScreen.HOME) },
                                onAskBravIa = { viewModel.navigateTo(AppScreen.BRAVIA) }
                            )
                        }

                        AppScreen.DELIVERY -> {
                            DeliveryTrackingScreen(
                                branchName = activeBranch,
                                cartItems = cartItemPairs,
                                darkMode = darkMode,
                                trackedOrder = trackedOrder,
                                allOrders = orders,
                                firestoreSyncStatus = firestoreSyncStatus,
                                isGuestMode = isGuestMode,
                                isUpdatingOrderStatus = isUpdatingOrderStatus,
                                realLocationMetrics = realLocationMetrics,
                                driverTelemetry = driverTelemetry,
                                driverChatMessages = driverChatMessages,
                                isDriverTyping = isDriverTyping,
                                liveDeliveryBanner = liveDeliveryBanner,
                                onRefreshRealLocation = { triggerPush ->
                                    viewModel.refreshRealUserLocation(context, triggerPush)
                                },
                                onTriggerDynamicPush = {
                                    viewModel.dispatchDynamicLocationOrderPush()
                                },
                                onSendDriverMessage = { msg ->
                                    viewModel.sendDriverChatMessage(msg)
                                },
                                onToggleAutoSimulation = {
                                    viewModel.toggleLiveTrafficSimulation()
                                },
                                onRecalculateTraffic = {
                                    viewModel.triggerLiveTrafficRecalculation()
                                },
                                onDismissLiveBanner = {
                                    viewModel.dismissLiveDeliveryBanner()
                                },
                                productLookup = { sku -> viewModel.findProductBySku(sku) },
                                onBack = { viewModel.navigateBack() },
                                onCallDriver = {
                                    viewModel.showToast("delivery", "Llamando a Carlos Rodríguez (Repartidor)...")
                                },
                                onMessageDriver = {
                                    viewModel.sendDriverChatMessage("Hola Carlos, ¿por dónde vienes y en cuánto tiempo llegas?")
                                },
                                onSelectOrder = { orderId -> viewModel.selectTrackedOrder(orderId) },
                                onSelectDeliveryStage = { stage ->
                                    viewModel.updateTrackedOrderStatusInFirestore(stage)
                                },
                                onAdvanceDeliveryStage = {
                                    viewModel.advanceTrackedOrderStatusInFirestore()
                                },
                                onOpenProduct = { sku -> viewModel.openProductDetail(sku) }
                            )
                        }

                        AppScreen.BRAVIA -> {
                            BravIaChatScreen(
                                storeMode = activeStore,
                                darkMode = darkMode,
                                areMenusVisible = areMenusVisible,
                                npuStatus = npuStatus,
                                onToggleNpuMode = { viewModel.toggleNpuMode() },
                                pendingImageUri = pendingChatImageUri,
                                onSelectImageUri = { uri -> viewModel.setPendingChatImageUri(uri) },
                                messages = chatMessages,
                                isGenerating = isAiGenerating,
                                budgetAmount = budgetAmount,
                                cartTotals = cartTotals,
                                activeBranch = activeBranch,
                                estimatedEtaMinutes = realLocationMetrics.stageAdjustedEtaMinutes,
                                productLookup = { sku -> viewModel.findProductBySku(sku) },
                                onBack = { viewModel.navigateBack() },
                                onOpenCart = { viewModel.navigateTo(AppScreen.CART) },
                                onOpenMyLists = { viewModel.openAccountSubScreen(AccountSubScreen.LISTAS) },
                                onBudgetChange = { viewModel.setTargetBudgetInChat(it) },
                                onBuildCartForBudget = { viewModel.applyBudgetInChat(false) },
                                onAdjustCartToBudget = { viewModel.applyBudgetInChat(true) },
                                onSendPrompt = { prompt -> viewModel.sendCustomChatMsg(prompt) },
                                onPauseGeneration = { viewModel.pauseOrStopAiGeneration() },
                                onAddBundleForMessage = { msgId -> viewModel.addAiBundleToCart(msgId) },
                                onSaveBundleAsList = { msgId -> viewModel.saveChatMessageBundleAsList(msgId) },
                                onRequestOrderConfirmation = { msgId -> viewModel.requestOrderConfirmationForMessage(msgId) },
                                onConfirmOrderFromChat = { msgId -> viewModel.confirmOrderFromChatMessage(msgId) },
                                onCancelOrderConfirmation = { msgId -> viewModel.cancelOrderConfirmationForMessage(msgId) },
                                onAddSingleProduct = { sku -> viewModel.changeProductQty(sku, 1) },
                                onOpenProduct = { sku -> viewModel.openProductDetail(sku) }
                            )
                        }

                        AppScreen.ACCOUNT -> {
                            AccountGridScreen(
                                userProfile = userProfile,
                                activeBranch = activeBranch,
                                bravisimaBalance = bravisimaBalance,
                                cartCount = cartTotals.count,
                                firestoreSyncStatus = firestoreSyncStatus,
                                isGuestMode = isGuestMode,
                                cacheStatusLabel = cacheStatusLabel,
                                darkMode = darkMode,
                                onBack = { viewModel.navigateBack() },
                                onOpenCart = { viewModel.navigateTo(AppScreen.CART) },
                                onSignOut = {
                                    scope.launch {
                                        signOutGoogleUser(context)
                                        onExitSession()
                                    }
                                },
                                onOpenSubScreen = { sub -> viewModel.openAccountSubScreen(sub) }
                            )
                        }

                        AppScreen.ACCOUNT_SUB -> {
                            AccountSubScreenView(
                                subScreen = activeAccountSub,
                                userProfile = userProfile,
                                activeBranch = activeBranch,
                                selectedPaletteId = selectedPaletteId,
                                firestoreSyncStatus = firestoreSyncStatus,
                                isGuestMode = isGuestMode,
                                isOfflineMode = isOfflineMode,
                                cacheStatusLabel = cacheStatusLabel,
                                orders = orders,
                                paymentMethods = paymentMethods,
                                addresses = addresses,
                                shoppingLists = shoppingLists,
                                aiPopulatingListId = aiPopulatingListId,
                                frequentStats = frequentStats,
                                allProducts = allCatalogProducts,
                                productLookup = { sku -> viewModel.findProductBySku(sku) },
                                fcmToken = fcmToken,
                                fcmTopics = fcmTopics,
                                pushFeed = pushFeed,
                                darkMode = darkMode,
                                notificationsEnabled = pushNotifications,
                                onBack = { viewModel.navigateBack() },
                                onRepeatOrder = { orderId -> viewModel.reorderPastOrder(orderId) },
                                onOpenLiveMap = { viewModel.openOrderTracking() },
                                onOpenOrderTracking = { orderId -> viewModel.openOrderTracking(orderId) },
                                onSaveProfile = { n, p, r, ncf -> viewModel.saveUserProfile(n, p, r, ncf) },
                                onSelectPaymentMethod = { id -> viewModel.setDefaultPayment(id) },
                                onAddPaymentCard = { viewModel.addNewPaymentCard() },
                                onSelectAddress = { id -> viewModel.setDefaultAddress(id) },
                                onLoadListToCart = { listId -> viewModel.addListToCart(listId) },
                                onCreateShoppingList = { name, autoPopulate, focusHint ->
                                    viewModel.createShoppingList(
                                        name = name,
                                        autoPopulateWithAi = autoPopulate,
                                        focusHint = focusHint
                                    )
                                },
                                onDeleteShoppingList = { listId -> viewModel.deleteShoppingList(listId) },
                                onRenameShoppingList = { listId, newName -> viewModel.renameShoppingList(listId, newName) },
                                onPopulateListWithAi = { listId -> viewModel.populateListWithBravIa(listId) },
                                onAddProductToList = { listId, sku -> viewModel.addProductToShoppingList(listId, sku) },
                                onRemoveProductFromList = { listId, sku -> viewModel.removeProductFromShoppingList(listId, sku) },
                                onAddSingleToCart = { sku -> viewModel.changeProductQty(sku, 1) },
                                onOpenProduct = { sku -> viewModel.openProductDetail(sku) },
                                onToggleDarkMode = { viewModel.toggleDarkMode() },
                                npuStatus = npuStatus,
                                onToggleNpuMode = { viewModel.toggleNpuMode() },
                                onSelectPalette = { paletteId -> viewModel.selectColorPalette(paletteId) },
                                onToggleNotifications = { viewModel.togglePushNotifications() },
                                onToggleFcmTopic = { topicKey, enabled -> viewModel.toggleFcmTopic(topicKey, enabled) },
                                onTriggerOfferPush = { viewModel.triggerExclusiveOfferPush() },
                                onTriggerOrderPush = { viewModel.triggerRealtimeOrderStatusPush() },
                                onSelectPushNotification = { record -> viewModel.handlePushNotificationClick(record) },
                                onMarkAllPushRead = { viewModel.markAllPushNotificationsRead() },
                                onRefreshLocalCache = { viewModel.refreshLocalCatalogCache() },
                                submittedSuggestions = submittedSuggestions,
                                onSubmitSupportSuggestion = { category, priority, subject, body ->
                                    viewModel.submitDirectSuggestionFromSupport(
                                        category = category,
                                        priority = priority,
                                        subject = subject,
                                        summaryBody = body
                                    )
                                },
                                onOpenBravIaSupportPrompt = { prompt ->
                                    viewModel.navigateTo(AppScreen.BRAVIA)
                                    viewModel.sendCustomChatMsg(prompt)
                                },
                                onUpdateBranch = { branch -> viewModel.setActiveBranch(branch) },
                                onSignOut = {
                                    scope.launch {
                                        signOutGoogleUser(context)
                                        onExitSession()
                                    }
                                },
                                onShowToast = { icon, msg -> viewModel.showToast(icon, msg) }
                            )
                        }
                    }
                    }

                    val showFabs = currentScreen in listOf(
                        AppScreen.HOME,
                        AppScreen.CATALOG,
                        AppScreen.CATEGORY
                    )
                    AnimatedVisibility(
                        visible = showFabs && areMenusVisible,
                        enter = slideInVertically(
                            initialOffsetY = { it },
                            animationSpec = tween(240, easing = FastOutSlowInEasing)
                        ) + fadeIn(animationSpec = tween(200)),
                        exit = slideOutVertically(
                            targetOffsetY = { it },
                            animationSpec = tween(220, easing = FastOutSlowInEasing)
                        ) + fadeOut(animationSpec = tween(180)),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .navigationBarsPadding()
                            .padding(end = 16.dp, bottom = 86.dp)
                    ) {
                        FloatingActionFabs(
                            cartCount = cartTotals.count,
                            isArca = isArca,
                            darkMode = darkMode,
                            pulseTrigger = cartPulseTrigger,
                            onOpenAi = { viewModel.navigateTo(AppScreen.BRAVIA) },
                            onOpenCart = { viewModel.navigateTo(AppScreen.CART) }
                        )
                    }

                    AnimatedVisibility(
                        visible = areMenusVisible,
                        enter = slideInVertically(
                            initialOffsetY = { it },
                            animationSpec = tween(250, easing = FastOutSlowInEasing)
                        ) + fadeIn(animationSpec = tween(210)),
                        exit = slideOutVertically(
                            targetOffsetY = { it },
                            animationSpec = tween(220, easing = FastOutSlowInEasing)
                        ) + fadeOut(animationSpec = tween(180)),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                    ) {
                        TranslucentBottomDock(
                            currentScreen = currentScreen,
                            isArca = isArca,
                            darkMode = darkMode,
                            onNavigate = { target -> viewModel.navigateTo(target) }
                        )
                    }

                    AnimatedVisibility(
                        visible = toast != null,
                        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 10.dp, start = 20.dp, end = 20.dp)
                    ) {
                        toast?.let { activeToast ->
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = Color(0xFF0F172A).copy(alpha = 0.56f),
                                shadowElevation = 12.dp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .translucentBackdropEffect(darkMode = true, accentColor = primaryColor)
                                    .border(1.dp, Color.White.copy(alpha = 0.26f), RoundedCornerShape(999.dp))
                                    .testTag("toast_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    BravoUnifiedIcon(
                                        iconKey = activeToast.icon,
                                        tint = Color.White,
                                        size = 16.dp
                                    )
                                    Text(
                                        text = activeToast.message,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = celebrationOrder != null,
                        enter = fadeIn(animationSpec = tween(220)),
                        exit = fadeOut(animationSpec = tween(260)),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        celebrationOrder?.let { confirmedOrder ->
                            OrderSuccessCelebrationOverlay(
                                orderId = confirmedOrder.id,
                                totalAmountRd = confirmedOrder.total.toInt(),
                                branchName = confirmedOrder.branch,
                                etaMinutes = realLocationMetrics.stageAdjustedEtaMinutes,
                                distanceKmLabel = "${realLocationMetrics.roadDistanceKm} km",
                                onContinueToTracking = {
                                    viewModel.dismissOrderCelebration()
                                }
                            )
                        }
                    }
                }
                }
            }
        }
    }

    if (isScannerOpen) {
        val scannedProduct = viewModel.findProductBySku(scannedSku)
        BarcodeScannerModal(
            selectedProduct = scannedProduct,
            onSelectProductSku = { sku -> viewModel.simulateScanProduct(sku) },
            onAddScannedProduct = { prod ->
                viewModel.changeProductQty(prod.sku, 1)
                viewModel.closeBarcodeScanner()
            },
            onViewDetails = { prod ->
                viewModel.closeBarcodeScanner()
                viewModel.openProductDetail(prod.sku)
            },
            onDismiss = { viewModel.closeBarcodeScanner() }
        )
    }
}
