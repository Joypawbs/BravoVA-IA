package com.example.ui.components

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Egg
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.LocalDining
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.Shader as AndroidShader
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import coil.size.Size as CoilSize
import coil.transform.Transformation
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import com.example.R
import com.example.model.AppScreen
import com.example.model.Product
import com.example.model.StoreMode
import com.example.model.nutritionProfile
import com.example.ui.theme.ArcaEmerald
import com.example.ui.theme.ArcaTeal
import com.example.ui.theme.BravoAmber
import com.example.ui.theme.BravoGreen
import com.example.ui.theme.BravoLime
import com.example.ui.theme.BravoRed
import com.example.ui.theme.PlusJakartaSans
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

val DeviceSupportsGpuBlur: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

val UniformMenuBlurRadius: Dp = 24.dp
val UniformBackdropBlurRadius: Dp = 38.dp

val LocalTranslucentHazeState = staticCompositionLocalOf<HazeState?> { null }

fun Modifier.realGpuBlur(radiusDp: Dp = UniformMenuBlurRadius): Modifier {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        this.graphicsLayer {
            val px = radiusDp.toPx()
            if (px > 0f) {
                renderEffect = AndroidRenderEffect
                    .createBlurEffect(px, px, AndroidShader.TileMode.MIRROR)
                    .asComposeRenderEffect()
            }
        }
    } else {
        this.blur(radiusDp)
    }
}

@Composable
fun rememberUniformTranslucentHazeStyle(
    darkMode: Boolean,
    accentColor: Color = MaterialTheme.colorScheme.primary
): HazeStyle {
    val tintBase = if (darkMode) Color(0xFF0B1120) else Color(0xFFFFFFFF)
    val fallbackBg = if (darkMode) Color(0xFF0A0F1A) else Color(0xFFFFFAF5)
    val tintAlpha = if (darkMode) 0.34f else 0.54f
    return remember(darkMode) {
        HazeStyle(
            backgroundColor = fallbackBg,
            tints = listOf(
                HazeTint(color = tintBase.copy(alpha = tintAlpha))
            ),
            blurRadius = UniformMenuBlurRadius,
            noiseFactor = 0f
        )
    }
}

fun Modifier.translucentBackdropSource(
    hazeState: HazeState?,
    zIndex: Float = 0f,
    enabled: Boolean = true
): Modifier {
    return if (enabled && hazeState != null && DeviceSupportsGpuBlur) {
        this.hazeSource(state = hazeState, zIndex = zIndex)
    } else {
        this
    }
}

@Composable
fun Modifier.translucentBackdropEffect(
    darkMode: Boolean,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    hazeState: HazeState? = LocalTranslucentHazeState.current,
    enabled: Boolean = true
): Modifier {
    if (!enabled || hazeState == null || !DeviceSupportsGpuBlur) return this
    val style = rememberUniformTranslucentHazeStyle(darkMode = darkMode, accentColor = accentColor)
    return this.hazeEffect(state = hazeState, style = style) {
        blurEnabled = true
    }
}

@Composable
fun uniformMenuTranslucentContainerColor(darkMode: Boolean): Color {
    return if (darkMode) {
        Color(0xFF111C30).copy(alpha = 0.76f)
    } else {
        Color.White.copy(alpha = 0.84f)
    }
}

@Composable
fun uniformInlineTranslucentCardColor(darkMode: Boolean): Color {
    return if (darkMode) {
        Color(0xFF111A2E).copy(alpha = 0.84f)
    } else {
        Color(0xFFFFFFFF).copy(alpha = 0.92f)
    }
}

fun uniformMenuTranslucentGlowBrush(accentColor: Color, darkMode: Boolean): Brush {
    return if (darkMode) {
        Brush.verticalGradient(
            listOf(
                accentColor.copy(alpha = 0.08f),
                Color(0xFF162238).copy(alpha = 0.26f),
                Color(0xFF0D1526).copy(alpha = 0.18f)
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.42f),
                accentColor.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.16f)
            )
        )
    }
}

fun uniformMenuTranslucentBorderBrush(accentColor: Color, darkMode: Boolean): Brush {
    return if (darkMode) {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.28f),
                accentColor.copy(alpha = 0.34f),
                Color.White.copy(alpha = 0.12f)
            )
        )
    } else {
        val topRim = Color.White.copy(alpha = 0.94f)
        val bottomRim = accentColor.copy(alpha = 0.26f)
        Brush.verticalGradient(listOf(topRim, bottomRim))
    }
}

fun uniformMenuTranslucentSheenBrush(darkMode: Boolean, accentColor: Color): Brush {
    return if (darkMode) {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.04f),
                Color.Transparent
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.28f),
                Color.Transparent
            )
        )
    }
}

fun parseHexColor(hex: String, fallback: Color = BravoRed): Color {
    return try {
        val clean = hex.removePrefix("#")
        val value = clean.toLong(16)
        if (clean.length == 6) {
            Color(0xFF000000 or value)
        } else {
            Color(value)
        }
    } catch (_: Exception) {
        fallback
    }
}

@Composable
fun DiagonalMetadataStrip(
    items: List<String>,
    slashColor: Color = MaterialTheme.colorScheme.primary,
    textColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    fontSizeSp: Float = 11f,
    modifier: Modifier = Modifier,
    onItemClick: ((Int, String) -> Unit)? = null
) {
    val cleanItems = remember(items) { items.filter { it.isNotBlank() } }
    if (cleanItems.isEmpty()) return

    if (onItemClick == null) {
        val annotated = remember(cleanItems, slashColor, textColor) {
            buildAnnotatedString {
                cleanItems.forEachIndexed { idx, part ->
                    withStyle(
                        SpanStyle(
                            color = if (idx == 0) slashColor else textColor,
                            fontWeight = if (idx == 0) FontWeight.ExtraBold else FontWeight.SemiBold
                        )
                    ) {
                        append(part)
                    }
                    if (idx < cleanItems.lastIndex) {
                        withStyle(
                            SpanStyle(
                                color = slashColor.copy(alpha = 0.65f),
                                fontWeight = FontWeight.Black
                            )
                        ) {
                            append("  /  ")
                        }
                    }
                }
            }
        }
        Text(
            text = annotated,
            fontSize = fontSizeSp.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
        )
    } else {
        Row(
            modifier = modifier,
            verticalAlignment = Alignment.CenterVertically
        ) {
            cleanItems.forEachIndexed { idx, part ->
                Text(
                    text = part,
                    color = if (idx == 0) slashColor else textColor,
                    fontWeight = if (idx == 0) FontWeight.ExtraBold else FontWeight.SemiBold,
                    fontSize = fontSizeSp.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable { onItemClick(idx, part) }
                )
                if (idx < cleanItems.lastIndex) {
                    Text(
                        text = "  /  ",
                        color = slashColor.copy(alpha = 0.65f),
                        fontWeight = FontWeight.Black,
                        fontSize = fontSizeSp.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AnimatedPurchaseButton(
    text: String,
    icon: ImageVector? = Icons.Filled.ShoppingCart,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null
) {
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    var flashActive by remember { mutableStateOf(false) }

    val filledState = isPressed || flashActive

    val bgColor by animateColorAsState(
        targetValue = if (filledState) primaryColor else primaryColor.copy(alpha = 0.06f),
        animationSpec = tween(durationMillis = 150),
        label = "btnBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (filledState) Color.White else primaryColor,
        animationSpec = tween(durationMillis = 150),
        label = "btnContent"
    )
    val scale by animateFloatAsState(
        targetValue = if (filledState) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "btnScale"
    )

    val taggedModifier = if (testTag != null) modifier.testTag(testTag) else modifier

    Surface(
        onClick = {
            performCrispHaptic(view, HapticStyle.CONFIRM)
            scope.launch {
                flashActive = true
                onClick()
                delay(200L)
                flashActive = false
            }
        },
        interactionSource = interactionSource,
        shape = RoundedCornerShape(999.dp),
        color = bgColor,
        border = BorderStroke(1.8.dp, primaryColor),
        modifier = taggedModifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ShimmerSkeletonBox(
    darkMode: Boolean,
    cornerRadius: Dp = 16.dp,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = -320f,
        targetValue = 920f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerTranslate"
    )

    val baseColor = if (darkMode) Color(0xFF162032) else Color(0xFFE2E8F0)
    val midColor = if (darkMode) Color(0xFF1E293B) else Color(0xFFEEF2F6)
    val highlightColor = if (darkMode) Color(0xFF334155) else Color(0xFFFFFFFF)

    val brush = Brush.linearGradient(
        colorStops = arrayOf(
            0.0f to baseColor,
            0.35f to midColor,
            0.50f to highlightColor,
            0.65f to midColor,
            1.0f to baseColor
        ),
        start = Offset(translateAnim, 0f),
        end = Offset(translateAnim + 260f, 160f)
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(brush)
    )
}

private data class SparkleStarSpec(
    val xFraction: Float,
    val yFraction: Float,
    val baseRadiusDp: Float,
    val phaseOffset: Float,
    val isWarmGold: Boolean
)

// Posiciones orbitales de las estrellas alrededor del emblema central
// Distribuidas en el anillo exterior para no solaparse con el icono
private val STARTUP_SPARKLE_STARS = listOf(
    SparkleStarSpec(0.20f, 0.14f, 10.5f, 0.00f, true),
    SparkleStarSpec(0.50f, 0.08f, 8.5f, 0.14f, false),
    SparkleStarSpec(0.80f, 0.15f, 11.0f, 0.28f, true),
    SparkleStarSpec(0.90f, 0.44f, 9.0f, 0.42f, false),
    SparkleStarSpec(0.82f, 0.79f, 10.0f, 0.56f, true),
    SparkleStarSpec(0.50f, 0.91f, 8.0f, 0.70f, false),
    SparkleStarSpec(0.18f, 0.80f, 10.5f, 0.84f, true),
    SparkleStarSpec(0.10f, 0.46f, 9.0f, 0.92f, true)
)

@Composable
fun AppStartupSkeletonScreen(
    darkMode: Boolean,
    isArca: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "startup_sparkle_transition")
    val masterPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "masterPhase"
    )
    val emblemScale by infiniteTransition.animateFloat(
        initialValue = 0.985f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "emblemScale"
    )
    val haloScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "haloScale"
    )
    val emblemSheenOffset by infiniteTransition.animateFloat(
        initialValue = -1.2f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "emblemSheenOffset"
    )
    val progressSweep by infiniteTransition.animateFloat(
        initialValue = 0.18f,
        targetValue = 0.96f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "progressSweep"
    )

    val brandColor = if (isArca) ArcaTeal else Color(0xFFFE0116)
    val bgTop = if (darkMode) Color(0xFF060911) else Color(0xFFFFF5F5)
    val bgBottom = if (darkMode) Color(0xFF0E1626) else Color(0xFFFFFBEB)
    val primaryTextColor = if (darkMode) Color(0xFFF8FAFC) else Color(0xFF1E293B)
    val secondaryTextColor = if (darkMode) Color(0xFF94A3B8) else Color(0xFF64748B)
    val emblemSurfaceColor = if (darkMode) Color(0xFF151F32) else Color(0xFFFE0116)
    val starPath = remember { Path() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(bgTop, bgBottom)))
            .testTag("startup_skeleton_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Luz ambiental de fondo
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        brandColor.copy(alpha = if (darkMode) 0.22f else 0.16f),
                        brandColor.copy(alpha = if (darkMode) 0.08f else 0.05f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.5f, size.height * 0.40f),
                    radius = size.minDimension * 0.64f
                ),
                radius = size.minDimension * 0.64f,
                center = Offset(size.width * 0.5f, size.height * 0.40f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        BravoAmber.copy(alpha = if (darkMode) 0.14f else 0.12f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.38f, size.height * 0.35f),
                    radius = size.minDimension * 0.46f
                ),
                radius = size.minDimension * 0.46f,
                center = Offset(size.width * 0.38f, size.height * 0.35f)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                // Halo radial y destellos orbitales en un solo pase de Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val center = Offset(w * 0.5f, h * 0.5f)
                    val haloRadius = (w * 0.44f) * haloScale

                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0.0f to brandColor.copy(alpha = if (darkMode) 0.38f else 0.32f),
                                0.52f to BravoAmber.copy(alpha = if (darkMode) 0.18f else 0.16f),
                                0.82f to brandColor.copy(alpha = if (darkMode) 0.05f else 0.04f),
                                1.0f to Color.Transparent
                            ),
                            center = center,
                            radius = haloRadius
                        ),
                        radius = haloRadius,
                        center = center
                    )

                    STARTUP_SPARKLE_STARS.forEach { star ->
                        val angle = masterPhase + star.phaseOffset * (2f * PI).toFloat()
                        val rawWave = ((sin(angle) + 1f) * 0.5f).coerceIn(0f, 1f)
                        // Suavizado smoothstep para el parpadeo
                        val twinkle = rawWave * rawWave * (3f - 2f * rawWave)
                        val scaleFactor = 0.52f + 0.48f * twinkle

                        // Desplazamiento orbital sutil
                        val driftPx = 1.5.dp.toPx()
                        val cx = w * star.xFraction + cos(angle) * driftPx
                        val cy = h * star.yFraction + sin(angle) * driftPx
                        val r = star.baseRadiusDp.dp.toPx() * scaleFactor
                        val waist = r * 0.26f

                        val fillAlpha = (0.38f + 0.62f * twinkle).coerceIn(0f, 1f)
                        val starColor = if (star.isWarmGold) {
                            Color(0xFFFFB800).copy(alpha = fillAlpha)
                        } else {
                            if (darkMode) {
                                Color(0xFFFFF7D6).copy(alpha = fillAlpha)
                            } else {
                                Color(0xFFFF9800).copy(alpha = fillAlpha)
                            }
                        }
                        val rimColor = if (darkMode) {
                            Color.White.copy(alpha = (0.45f + 0.50f * twinkle).coerceIn(0f, 1f))
                        } else {
                            Color(0xFFD97706).copy(alpha = (0.35f + 0.45f * twinkle).coerceIn(0f, 1f))
                        }

                        // Halo individual de cada estrella
                        drawCircle(
                            brush = Brush.radialGradient(
                                colorStops = arrayOf(
                                    0.0f to starColor.copy(alpha = 0.36f * twinkle),
                                    0.65f to starColor.copy(alpha = 0.10f * twinkle),
                                    1.0f to Color.Transparent
                                ),
                                center = Offset(cx, cy),
                                radius = r * 1.15f
                            ),
                            radius = r * 1.15f,
                            center = Offset(cx, cy)
                        )

                        // Silueta de estrella de 4 puntas
                        starPath.reset()
                        starPath.moveTo(cx, cy - r)
                        starPath.quadraticTo(cx + waist, cy - waist, cx + r, cy)
                        starPath.quadraticTo(cx + waist, cy + waist, cx, cy + r)
                        starPath.quadraticTo(cx - waist, cy + waist, cx - r, cy)
                        starPath.quadraticTo(cx - waist, cy - waist, cx, cy - r)
                        starPath.close()

                        drawPath(path = starPath, color = starColor)
                        drawPath(
                            path = starPath,
                            color = rimColor,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(
                                width = 1.dp.toPx(),
                                join = androidx.compose.ui.graphics.StrokeJoin.Round
                            )
                        )

                        // Núcleo luminoso central
                        drawCircle(
                            color = Color.White.copy(alpha = (0.75f + 0.25f * twinkle).coerceIn(0f, 1f)),
                            radius = max(1.4f, r * 0.20f),
                            center = Offset(cx, cy)
                        )
                    }
                }

                // Emblema central con barrido de brillo
                Box(
                    modifier = Modifier
                        .size(138.dp)
                        .graphicsLayer {
                            scaleX = emblemScale
                            scaleY = emblemScale
                        }
                        .shadow(
                            elevation = 20.dp,
                            shape = RoundedCornerShape(38.dp),
                            spotColor = brandColor.copy(alpha = 0.45f)
                        )
                        .clip(RoundedCornerShape(38.dp))
                        .background(emblemSurfaceColor)
                        .border(
                            width = 2.5.dp,
                            brush = Brush.linearGradient(
                                colors = if (darkMode) {
                                    listOf(
                                        brandColor.copy(alpha = 0.90f),
                                        BravoAmber.copy(alpha = 0.72f),
                                        Color.White.copy(alpha = 0.32f)
                                    )
                                } else {
                                    listOf(
                                        Color.White.copy(alpha = 0.92f),
                                        BravoAmber.copy(alpha = 0.78f),
                                        Color.White.copy(alpha = 0.42f)
                                    )
                                }
                            ),
                            shape = RoundedCornerShape(38.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_art),
                        contentDescription = "Icono Oficial BravoVa",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Reflejo diagonal dentro de los bordes del emblema
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val startX = w * emblemSheenOffset
                        drawRect(
                            brush = Brush.linearGradient(
                                colorStops = arrayOf(
                                    0.0f to Color.Transparent,
                                    0.45f to Color.White.copy(alpha = 0.18f),
                                    0.55f to Color.White.copy(alpha = 0.06f),
                                    1.0f to Color.Transparent
                                ),
                                start = Offset(startX, 0f),
                                end = Offset(startX + w * 0.55f, h)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            BravoOfficialLogoBadge(scale = 1.28f)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Los expertos en vender barato",
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp,
                letterSpacing = 0.3.sp,
                color = primaryTextColor
            )

            Spacer(modifier = Modifier.height(22.dp))

            TranslucentCard(
                darkMode = darkMode,
                isArca = isArca,
                cornerRadius = 999.dp,
                modifier = Modifier.width(256.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { progressSweep },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(CircleShape),
                        color = brandColor,
                        trackColor = brandColor.copy(alpha = if (darkMode) 0.24f else 0.16f)
                    )
                    Text(
                        text = "Cargando catálogo, precios e imágenes...",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = secondaryTextColor
                    )
                }
            }
        }
    }
}

@Composable
fun BravoUnderline(isArca: Boolean, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val brush = if (isArca) {
        Brush.horizontalGradient(listOf(ArcaEmerald, ArcaTeal))
    } else {
        Brush.horizontalGradient(listOf(BravoAmber, BravoRed, primary))
    }
    Box(
        modifier = modifier
            .padding(top = 3.dp)
            .width(46.dp)
            .height(3.5.dp)
            .clip(CircleShape)
            .background(brush)
    )
}

private object TransparentLogoCache {
    private val cache = LruCache<Int, ImageBitmap>(8)

    fun getOrLoad(context: android.content.Context, resId: Int): ImageBitmap? {
        cache.get(resId)?.let { return it }
        return try {
            val raw = BitmapFactory.decodeResource(context.resources, resId) ?: return null
            val bmp = raw.copy(Bitmap.Config.ARGB_8888, true)
            val w = bmp.width
            val h = bmp.height
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            for (i in pixels.indices) {
                val px = pixels[i]
                val a = (px ushr 24) and 0xFF
                if (a == 0) continue
                val r = (px ushr 16) and 0xFF
                val g = (px ushr 8) and 0xFF
                val b = px and 0xFF
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                // Elimina el fondo blanco de los logos para integrarlos sobre superficies translúcidas
                if (r >= 235 && g >= 235 && b >= 235 && (maxC - minC) <= 20) {
                    pixels[i] = 0x00000000
                } else if (r >= 218 && g >= 218 && b >= 218 && (maxC - minC) <= 24) {
                    val fadedAlpha = ((240 - ((r + g + b) / 3)).coerceIn(0, 255) * a) / 255
                    pixels[i] = (fadedAlpha shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            bmp.setPixels(pixels, 0, w, 0, 0, w, h)
            val img = bmp.asImageBitmap()
            cache.put(resId, img)
            img
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun BravoOfficialLogoBadge(scale: Float = 1f) {
    val context = LocalContext.current
    val cutoutBitmap = remember(context) {
        TransparentLogoCache.getOrLoad(context, R.drawable.logo_bravo_official)
    }
    if (cutoutBitmap != null) {
        Image(
            bitmap = cutoutBitmap,
            contentDescription = "Logo Oficial Supermercados Bravo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .height((31f * scale).dp)
                .width((118f * scale).dp)
        )
    } else {
        Image(
            painter = painterResource(id = R.drawable.logo_bravo_official),
            contentDescription = "Logo Oficial Supermercados Bravo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .height((31f * scale).dp)
                .width((118f * scale).dp)
        )
    }
}

@Composable
fun ArcaOfficialLogoBadge(scale: Float = 1f) {
    val context = LocalContext.current
    val cutoutBitmap = remember(context) {
        TransparentLogoCache.getOrLoad(context, R.drawable.logo_arca_official)
    }
    if (cutoutBitmap != null) {
        Image(
            bitmap = cutoutBitmap,
            contentDescription = "Logo Oficial El Arca Petshop",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .height((34f * scale).dp)
                .width((80f * scale).dp)
        )
    } else {
        Image(
            painter = painterResource(id = R.drawable.logo_arca_official),
            contentDescription = "Logo Oficial El Arca Petshop",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .height((34f * scale).dp)
                .width((80f * scale).dp)
        )
    }
}

@Composable
fun BravoArcaHeaderSwitcher(
    activeStore: StoreMode,
    darkMode: Boolean,
    onSelectStore: (StoreMode) -> Unit,
    expanded: Boolean? = null,
    onExpandedChange: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    var internalExpanded by remember { mutableStateOf(false) }
    val isExpanded = expanded ?: internalExpanded
    val setExpanded: (Boolean) -> Unit = { next ->
        if (onExpandedChange != null) {
            onExpandedChange(next)
        } else {
            internalExpanded = next
        }
    }
    val isArca = activeStore == StoreMode.ARCA
    val accent = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val borderCol = if (isArca) {
        Color(0xFFA3B108).copy(alpha = 0.45f)
    } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
    }

    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable {
                    HapticFeedbackManager.onNavigationClick(view)
                    setExpanded(!isExpanded)
                }
                .padding(horizontal = 4.dp, vertical = 4.dp)
                .testTag("brand_switcher_button"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = activeStore,
                transitionSpec = {
                    val toArca = targetState == StoreMode.ARCA
                    val slideOffset = if (toArca) 36 else -36
                    (androidx.compose.animation.fadeIn(animationSpec = tween(280, easing = FastOutSlowInEasing)) +
                        androidx.compose.animation.scaleIn(initialScale = 0.88f, animationSpec = tween(280, easing = FastOutSlowInEasing)) +
                        androidx.compose.animation.slideInHorizontally(animationSpec = tween(280, easing = FastOutSlowInEasing)) { slideOffset })
                        .togetherWith(
                            androidx.compose.animation.fadeOut(animationSpec = tween(190)) +
                                androidx.compose.animation.scaleOut(targetScale = 0.90f, animationSpec = tween(190))
                        )
                },
                label = "header_brand_logo_morph"
            ) { mode ->
                if (mode == StoreMode.BRAVO) {
                    BravoOfficialLogoBadge(scale = 0.98f)
                } else {
                    ArcaOfficialLogoBadge(scale = 1.02f)
                }
            }
            Icon(
                imageVector = if (isExpanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = "Cambiar tienda",
                tint = if (isArca) Color(0xFF6B7800) else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        if (onExpandedChange == null) {
            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = { setExpanded(false) },
                shape = RoundedCornerShape(22.dp),
                containerColor = uniformMenuTranslucentContainerColor(darkMode),
                tonalElevation = 8.dp,
                shadowElevation = 16.dp,
                border = BorderStroke(1.1.dp, uniformMenuTranslucentBorderBrush(accent, darkMode)),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                BravoArcaSelectorMenuContent(
                    activeStore = activeStore,
                    borderCol = borderCol,
                    onSelectStore = { mode ->
                        setExpanded(false)
                        onSelectStore(mode)
                    }
                )
            }
        }
    }
}

@Composable
private fun BravoArcaSelectorMenuContent(
    activeStore: StoreMode,
    borderCol: Color,
    onSelectStore: (StoreMode) -> Unit
) {
    val view = LocalView.current
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "CAMBIAR DE TIENDA",
            fontFamily = PlusJakartaSans,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 10.sp,
            letterSpacing = 0.8.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        Surface(
            onClick = {
                HapticFeedbackManager.onConfirmAction(view)
                onSelectStore(StoreMode.BRAVO)
            },
            shape = RoundedCornerShape(16.dp),
            color = if (activeStore == StoreMode.BRAVO) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
            } else {
                Color.Transparent
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("switch_to_bravo")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BravoOfficialLogoBadge(scale = 0.92f)
                    Column {
                        Text(
                            text = "Supermercados Bravo",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Los expertos en vender barato",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                if (activeStore == StoreMode.BRAVO) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Activo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 4.dp),
            color = borderCol.copy(alpha = 0.4f)
        )

        Surface(
            onClick = {
                HapticFeedbackManager.onConfirmAction(view)
                onSelectStore(StoreMode.ARCA)
            },
            shape = RoundedCornerShape(16.dp),
            color = if (activeStore == StoreMode.ARCA) {
                ArcaTeal.copy(alpha = 0.16f)
            } else {
                Color.Transparent
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("switch_to_arca")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ArcaOfficialLogoBadge(scale = 0.98f)
                    Column {
                        Text(
                            text = "El Arca Petshop",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Nutrición & Cuidado Mascotas",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                if (activeStore == StoreMode.ARCA) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Activo",
                        tint = ArcaTeal,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BravoArcaSelectorMenuOverlay(
    expanded: Boolean,
    activeStore: StoreMode,
    darkMode: Boolean,
    menuHazeState: HazeState?,
    onDismiss: () -> Unit,
    onSelectStore: (StoreMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val isArca = activeStore == StoreMode.ARCA
    val accent = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val borderCol = if (isArca) {
        Color(0xFFA3B108).copy(alpha = 0.45f)
    } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
    }
    val shape = RoundedCornerShape(22.dp)
    val borderBrush = uniformMenuTranslucentBorderBrush(accent, darkMode)
    val sheenBrush = uniformMenuTranslucentSheenBrush(darkMode, accent)
    val useRealHaze = expanded && menuHazeState != null && DeviceSupportsGpuBlur
    val containerCol = if (useRealHaze) Color.Transparent else uniformMenuTranslucentContainerColor(darkMode)

    androidx.compose.animation.AnimatedVisibility(
        visible = expanded,
        enter = androidx.compose.animation.fadeIn(animationSpec = tween(180)) +
            androidx.compose.animation.scaleIn(
                initialScale = 0.94f,
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ),
        exit = androidx.compose.animation.fadeOut(animationSpec = tween(150)) +
            androidx.compose.animation.scaleOut(
                targetScale = 0.94f,
                animationSpec = tween(150)
            ),
        modifier = modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Área táctil exterior para cerrar el selector al tocar fuera
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )

            Surface(
                modifier = Modifier
                    .padding(start = 14.dp, top = 46.dp)
                    .width(296.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = shape,
                        spotColor = accent.copy(alpha = 0.28f)
                    )
                    .clip(shape)
                    .translucentBackdropEffect(
                        darkMode = darkMode,
                        accentColor = accent,
                        hazeState = menuHazeState,
                        enabled = useRealHaze
                    )
                    .testTag("brand_switcher_menu_surface"),
                shape = shape,
                color = containerCol,
                border = BorderStroke(1.2.dp, borderBrush)
            ) {
                Box(
                    modifier = Modifier
                        .background(uniformMenuTranslucentGlowBrush(accent, darkMode))
                        .background(sheenBrush)
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    BravoArcaSelectorMenuContent(
                        activeStore = activeStore,
                        borderCol = borderCol,
                        onSelectStore = { mode ->
                            onDismiss()
                            onSelectStore(mode)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FloatingHeaderCapsule(
    darkMode: Boolean,
    modifier: Modifier = Modifier,
    enableHazeBlur: Boolean = true,
    content: @Composable () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val useRealHaze = enableHazeBlur && LocalTranslucentHazeState.current != null && DeviceSupportsGpuBlur
    val containerColor = if (useRealHaze) Color.Transparent else uniformMenuTranslucentContainerColor(darkMode)
    val borderBrush = uniformMenuTranslucentBorderBrush(primary, darkMode)
    val sheenBrush = uniformMenuTranslucentSheenBrush(darkMode, primary)
    val shape = RoundedCornerShape(24.dp)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 10.dp,
                    shape = shape,
                    spotColor = primary.copy(alpha = 0.22f)
                )
                .clip(shape)
                .translucentBackdropEffect(
                    darkMode = darkMode,
                    accentColor = primary,
                    enabled = useRealHaze
                ),
            shape = shape,
            color = containerColor,
            border = BorderStroke(
                width = 1.15.dp,
                brush = borderBrush
            )
        ) {
            Box(
                modifier = Modifier
                    .background(uniformMenuTranslucentGlowBrush(primary, darkMode))
                    .background(sheenBrush)
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
fun TranslucentCard(
    darkMode: Boolean,
    isArca: Boolean = false,
    cornerRadius: Dp = 22.dp,
    modifier: Modifier = Modifier,
    enableHazeBlur: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    val primary = MaterialTheme.colorScheme.primary
    val accent = if (isArca) ArcaTeal else primary
    val useRealHaze = enableHazeBlur && LocalTranslucentHazeState.current != null && DeviceSupportsGpuBlur

    val bg = if (useRealHaze) Color.Transparent else uniformInlineTranslucentCardColor(darkMode)
    val borderBrush = uniformMenuTranslucentBorderBrush(accent, darkMode)
    val spot = accent.copy(alpha = if (darkMode) 0.18f else 0.16f)
    val translucentSheen = uniformMenuTranslucentSheenBrush(darkMode, accent)
    val shape = RoundedCornerShape(cornerRadius)

    val cardModifier = modifier
        .shadow(
            elevation = if (darkMode) 6.dp else 7.dp,
            shape = shape,
            spotColor = spot
        )
        .clip(shape)
        .translucentBackdropEffect(
            darkMode = darkMode,
            accentColor = accent,
            enabled = useRealHaze
        )

    if (onClick != null) {
        Card(
            onClick = {
                performCrispHaptic(view, HapticStyle.TICK)
                onClick()
            },
            modifier = cardModifier,
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = bg),
            border = BorderStroke(1.15.dp, borderBrush)
        ) {
            Box(
                modifier = Modifier
                    .background(uniformMenuTranslucentGlowBrush(accent, darkMode))
                    .background(translucentSheen)
            ) {
                content()
            }
        }
    } else {
        Card(
            modifier = cardModifier,
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = bg),
            border = BorderStroke(1.15.dp, borderBrush)
        ) {
            Box(
                modifier = Modifier
                    .background(uniformMenuTranslucentGlowBrush(accent, darkMode))
                    .background(translucentSheen)
            ) {
                content()
            }
        }
    }
}

object StudioCutoutCenterTransformation : Transformation {
    override val cacheKey: String = "studio_cutout_center_v3"

    private val cutoutMemoryCache = object : LruCache<Int, Bitmap>(72) {}

    override suspend fun transform(input: Bitmap, size: CoilSize): Bitmap {
        val cx = input.width / 2
        val cy = input.height / 2
        val qx = (input.width / 4).coerceAtLeast(1)
        val qy = (input.height / 4).coerceAtLeast(1)
        val signature = (((((input.width * 31 + input.height) * 31 +
            input.getPixel(cx, cy)) * 31 +
            input.getPixel(qx, qy)) * 31 +
            input.getPixel(input.width - qx - 1, qy)) * 31 +
            input.getPixel(qx, input.height - qy - 1))
        cutoutMemoryCache.get(signature)?.let { cached ->
            if (!cached.isRecycled) return cached
        }
        val src = input.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        if (w <= 4 || h <= 4) return src

        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        var transparentBorderCount = 0
        var borderSampleCount = 0
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var lightBorderCount = 0

        fun sampleBorderPixel(px: Int) {
            borderSampleCount++
            val a = (px ushr 24) and 0xFF
            if (a < 180) {
                transparentBorderCount++
                return
            }
            val r = (px ushr 16) and 0xFF
            val g = (px ushr 8) and 0xFF
            val b = px and 0xFF
            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            if (r >= 172 && g >= 168 && b >= 160 && (maxC - minC) <= 52) {
                lightBorderCount++
                sumR += r
                sumG += g
                sumB += b
            }
        }

        for (x in 0 until w) {
            sampleBorderPixel(pixels[x])
            sampleBorderPixel(pixels[(h - 1) * w + x])
        }
        for (y in 1 until h - 1) {
            sampleBorderPixel(pixels[y * w])
            sampleBorderPixel(pixels[y * w + (w - 1)])
        }

        val alreadyTransparent = transparentBorderCount > (borderSampleCount / 4)

        if (!alreadyTransparent && lightBorderCount > (borderSampleCount / 5)) {
            val bgR = (sumR / lightBorderCount).toInt()
            val bgG = (sumG / lightBorderCount).toInt()
            val bgB = (sumB / lightBorderCount).toInt()

            val visited = BooleanArray(w * h)
            val queue = IntArray(w * h)
            var head = 0
            var tail = 0

            fun isBackgroundCandidate(idx: Int): Boolean {
                val px = pixels[idx]
                val a = (px ushr 24) and 0xFF
                if (a < 32) return true
                val r = (px ushr 16) and 0xFF
                val g = (px ushr 8) and 0xFF
                val b = px and 0xFF
                val diff = abs(r - bgR) + abs(g - bgG) + abs(b - bgB)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val isNearWhite = r >= 215 && g >= 215 && b >= 210 && (maxC - minC) <= 36
                return diff <= 92 || isNearWhite
            }

            fun enqueueIfBg(x: Int, y: Int) {
                val idx = y * w + x
                if (!visited[idx] && isBackgroundCandidate(idx)) {
                    visited[idx] = true
                    queue[tail++] = idx
                }
            }

            for (x in 0 until w) {
                enqueueIfBg(x, 0)
                enqueueIfBg(x, h - 1)
            }
            for (y in 1 until h - 1) {
                enqueueIfBg(0, y)
                enqueueIfBg(w - 1, y)
            }

            while (head < tail) {
                val idx = queue[head++]
                pixels[idx] = 0x00000000
                val x = idx % w
                val y = idx / w
                if (x > 0) enqueueIfBg(x - 1, y)
                if (x + 1 < w) enqueueIfBg(x + 1, y)
                if (y > 0) enqueueIfBg(x, y - 1)
                if (y + 1 < h) enqueueIfBg(x, y + 1)
            }

            // Suaviza los bordes adyacentes al fondo recortado
            for (y in 1 until h - 1) {
                val rowOffset = y * w
                for (x in 1 until w - 1) {
                    val idx = rowOffset + x
                    if (visited[idx]) continue
                    val touchesBg =
                        visited[idx - 1] || visited[idx + 1] || visited[idx - w] || visited[idx + w]
                    if (touchesBg) {
                        val px = pixels[idx]
                        val r = (px ushr 16) and 0xFF
                        val g = (px ushr 8) and 0xFF
                        val b = px and 0xFF
                        val diff = abs(r - bgR) + abs(g - bgG) + abs(b - bgB)
                        if (diff < 115) {
                            val newAlpha = ((diff * 255) / 115).coerceIn(40, 230)
                            pixels[idx] = (newAlpha shl 24) or (px and 0x00FFFFFF)
                        }
                    }
                }
            }
        }

        // Calcula los límites del producto para centrarlo en la miniatura
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1

        for (y in 0 until h) {
            val rowOffset = y * w
            for (x in 0 until w) {
                val a = (pixels[rowOffset + x] ushr 24) and 0xFF
                if (a > 24) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        src.setPixels(pixels, 0, w, 0, 0, w, h)

        if (maxX <= minX || maxY <= minY) {
            return src
        }

        val contentW = maxX - minX + 1
        val contentH = maxY - minY + 1
        val targetSide = max(w, h).coerceIn(240, 420)
        val outBitmap = Bitmap.createBitmap(targetSide, targetSide, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(outBitmap)

        val padFraction = 0.06f
        val availableSide = targetSide * (1f - padFraction * 2f)
        val scale = min(availableSide / contentW.toFloat(), availableSide / contentH.toFloat())
        val drawW = contentW * scale
        val drawH = contentH * scale
        val left = (targetSide - drawW) / 2f
        val top = (targetSide - drawH) / 2f

        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG or AndroidPaint.FILTER_BITMAP_FLAG)
        val srcRect = Rect(minX, minY, maxX + 1, maxY + 1)
        val dstRect = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(src, srcRect, dstRect, paint)

        cutoutMemoryCache.put(signature, outBitmap)
        return outBitmap
    }
}

@Composable
fun ProductArtworkView(
    product: Product,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val accent = remember(product.colorHex) { parseHexColor(product.colorHex) }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        if (!product.imageUrl.isNullOrBlank()) {
            val imageRequest = remember(product.imageUrl, context) {
                ImageRequest.Builder(context)
                    .data(product.imageUrl)
                    .allowHardware(false)
                    .transformations(StudioCutoutCenterTransformation)
                    .crossfade(180)
                    .build()
            }
            SubcomposeAsyncImage(
                model = imageRequest,
                contentDescription = product.name,
                contentScale = ContentScale.Fit,
                alignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(2.dp),
                loading = {
                    ShimmerSkeletonBox(
                        darkMode = false,
                        cornerRadius = 12.dp,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    )
                },
                error = {
                    ProductVectorIllustration(product = product, accentColor = accent)
                }
            )
        } else {
            ProductVectorIllustration(product = product, accentColor = accent)
        }
    }
}

@Composable
fun ProductVectorIllustration(
    product: Product,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(6.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            when (product.artType) {
                "salami" -> {
                    drawRoundRect(
                        color = accentColor,
                        topLeft = Offset(w * 0.14f, h * 0.28f),
                        size = Size(w * 0.72f, h * 0.44f),
                        cornerRadius = CornerRadius(h * 0.22f, h * 0.22f)
                    )
                    drawRect(
                        color = Color(0xFFD4AF37),
                        topLeft = Offset(w * 0.36f, h * 0.28f),
                        size = Size(w * 0.28f, h * 0.44f)
                    )
                }
                "jug" -> {
                    drawRoundRect(
                        color = accentColor,
                        topLeft = Offset(w * 0.26f, h * 0.16f),
                        size = Size(w * 0.48f, h * 0.68f),
                        cornerRadius = CornerRadius(14f, 14f)
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.92f),
                        topLeft = Offset(w * 0.31f, h * 0.36f),
                        size = Size(w * 0.38f, h * 0.32f),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                }
                else -> {
                    drawRoundRect(
                        color = accentColor,
                        topLeft = Offset(w * 0.20f, h * 0.15f),
                        size = Size(w * 0.60f, h * 0.70f),
                        cornerRadius = CornerRadius(18f, 18f)
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.92f),
                        topLeft = Offset(w * 0.26f, h * 0.32f),
                        size = Size(w * 0.48f, h * 0.36f),
                        cornerRadius = CornerRadius(10f, 10f)
                    )
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (product.isBravo) "b" else "★",
                color = accentColor,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
            )
            Text(
                text = product.badge,
                color = Color(0xFF0F172A),
                fontWeight = FontWeight.Black,
                fontSize = 7.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
fun VerticalProductCard(
    product: Product,
    qtyInCart: Int,
    isArca: Boolean,
    darkMode: Boolean,
    onOpenDetail: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    modifier: Modifier = Modifier,
    isFavorite: Boolean = false,
    onToggleFavorite: (() -> Unit)? = null
) {
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val brandAccent = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val itemSubtotal = qtyInCart * product.price
    val buttonPulse = remember { Animatable(1f) }
    val cardInteraction = remember { MutableInteractionSource() }
    val isCardPressed by cardInteraction.collectIsPressedAsState()
    val cardPressScale by animateFloatAsState(
        targetValue = if (isCardPressed) 0.97f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardPressScale"
    )
    val favScale by animateFloatAsState(
        targetValue = if (isFavorite) 1.16f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "favScale"
    )

    TranslucentCard(
        darkMode = darkMode,
        isArca = isArca,
        cornerRadius = 18.dp,
        modifier = modifier
            .height(218.dp)
            .graphicsLayer {
                scaleX = cardPressScale
                scaleY = cardPressScale
            }
            .clipToBounds()
            .testTag("product_card_${product.sku}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = cardInteraction,
                        indication = null
                    ) {
                        performCrispHaptic(view, HapticStyle.TICK)
                        onOpenDetail()
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val tagLeft = remember(product.isBravo, product.badge, isArca) {
                        if (product.isBravo) {
                            if (isArca) "ARCA" else "BRAVO"
                        } else {
                            product.badge.ifBlank { "MARCA" }.take(7)
                        }
                    }
                    DiagonalMetadataStrip(
                        items = listOf(tagLeft, product.unit),
                        slashColor = brandAccent,
                        fontSizeSp = 8f,
                        modifier = Modifier.weight(1f)
                    )

                    if (onToggleFavorite != null) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favorito",
                            tint = if (isFavorite) brandAccent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                            modifier = Modifier
                                .size(16.dp)
                                .graphicsLayer {
                                    scaleX = favScale
                                    scaleY = favScale
                                }
                                .clickable {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onToggleFavorite()
                                }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(74.dp)
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ProductArtworkView(
                        product = product,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(5.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(30.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = product.name,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp,
                        lineHeight = 13.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clipToBounds()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(30.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "RD$ ${product.price}",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 2.dp)
                    )

                    if (qtyInCart > 0) {
                        Row(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(brandAccent.copy(alpha = 0.10f))
                                .border(1.dp, brandAccent.copy(alpha = 0.4f), CircleShape)
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(if (darkMode) Color(0xFF0F172A) else Color.White)
                                    .clickable {
                                        HapticFeedbackManager.onDecrementOrRemove(view, isFullRemove = qtyInCart <= 1)
                                        onDecrement()
                                    }
                                    .testTag("minus_${product.sku}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Remove,
                                    contentDescription = "Restar uno",
                                    tint = brandAccent,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                            Text(
                                text = qtyInCart.toString(),
                                color = brandAccent,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 2.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .graphicsLayer {
                                        scaleX = buttonPulse.value
                                        scaleY = buttonPulse.value
                                    }
                                    .clip(CircleShape)
                                    .background(brandAccent)
                                    .clickable {
                                        HapticFeedbackManager.onAddToCart(view)
                                        onIncrement()
                                        scope.launch {
                                            buttonPulse.snapTo(1.22f)
                                            buttonPulse.animateTo(
                                                targetValue = 1f,
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                                    stiffness = Spring.StiffnessMedium
                                                )
                                            )
                                        }
                                    }
                                    .testTag("plus_${product.sku}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Agregar otro",
                                    tint = Color.White,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(25.dp)
                                .graphicsLayer {
                                    scaleX = buttonPulse.value
                                    scaleY = buttonPulse.value
                                }
                                .clip(CircleShape)
                                .background(if (darkMode) Color(0xFF1E293B) else Color.White)
                                .border(1.4.dp, brandAccent, CircleShape)
                                .clickable {
                                    HapticFeedbackManager.onAddToCart(view)
                                    onIncrement()
                                    scope.launch {
                                        buttonPulse.snapTo(1.22f)
                                        buttonPulse.animateTo(
                                            targetValue = 1f,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMedium
                                            )
                                        )
                                    }
                                }
                                .testTag("add_${product.sku}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "Agregar al carrito",
                                tint = brandAccent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 2.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                )

                if (qtyInCart > 0) {
                    DiagonalMetadataStrip(
                        items = listOf("${qtyInCart}x en carrito", "RD$ $itemSubtotal"),
                        slashColor = brandAccent,
                        fontSizeSp = 8f,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    val shortCat = remember(product.category) {
                        when (product.category.lowercase()) {
                            "productos nuevos" -> "Novedad"
                            "aceite y vinagres" -> "Aceites"
                            "agua y refrescos" -> "Bebidas"
                            "alimentación general" -> "Despensa"
                            "carne res y cerdo" -> "Carnes"
                            "frutas y vegetales" -> "Frescos"
                            "lácteos y huevos" -> "Lácteos"
                            "panes y galletas" -> "Panadería"
                            "hogar y limpieza" -> "Hogar"
                            "alimentos secos" -> "Croquetas"
                            "alimentos húmedos y snacks" -> "Snacks"
                            "salud y cuidado veterinario" -> "Salud Pet"
                            "hogar y arena sanitaria" -> "Higiene"
                            "accesorios y paseo" -> "Paseo"
                            "juguetes y confort" -> "Confort"
                            else -> product.category
                        }
                    }
                    DiagonalMetadataStrip(
                        items = listOf(shortCat, "Disponible"),
                        slashColor = Color(0xFF10B981),
                        fontSizeSp = 8f,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun SectionLineIcon(iconType: String, isArca: Boolean) {
    val vectorIcon: ImageVector = when (iconType) {
        "new_badge" -> Icons.Filled.NewReleases
        "oil_bottle" -> Icons.Filled.WaterDrop
        "water_soda" -> Icons.Filled.LocalDrink
        "plate_cutlery" -> Icons.Filled.Restaurant
        "baby_bottle" -> Icons.Filled.LocalDrink
        "wine_glass" -> Icons.Filled.LocalBar
        "cow_meat" -> Icons.Filled.LocalDining
        "salami_deli" -> Icons.Filled.Kitchen
        "fresh_produce" -> Icons.Filled.Eco
        "cleaning_spray" -> Icons.Filled.CleaningServices
        "milk_cheese" -> Icons.Filled.Egg
        "bakery_bread" -> Icons.Filled.BakeryDining
        "kibble_bag" -> Icons.Filled.Pets
        "wet_food" -> Icons.Filled.Inventory2
        "vet_cross" -> Icons.Filled.MedicalServices
        "litter_box" -> Icons.Filled.CleaningServices
        "leash" -> Icons.Filled.Pets
        "pet_toy" -> Icons.Filled.SportsBaseball
        else -> if (isArca) Icons.Filled.Pets else Icons.Filled.ShoppingCart
    }
    val accent = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(accent.copy(alpha = 0.12f))
            .border(1.dp, accent.copy(alpha = 0.25f), RoundedCornerShape(13.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = vectorIcon,
            contentDescription = iconType,
            tint = accent,
            modifier = Modifier.size(21.dp)
        )
    }
}

/**
 * High-resolution unified vector icon resolver that replaces device-dependent emojis
 * with consistent Material Vector Icons of identical geometry and stroke weight.
 */
@Composable
fun BravoUnifiedIcon(
    iconKey: String,
    tint: Color = MaterialTheme.colorScheme.primary,
    size: Dp = 18.dp,
    modifier: Modifier = Modifier
) {
    val normalized = iconKey.trim().lowercase()
    val vector: ImageVector = when {
        normalized == "🛵" || normalized.contains("delivery") || normalized.contains("moto") || normalized.contains("ruta") -> Icons.Filled.DirectionsBike
        normalized == "📋" || normalized.contains("list") || normalized.contains("receipt") || normalized == "🧾" -> Icons.Filled.ReceiptLong
        normalized == "🏪" || normalized.contains("store") || normalized.contains("branch") -> Icons.Filled.Storefront
        normalized == "🏠" || normalized.contains("home") -> Icons.Outlined.Home
        normalized == "🔥" || normalized.contains("fire") || normalized.contains("hot") -> Icons.Filled.LocalFireDepartment
        normalized == "🎉" || normalized.contains("offer") || normalized.contains("deal") || normalized.contains("gift") -> Icons.Filled.LocalOffer
        normalized == "✓" || normalized == "✅" || normalized.contains("check") || normalized.contains("success") -> Icons.Filled.CheckCircle
        normalized == "🗑️" || normalized.contains("delete") || normalized.contains("trash") || normalized == "−" -> Icons.Filled.DeleteOutline
        normalized == "🌙" || normalized.contains("dark") || normalized.contains("moon") -> Icons.Filled.DarkMode
        normalized == "☀️" || normalized.contains("light") || normalized.contains("sun") -> Icons.Filled.LightMode
        normalized == "🔔" || normalized.contains("bell") || normalized.contains("notif") -> Icons.Filled.NotificationsActive
        normalized == "💳" || normalized.contains("card") || normalized.contains("pay") -> Icons.Filled.CreditCard
        normalized == "📦" || normalized.contains("box") || normalized.contains("pack") -> Icons.Filled.Inventory2
        normalized == "📍" || normalized.contains("pin") || normalized.contains("location") || normalized.contains("gps") -> Icons.Filled.LocationOn
        normalized == "✨" || normalized.contains("sparkle") || normalized.contains("ai") || normalized.contains("bravia") -> Icons.Filled.AutoAwesome
        normalized == "🐾" || normalized.contains("pet") || normalized.contains("arca") -> Icons.Filled.Pets
        normalized == "🛒" || normalized.contains("cart") -> Icons.Filled.ShoppingCart
        normalized == "🏆" || normalized.contains("trophy") || normalized.contains("points") -> Icons.Filled.EmojiEvents
        normalized.contains("shipping") || normalized.contains("truck") -> Icons.Filled.LocalShipping
        else -> Icons.Filled.Info
    }
    Icon(
        imageVector = vector,
        contentDescription = iconKey,
        tint = tint,
        modifier = modifier.size(size)
    )
}

private val SkuNoiseCleanupRegex = Regex(
    pattern = """\s*(?:\[\s*(?:SKU\s*:?\s*)?(?:BRV|ARC)-\d{3}\s*\]|\(\s*(?:SKU\s*:?\s*)?(?:BRV|ARC)-\d{3}\s*\)|\b(?:SKU\s*:?\s*)?(?:BRV|ARC)-\d{3}\b)""",
    option = RegexOption.IGNORE_CASE
)
private val SkusFooterCleanupRegex = Regex("""(?im)^\s*SKUS\s*:\s*\[.*?\]\s*$""")
private val NumberedItemMatchRegex = Regex("""^(?:\*\*)?(?:Paso\s*)?(\d+)[\.\)\:\-]\s*(?:\*\*)?\s*(.+)$""", RegexOption.IGNORE_CASE)
private val BulletItemMatchRegex = Regex("""^(?:[•\-\*▪▸])\s+(.+)$""")

private sealed class ParsedChatBlock {
    data class TopicHeader(val title: String) : ParsedChatBlock()
    data class EnumeratedPoint(val badgeNumber: Int, val content: String) : ParsedChatBlock()
    data class Paragraph(val content: String) : ParsedChatBlock()
}

private fun buildBoldAnnotatedLine(rawLine: String): androidx.compose.ui.text.AnnotatedString {
    val cleaned = rawLine.replace(SkuNoiseCleanupRegex, "").trim()
    return buildAnnotatedString {
        val boldParts = cleaned.split("**")
        for (i in boldParts.indices) {
            if (i % 2 == 1) {
                withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold)) {
                    append(boldParts[i])
                }
            } else {
                val italicParts = boldParts[i].split("*")
                for (j in italicParts.indices) {
                    if (j % 2 == 1) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold)) {
                            append(italicParts[j])
                        }
                    } else {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(italicParts[j])
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FormattedChatText(
    rawText: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val sanitizedText = remember(rawText) {
        rawText
            .replace(SkusFooterCleanupRegex, "")
            .replace(SkuNoiseCleanupRegex, "")
            .trim()
    }

    val blocks = remember(sanitizedText) {
        val lines = sanitizedText.lines()
        val parsed = mutableListOf<ParsedChatBlock>()
        var runningBulletNumber = 1

        for (rawLine in lines) {
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty()) continue

            val plainNoStars = trimmed.removePrefix("###").removePrefix("##").removePrefix("#").trim()
                .removeSurrounding("**").trim()

            val numberedMatch = NumberedItemMatchRegex.find(trimmed)
            val bulletMatch = BulletItemMatchRegex.find(trimmed)

            val isTopicHeader = (trimmed.startsWith("#") ||
                (trimmed.startsWith("**") && trimmed.endsWith("**") && plainNoStars.length <= 68) ||
                (plainNoStars.endsWith(":") && plainNoStars.length <= 68 && numberedMatch == null && bulletMatch == null))

            when {
                isTopicHeader -> {
                    runningBulletNumber = 1
                    parsed.add(ParsedChatBlock.TopicHeader(plainNoStars.removeSuffix(":")))
                }
                numberedMatch != null -> {
                    val explicitNum = numberedMatch.groupValues[1].toIntOrNull() ?: runningBulletNumber
                    val body = numberedMatch.groupValues[2].trim().removePrefix("**").trim()
                    runningBulletNumber = explicitNum + 1
                    parsed.add(ParsedChatBlock.EnumeratedPoint(explicitNum, body))
                }
                bulletMatch != null -> {
                    val body = bulletMatch.groupValues[1].trim()
                    val num = runningBulletNumber++
                    parsed.add(ParsedChatBlock.EnumeratedPoint(num, body))
                }
                else -> {
                    parsed.add(ParsedChatBlock.Paragraph(trimmed))
                }
            }
        }
        parsed
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        blocks.forEachIndexed { index, block ->
            when (block) {
                is ParsedChatBlock.TopicHeader -> {
                    if (index > 0) {
                        Spacer(modifier = Modifier.height(4.dp))
                        HorizontalDivider(
                            color = primaryColor.copy(alpha = 0.22f),
                            thickness = 1.dp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(16.dp)
                                .clip(CircleShape)
                                .background(primaryColor)
                        )
                        Text(
                            text = block.title,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.5.sp,
                            lineHeight = 19.sp,
                            color = textColor
                        )
                    }
                }
                is ParsedChatBlock.EnumeratedPoint -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(primaryColor.copy(alpha = 0.07f))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 1.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(primaryColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = block.badgeNumber.toString(),
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                        Text(
                            text = buildBoldAnnotatedLine(block.content),
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            fontSize = 13.5.sp,
                            lineHeight = 19.5.sp,
                            letterSpacing = 0.1.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                is ParsedChatBlock.Paragraph -> {
                    Text(
                        text = buildBoldAnnotatedLine(block.content),
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        fontSize = 13.8.sp,
                        lineHeight = 20.sp,
                        letterSpacing = 0.1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun FloatingActionFabs(
    cartCount: Int,
    isArca: Boolean,
    darkMode: Boolean,
    onOpenAi: () -> Unit,
    onOpenCart: () -> Unit,
    modifier: Modifier = Modifier,
    pulseTrigger: Long = 0L
) {
    val view = LocalView.current
    val accent = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val useRealHaze = LocalTranslucentHazeState.current != null && DeviceSupportsGpuBlur
    val fabBg = if (useRealHaze) Color.Transparent else uniformMenuTranslucentContainerColor(darkMode)
    val borderBrush = uniformMenuTranslucentBorderBrush(accent, darkMode)
    val sheenBrush = uniformMenuTranslucentSheenBrush(darkMode, accent)

    val cartScale = remember { Animatable(1f) }
    LaunchedEffect(pulseTrigger) {
        if (pulseTrigger == 0L) return@LaunchedEffect
        cartScale.snapTo(1.22f)
        cartScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            )
        )
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            onClick = {
                HapticFeedbackManager.onAssistantTrigger(view)
                onOpenAi()
            },
            shape = CircleShape,
            color = fabBg,
            border = BorderStroke(1.2.dp, borderBrush),
            shadowElevation = 10.dp,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .translucentBackdropEffect(
                    darkMode = darkMode,
                    accentColor = accent,
                    enabled = useRealHaze
                )
                .testTag("fab_ai_assistant")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(uniformMenuTranslucentGlowBrush(accent, darkMode))
                    .background(sheenBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Abrir Asistente Brav IA",
                    tint = accent,
                    modifier = Modifier.size(21.dp)
                )
            }
        }

        Box(
            contentAlignment = Alignment.TopEnd,
            modifier = Modifier.graphicsLayer {
                scaleX = cartScale.value
                scaleY = cartScale.value
            }
        ) {
            Surface(
                onClick = {
                    HapticFeedbackManager.onNavigationClick(view)
                    onOpenCart()
                },
                shape = CircleShape,
                color = fabBg,
                border = BorderStroke(1.2.dp, borderBrush),
                shadowElevation = 10.dp,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .translucentBackdropEffect(
                        darkMode = darkMode,
                        accentColor = accent,
                        enabled = useRealHaze
                    )
                    .testTag("fab_cart")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(uniformMenuTranslucentGlowBrush(accent, darkMode))
                        .background(sheenBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingCart,
                        contentDescription = "Ver mi Carrito",
                        tint = accent,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }

            if (cartCount > 0) {
                Box(
                    modifier = Modifier
                        .offset(x = 4.dp, y = (-4).dp)
                        .clip(CircleShape)
                        .background(accent)
                        .border(2.dp, if (darkMode) Color(0xFF090D16) else Color.White, CircleShape)
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cartCount.toString(),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun TranslucentBottomDock(
    currentScreen: AppScreen,
    isArca: Boolean,
    darkMode: Boolean,
    onNavigate: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    val activeTab = when (currentScreen) {
        AppScreen.BRAVISIMA -> AppScreen.BRAVISIMA
        AppScreen.CATALOG, AppScreen.CATEGORY, AppScreen.PRODUCT -> AppScreen.CATALOG
        AppScreen.HOME, AppScreen.CART, AppScreen.DELIVERY -> AppScreen.HOME
        AppScreen.BRAVIA -> AppScreen.BRAVIA
        AppScreen.ACCOUNT, AppScreen.ACCOUNT_SUB -> AppScreen.ACCOUNT
    }
    val activeColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val inactiveColor = if (darkMode) Color(0xFF94A3B8) else Color(0xFF1E293B)
    val useRealHaze = LocalTranslucentHazeState.current != null && DeviceSupportsGpuBlur
    val dockBg = if (useRealHaze) Color.Transparent else uniformMenuTranslucentContainerColor(darkMode)
    val borderBrush = uniformMenuTranslucentBorderBrush(activeColor, darkMode)
    val sheenBrush = uniformMenuTranslucentSheenBrush(darkMode, activeColor)

    val navItems = remember {
        listOf(
            Triple(AppScreen.BRAVISIMA, Icons.Outlined.CreditCard, "Tarjeta"),
            Triple(AppScreen.CATALOG, Icons.Outlined.GridView, "Catálogos"),
            Triple(AppScreen.HOME, Icons.Outlined.Home, "Home"),
            Triple(AppScreen.BRAVIA, Icons.Outlined.Search, "Buscar"),
            Triple(AppScreen.ACCOUNT, Icons.Outlined.PersonOutline, "Perfil")
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .height(58.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    elevation = 10.dp,
                    shape = RoundedCornerShape(999.dp),
                    spotColor = activeColor.copy(alpha = 0.22f)
                )
                .clip(RoundedCornerShape(999.dp))
                .translucentBackdropEffect(
                    darkMode = darkMode,
                    accentColor = activeColor,
                    enabled = useRealHaze
                ),
            shape = RoundedCornerShape(999.dp),
            color = dockBg,
            border = BorderStroke(
                width = 1.15.dp,
                brush = borderBrush
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(uniformMenuTranslucentGlowBrush(activeColor, darkMode))
                    .background(sheenBrush)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                navItems.forEach { (screen, icon, contentDesc) ->
                    val isSelected = activeTab == screen
                    val isSearchAi = screen == AppScreen.BRAVIA

                    val iconScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.15f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "navScale"
                    )
                    val pillAlpha by animateFloatAsState(
                        targetValue = if (isSelected) (if (darkMode) 0.20f else 0.12f) else 0f,
                        animationSpec = tween(durationMillis = 200),
                        label = "navPillAlpha"
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 3.dp, vertical = 3.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(activeColor.copy(alpha = pillAlpha))
                            .clickable {
                                if (isSearchAi) {
                                    HapticFeedbackManager.onAssistantTrigger(view)
                                } else {
                                    HapticFeedbackManager.onNavigationClick(view)
                                }
                                onNavigate(screen)
                            }
                            .testTag("nav_${screen.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 4.dp)
                                    .width(24.dp)
                                    .height(3.dp)
                                    .clip(CircleShape)
                                    .background(activeColor)
                            )
                        }

                        Box(
                            contentAlignment = Alignment.TopEnd,
                            modifier = Modifier.graphicsLayer {
                                scaleX = iconScale
                                scaleY = iconScale
                            }
                        ) {
                            if (screen == AppScreen.BRAVISIMA) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_bravisima_card),
                                    contentDescription = contentDesc,
                                    tint = if (isSelected) activeColor else inactiveColor,
                                    modifier = Modifier.size(25.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = contentDesc,
                                    tint = if (isSelected) activeColor else inactiveColor,
                                    modifier = Modifier.size(25.dp)
                                )
                            }
                            if (isSearchAi) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = BravoAmber,
                                    modifier = Modifier
                                        .size(11.dp)
                                        .offset(x = 4.dp, y = (-3).dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Full-screen emerald green order confirmation overlay with an animated white vector checkmark
 * and celebratory multi-note audio fanfare when an order is completed.
 */
@Composable
fun OrderSuccessCelebrationOverlay(
    orderId: String,
    totalAmountRd: Int,
    branchName: String,
    etaMinutes: Int,
    distanceKmLabel: String,
    onContinueToTracking: () -> Unit
) {
    val view = LocalView.current
    val circleScale = remember { Animatable(0.2f) }
    val checkProgress = remember { Animatable(0f) }
    val contentAlpha = remember { Animatable(0f) }
    val pulseTransition = rememberInfiniteTransition(label = "greenCelebrationPulse")
    val ringScale by pulseTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringScale"
    )

    LaunchedEffect(orderId) {
        HapticFeedbackManager.onOrderCelebration(view)
        circleScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        )
        checkProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
        )
        contentAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 360)
        )
        kotlinx.coroutines.delay(2400L)
        onContinueToTracking()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF059669),
                        Color(0xFF10B981),
                        Color(0xFF047857)
                    )
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                HapticFeedbackManager.onConfirmAction(view)
                onContinueToTracking()
            }
            .testTag("order_celebration_overlay"),
        contentAlignment = Alignment.Center
    ) {
        // Anillos concéntricos de confirmación
        Box(
            modifier = Modifier
                .size(250.dp)
                .graphicsLayer {
                    scaleX = ringScale
                    scaleY = ringScale
                    alpha = 0.16f
                }
                .clip(CircleShape)
                .background(Color.White)
        )
        Box(
            modifier = Modifier
                .size(188.dp)
                .graphicsLayer {
                    scaleX = (ringScale * 0.92f)
                    scaleY = (ringScale * 0.92f)
                    alpha = 0.22f
                }
                .clip(CircleShape)
                .background(Color.White)
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(128.dp)
                    .graphicsLayer {
                        scaleX = circleScale.value
                        scaleY = circleScale.value
                    }
                    .shadow(24.dp, CircleShape, spotColor = Color.Black.copy(alpha = 0.25f))
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.22f))
                    .border(3.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(68.dp)) {
                    val progress = checkProgress.value
                    val w = size.width
                    val h = size.height
                    val start = Offset(w * 0.18f, h * 0.52f)
                    val mid = Offset(w * 0.43f, h * 0.76f)
                    val end = Offset(w * 0.84f, h * 0.26f)

                    val path = Path().apply {
                        moveTo(start.x, start.y)
                        val firstLegFraction = (progress / 0.42f).coerceIn(0f, 1f)
                        lineTo(
                            start.x + (mid.x - start.x) * firstLegFraction,
                            start.y + (mid.y - start.y) * firstLegFraction
                        )
                        if (progress > 0.42f) {
                            val secondLegFraction = ((progress - 0.42f) / 0.58f).coerceIn(0f, 1f)
                            lineTo(
                                mid.x + (end.x - mid.x) * secondLegFraction,
                                mid.y + (end.y - mid.y) * secondLegFraction
                            )
                        }
                    }

                    drawPath(
                        path = path,
                        color = Color.White,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 9.dp.toPx(),
                            cap = androidx.compose.ui.graphics.StrokeCap.Round,
                            join = androidx.compose.ui.graphics.StrokeJoin.Round
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = contentAlpha.value }
            ) {
                Text(
                    text = "¡Pedido Confirmado!",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Orden $orderId • RD$$totalAmountRd",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = Color.White.copy(alpha = 0.94f)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.42f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = "Ubicación real",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "$branchName • $distanceKmLabel",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.White
                            )
                            Text(
                                text = "Llegada estimada: ~$etaMinutes min",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.5.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(22.dp))
                Surface(
                    onClick = {
                        HapticFeedbackManager.onConfirmAction(view)
                        onContinueToTracking()
                    },
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 8.dp,
                    modifier = Modifier.testTag("celebration_continue_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DirectionsBike,
                            contentDescription = null,
                            tint = Color(0xFF047857),
                            modifier = Modifier.size(19.dp)
                        )
                        Text(
                            text = "Ver Mapa y Rastreo en Vivo",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF047857)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PredictiveCatalogSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    catalogProducts: List<Product>,
    onSelectPredictedProduct: (Product) -> Unit,
    placeholderText: String,
    darkMode: Boolean,
    isArca: Boolean,
    testTag: String,
    modifier: Modifier = Modifier,
    trailingActionContent: (@Composable () -> Unit)? = null
) {
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val view = LocalView.current

    // Busca la coincidencia más cercana del catálogo mientras se escribe
    val predictedProduct = remember(query, catalogProducts) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            null
        } else {
            val lower = clean.lowercase()
            catalogProducts.firstOrNull { it.name.lowercase().startsWith(lower) }
                ?: catalogProducts.firstOrNull { prod ->
                    prod.name.lowercase().split(" ").any { word -> word.startsWith(lower) }
                }
                ?: catalogProducts.firstOrNull { it.name.lowercase().contains(lower) }
        }
    }

    // Texto sugerido de autocompletado
    val inlineGhostSuffix = remember(query, predictedProduct) {
        val clean = query
        if (clean.isBlank() || predictedProduct == null) {
            ""
        } else {
            val prodName = predictedProduct.name
            if (prodName.startsWith(clean, ignoreCase = true) && prodName.length > clean.length) {
                prodName.substring(clean.length)
            } else {
                "  —  ${predictedProduct.name}"
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TranslucentCard(
            darkMode = darkMode,
            isArca = isArca,
            cornerRadius = 999.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = "Buscar",
                    tint = primaryColor,
                    modifier = Modifier.size(18.dp)
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (query.isEmpty()) {
                        Text(
                            text = placeholderText,
                            fontFamily = PlusJakartaSans,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.80f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else if (predictedProduct != null && inlineGhostSuffix.isNotEmpty()) {
                        // Sugerencia visual detrás del cursor
                        Text(
                            text = buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        color = Color.Transparent,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                ) {
                                    append(query)
                                }
                                withStyle(
                                    SpanStyle(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                            alpha = if (darkMode) 0.55f else 0.48f
                                        ),
                                        fontWeight = FontWeight.Medium
                                    )
                                ) {
                                    append(inlineGhostSuffix)
                                }
                            },
                            fontFamily = PlusJakartaSans,
                            fontSize = 12.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    BasicTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(primaryColor),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                if (predictedProduct != null) {
                                    onQueryChange(predictedProduct.name)
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag(testTag)
                    )
                }

                // Chip rápido para completar la búsqueda
                if (query.isNotBlank() && predictedProduct != null && !predictedProduct.name.equals(query.trim(), ignoreCase = true)) {
                    val cal = predictedProduct.nutritionProfile().caloriesKcal
                    Surface(
                        onClick = {
                            performCrispHaptic(view, HapticStyle.TICK)
                            onQueryChange(predictedProduct.name)
                        },
                        shape = CircleShape,
                        color = primaryColor.copy(alpha = if (darkMode) 0.22f else 0.12f),
                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.35f)),
                        modifier = Modifier.testTag("${testTag}_inline_prediction")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "RD$${predictedProduct.price}" + (if (cal != null) " • ${cal}kcal" else ""),
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp,
                                color = primaryColor
                            )
                            Text(
                                text = "Completar ⇥",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                if (query.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f))
                            .clickable {
                                performCrispHaptic(view, HapticStyle.TICK)
                                onQueryChange("")
                            }
                            .testTag("${testTag}_clear"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Limpiar búsqueda",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                if (trailingActionContent != null) {
                    trailingActionContent()
                }
            }
        }
    }
}


