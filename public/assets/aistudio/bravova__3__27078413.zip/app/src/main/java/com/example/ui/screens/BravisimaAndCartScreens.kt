package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.model.BravisimaCard
import com.example.model.BravisimaMovement
import com.example.model.CartTotals
import com.example.model.DriverChatMessage
import com.example.model.DriverLiveTelemetry
import com.example.model.LiveDeliveryBannerNotification
import com.example.model.OrderDeliveryStage
import com.example.model.OrderRecord
import com.example.model.Product
import com.example.model.RealLocationDeliveryMetrics
import com.example.model.StoreMode
import com.example.model.UserProfile
import com.example.ui.components.AnimatedPurchaseButton
import com.example.ui.components.BravoOfficialLogoBadge
import com.example.ui.components.BravoUnderline
import com.example.ui.components.BravoUnifiedIcon
import com.example.ui.components.DiagonalMetadataStrip
import com.example.ui.components.FloatingHeaderCapsule
import com.example.ui.components.HapticFeedbackManager
import com.example.ui.components.HapticStyle
import com.example.ui.components.LocalTranslucentHazeState
import com.example.ui.components.ProductArtworkView
import com.example.ui.components.TranslucentCard
import com.example.ui.components.performCrispHaptic
import com.example.ui.components.translucentBackdropSource
import com.example.ui.theme.ArcaTeal
import com.example.ui.theme.BravoAmber
import com.example.ui.theme.BravoRed
import com.example.ui.theme.BravoRedDark
import com.example.ui.theme.PlusJakartaSans
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private fun formatMoney(amount: Int): String {
    return NumberFormat.getNumberInstance(Locale.US).format(amount)
}

@Composable
fun BravisimaScreen(
    balance: Int,
    cartTotals: CartTotals,
    userProfile: UserProfile,
    bravisimaCard: BravisimaCard,
    movements: List<BravisimaMovement>,
    isGuestMode: Boolean,
    isSavingBravisima: Boolean,
    darkMode: Boolean,
    onRedeemInCart: () -> Unit,
    onOpenScanner: () -> Unit,
    onToggleCardLock: () -> Unit,
    onToggleAutoRedeem: () -> Unit,
    onSaveCardSettings: (holderName: String, monthlyGoal: Int, preferredCategory: String) -> Unit,
    onRedeemPromoCode: (String) -> Unit,
    onCopyCardNumber: (String) -> Unit,
    onSignOutGoogle: () -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val primaryColor = MaterialTheme.colorScheme.primary
    val neededForNextPeso = cartTotals.nextHundredRemainder.roundToInt()

    var isGoogleSigningIn by remember { mutableStateOf(false) }
    var authErrorBanner by remember { mutableStateOf<String?>(null) }
    var maskCardNumber by remember { mutableStateOf(false) }
    var isEditingSettings by remember { mutableStateOf(false) }
    var editableHolderName by remember(bravisimaCard.holderName) { mutableStateOf(bravisimaCard.holderName) }
    var editableGoal by remember(bravisimaCard.monthlyGoal) { mutableIntStateOf(bravisimaCard.monthlyGoal) }
    var editableCategory by remember(bravisimaCard.preferredCategory) { mutableStateOf(bravisimaCard.preferredCategory) }
    var promoCodeInput by remember { mutableStateOf("") }

    val cardNumber = bravisimaCard.cardNumber.ifBlank { userProfile.bravisimaNumber }
    val displayCardNumber = if (maskCardNumber && cardNumber.length >= 4) {
        "BRV-••••-••••-${cardNumber.takeLast(4)}"
    } else {
        cardNumber
    }
    val barcodeBars = remember(cardNumber) {
        val seedBase = abs(cardNumber.hashCode())
        IntArray(32) { idx ->
            1 + ((seedBase / (idx + 1) + idx * 5) % 3)
        }
    }

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("bravisima_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "bravisima_auth_status", contentType = "auth_status_card") {
                TranslucentCard(
                    darkMode = darkMode,
                    cornerRadius = 22.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("bravisima_auth_card")
                ) {
                    if (isGuestMode) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(primaryColor.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = "Cuenta Google y Bravísima",
                                        tint = primaryColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Vincula tu cuenta Google",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Inicia sesión con tu cuenta de Google para sincronizar y gestionar tu Tarjeta Bravísima en todos tus dispositivos.",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.5.sp,
                                        lineHeight = 15.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            AnimatedVisibility(
                                visible = authErrorBanner != null,
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                authErrorBanner?.let { err ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.errorContainer,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = err,
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    if (isGoogleSigningIn) return@Button
                                    HapticFeedbackManager.onConfirmAction(view)
                                    authErrorBanner = null
                                    isGoogleSigningIn = true
                                    scope.launch {
                                        val result = launchGoogleSignInSheet(context)
                                        isGoogleSigningIn = false
                                        result.onFailure { e ->
                                            authErrorBanner = e.localizedMessage
                                                ?: "No se pudo completar el inicio de sesión con Google."
                                        }
                                    }
                                },
                                enabled = !isGoogleSigningIn,
                                shape = RoundedCornerShape(999.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 11.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("bravisima_google_signin_button")
                            ) {
                                if (isGoogleSigningIn) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.2.dp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Conectando con Google...",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.5.sp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = BravoAmber,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Iniciar sesión con Google",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 13.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF059669).copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudDone,
                                        contentDescription = "Sincronizado con Google",
                                        tint = Color(0xFF059669),
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = bravisimaCard.holderName,
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.5.sp,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (isSavingBravisima) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(12.dp),
                                                strokeWidth = 1.8.dp,
                                                color = primaryColor
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${bravisimaCard.holderEmail ?: userProfile.email} • Cuenta Google Activa",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    HapticFeedbackManager.onNavigationClick(view)
                                    onSignOutGoogle()
                                },
                                border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                shape = RoundedCornerShape(999.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("bravisima_sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Cerrar sesión de Google",
                                    tint = primaryColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Salir",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.5.sp,
                                    color = primaryColor
                                )
                            }
                        }
                    }
                }
            }

            item(key = "bravisima_card", contentType = "loyalty_card") {
                val cardGradient = if (bravisimaCard.isLocked) {
                    listOf(Color(0xFF334155), Color(0xFF1E293B), Color(0xFF0F172A))
                } else {
                    listOf(primaryColor, BravoRedDark, Color(0xFF4C0519))
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .shadow(18.dp, RoundedCornerShape(26.dp), spotColor = primaryColor.copy(alpha = 0.35f))
                        .clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(colors = cardGradient))
                        .padding(20.dp)
                        .testTag("bravisima_digital_card")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                DiagonalMetadataStrip(
                                    items = listOf(
                                        "NIVEL ${bravisimaCard.tier.label.uppercase()}",
                                        if (bravisimaCard.isLocked) "BLOQUEADA" else "ACTIVA",
                                        "1% Cashback"
                                    ),
                                    slashColor = Color.White,
                                    textColor = Color.White.copy(alpha = 0.88f),
                                    fontSizeSp = 10f
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "Bravísima Digital",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 23.sp,
                                    color = Color.White
                                )

                                Text(
                                    text = bravisimaCard.holderName.uppercase(),
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    letterSpacing = 1.1.sp,
                                    color = Color.White.copy(alpha = 0.90f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Color.White.copy(alpha = 0.96f)
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                    BravoOfficialLogoBadge(scale = 0.82f)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .clickable {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onOpenScanner()
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .testTag("bravisima_barcode_plate"),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                            ) {
                                val totalUnits = barcodeBars.sum() * 2
                                val unitWidth = size.width / totalUnits
                                var x = 0f
                                barcodeBars.forEachIndexed { idx, w ->
                                    val barWidth = w * unitWidth
                                    drawRect(
                                        color = if (bravisimaCard.isLocked) Color(0xFF94A3B8) else Color(0xFF111827),
                                        topLeft = Offset(x, 0f),
                                        size = Size(barWidth, size.height)
                                    )
                                    x += barWidth + (if (idx % 2 == 0) unitWidth * 1.4f else unitWidth * 0.9f)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = displayCardNumber,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    letterSpacing = 1.1.sp,
                                    color = Color(0xFF1F2937)
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (maskCardNumber) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Mostrar u ocultar número de tarjeta",
                                        tint = Color(0xFF475569),
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clickable {
                                                performCrispHaptic(view, HapticStyle.TICK)
                                                maskCardNumber = !maskCardNumber
                                            }
                                            .testTag("bravisima_toggle_mask_button")
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar número Bravísima",
                                        tint = Color(0xFF475569),
                                        modifier = Modifier
                                            .size(17.dp)
                                            .clickable {
                                                performCrispHaptic(view, HapticStyle.TICK)
                                                clipboard.setText(AnnotatedString(cardNumber))
                                                onCopyCardNumber(cardNumber)
                                            }
                                            .testTag("bravisima_copy_number_button")
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.QrCodeScanner,
                                            contentDescription = null,
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Escanear",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = primaryColor
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = if (bravisimaCard.isLocked) "BALANCE PROTEGIDO" else "BALANCE DISPONIBLE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "RD$ ${formatMoney(balance)}.00",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 26.sp,
                                    color = Color.White
                                )
                            }

                            Button(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onRedeemInCart()
                                },
                                enabled = !bravisimaCard.isLocked,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = primaryColor,
                                    disabledContainerColor = Color.White.copy(alpha = 0.45f),
                                    disabledContentColor = Color(0xFF334155)
                                ),
                                shape = RoundedCornerShape(999.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                modifier = Modifier.testTag("bravisima_redeem_button")
                            ) {
                                Text(
                                    text = if (bravisimaCard.isLocked) "Bloqueada" else "Canjear en carrito",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            item(key = "bravisima_management", contentType = "card_management") {
                val tier = bravisimaCard.tier
                val nextTarget = tier.nextTierTargetRd
                val tierProgress = if (nextTarget != null && nextTarget > tier.minLifetimeRd) {
                    ((bravisimaCard.lifetimeEarned - tier.minLifetimeRd).toFloat() /
                        (nextTarget - tier.minLifetimeRd).toFloat()).coerceIn(0f, 1f)
                } else {
                    1f
                }
                val goalProgress = (bravisimaCard.balance.toFloat() / bravisimaCard.monthlyGoal.toFloat()).coerceIn(0f, 1f)

                TranslucentCard(
                    darkMode = darkMode,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("bravisima_management_card")
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Gestionar Tarjeta Bravísima",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = false)
                        }

                        // Resumen de nivel y meta mensual
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Nivel ${tier.label} • Acumulado RD$ ${formatMoney(bravisimaCard.lifetimeEarned)}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                                Text(
                                    text = if (nextTarget != null) "Meta: RD$ $nextTarget" else "Nivel Máximo",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            LinearProgressIndicator(
                                progress = { tierProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(99.dp)),
                                color = primaryColor,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                            Text(
                                text = "${tier.benefitSummary} • Meta de ahorro: RD$ ${formatMoney(bravisimaCard.balance)} / RD$ ${formatMoney(bravisimaCard.monthlyGoal)} (${(goalProgress * 100).roundToInt()}%)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Interruptor de bloqueo de seguridad
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (bravisimaCard.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = if (bravisimaCard.isLocked) BravoRed else Color(0xFF059669),
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = if (bravisimaCard.isLocked) "Tarjeta bloqueada" else "Seguridad de tarjeta activa",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (bravisimaCard.isLocked) {
                                            "Canjes y códigos pausados temporalmente"
                                        } else {
                                            "Toca para bloquear temporalmente tu Bravísima"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = bravisimaCard.isLocked,
                                onCheckedChange = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onToggleCardLock()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = BravoRed
                                ),
                                modifier = Modifier.testTag("bravisima_lock_switch")
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                        // Canje automático en el carrito
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CreditCard,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "Canje automático en carrito",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Aplica tu balance Bravísima al pagar automáticamente",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = bravisimaCard.autoRedeemInCart && !bravisimaCard.isLocked,
                                onCheckedChange = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onToggleAutoRedeem()
                                },
                                enabled = !bravisimaCard.isLocked,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = primaryColor
                                ),
                                modifier = Modifier.testTag("bravisima_autoredeem_switch")
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                        // Configuración de titular y meta de ahorro
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    isEditingSettings = !isEditingSettings
                                }
                                .padding(vertical = 4.dp)
                                .testTag("bravisima_toggle_settings_editor"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Personalizar titular, meta y pasillo favorito",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = primaryColor
                                )
                            }
                            Icon(
                                imageVector = if (isEditingSettings) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = primaryColor
                            )
                        }

                        AnimatedVisibility(visible = isEditingSettings) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                OutlinedTextField(
                                    value = editableHolderName,
                                    onValueChange = { editableHolderName = it },
                                    label = { Text("Nombre en Tarjeta Bravísima") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("bravisima_holder_name_input")
                                )

                                Text(
                                    text = "Meta mensual de ahorro: RD$ ${formatMoney(editableGoal)}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(300, 500, 1000, 2000).forEach { goalOption ->
                                        val selected = editableGoal == goalOption
                                        Surface(
                                            onClick = {
                                                performCrispHaptic(view, HapticStyle.TICK)
                                                editableGoal = goalOption
                                            },
                                            shape = RoundedCornerShape(999.dp),
                                            color = if (selected) primaryColor else primaryColor.copy(alpha = 0.10f),
                                            border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.4f))
                                        ) {
                                            Text(
                                                text = "RD$ $goalOption",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.5.sp,
                                                color = if (selected) Color.White else primaryColor,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "Categoría preferida de bonos",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("Todo Bravo", "Despensa", "Carnes y Frescos", "El Arca Mascotas").forEach { catOption ->
                                        val selected = editableCategory == catOption
                                        Surface(
                                            onClick = {
                                                performCrispHaptic(view, HapticStyle.TICK)
                                                editableCategory = catOption
                                            },
                                            shape = RoundedCornerShape(999.dp),
                                            color = if (selected) primaryColor else primaryColor.copy(alpha = 0.10f),
                                            border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.4f))
                                        ) {
                                            Text(
                                                text = catOption,
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.5.sp,
                                                color = if (selected) Color.White else primaryColor,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }

                                Button(
                                    onClick = {
                                        HapticFeedbackManager.onConfirmAction(view)
                                        onSaveCardSettings(editableHolderName, editableGoal, editableCategory)
                                        isEditingSettings = false
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("bravisima_save_settings_button")
                                ) {
                                    Text(
                                        text = if (isGuestMode) "Guardar en mi Dispositivo" else "Guardar Cambios en mi Cuenta",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.5.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item(key = "bravisima_promo_redeem", contentType = "promo_code_card") {
                TranslucentCard(
                    darkMode = darkMode,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Activar Código Promocional",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = false)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = promoCodeInput,
                                onValueChange = { promoCodeInput = it },
                                placeholder = { Text("Ej. BRAVO25") },
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.LocalOffer,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("bravisima_promo_input")
                            )
                            Button(
                                onClick = {
                                    HapticFeedbackManager.onConfirmAction(view)
                                    onRedeemPromoCode(promoCodeInput)
                                    promoCodeInput = ""
                                },
                                enabled = !bravisimaCard.isLocked && promoCodeInput.isNotBlank(),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("bravisima_apply_promo_button")
                            ) {
                                Text(
                                    text = "Aplicar",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.5.sp,
                                    color = Color.White
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("BRAVO25" to "+RD$ 25", "BRAVISIMA50" to "+RD$ 50", "ARCA20" to "+RD$ 20").forEach { (code, reward) ->
                                val alreadyClaimed = bravisimaCard.claimedPromoCodes.any { it.equals(code, ignoreCase = true) }
                                Surface(
                                    onClick = {
                                        if (!alreadyClaimed) {
                                            performCrispHaptic(view, HapticStyle.TICK)
                                            promoCodeInput = code
                                        }
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (alreadyClaimed) {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    } else {
                                        primaryColor.copy(alpha = 0.10f)
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        if (alreadyClaimed) Color.Transparent else primaryColor.copy(alpha = 0.35f)
                                    )
                                ) {
                                    Text(
                                        text = if (alreadyClaimed) "$code ✓ Canjeado" else "$code ($reward)",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.sp,
                                        color = if (alreadyClaimed) MaterialTheme.colorScheme.onSurfaceVariant else primaryColor,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item(key = "bravisima_progress", contentType = "progress_card") {
                TranslucentCard(
                    darkMode = darkMode,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Progreso en tu carrito actual",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = false)
                            Spacer(modifier = Modifier.height(4.dp))
                            DiagonalMetadataStrip(
                                items = listOf("+RD$ ${cartTotals.bravisimaGenerated}", "Hoy"),
                                slashColor = Color(0xFF059669),
                                fontSizeSp = 11.5f
                            )
                        }

                        Text(
                            text = "Recibes RD$ 1.00 de retorno automático por cada RD$ 100.00 en compras.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        LinearProgressIndicator(
                            progress = { cartTotals.progressPct },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(99.dp)),
                            color = primaryColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        DiagonalMetadataStrip(
                            items = listOf("Próximo peso", "Faltan RD$ $neededForNextPeso"),
                            slashColor = primaryColor,
                            fontSizeSp = 11f
                        )
                    }
                }
            }

            item(key = "bravisima_movements", contentType = "movements_card") {
                TranslucentCard(
                    darkMode = darkMode,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Movimientos recientes (${movements.size})",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = false)
                        }

                        if (movements.isEmpty()) {
                            Text(
                                text = "Aún no hay movimientos registrados en tu Tarjeta Bravísima.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            movements.forEachIndexed { idx, mov ->
                                val isPositive = mov.amount >= 0
                                val formattedAmount = if (isPositive) {
                                    "+RD$ ${formatMoney(mov.amount)}.00"
                                } else {
                                    "-RD$ ${formatMoney(abs(mov.amount))}.00"
                                }
                                MovementRow(
                                    title = mov.title,
                                    meta = listOf(mov.dateLabel, mov.subtitle),
                                    amountText = formattedAmount,
                                    isPositive = isPositive
                                )
                                if (idx < movements.lastIndex) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                }
                            }
                        }
                    }
                }
            }
        }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(primaryColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_bravisima_card),
                        contentDescription = "Icono Tarjeta Bravísima",
                        tint = primaryColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "Tarjeta Bravísima",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = false)
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = primaryColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = bravisimaCard.tier.label,
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.5.sp,
                        color = primaryColor,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MovementRow(
    title: String,
    meta: List<String>,
    amountText: String,
    isPositive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            DiagonalMetadataStrip(
                items = meta,
                slashColor = MaterialTheme.colorScheme.primary,
                fontSizeSp = 11f
            )
        }
        Text(
            text = amountText,
            fontFamily = PlusJakartaSans,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            color = if (isPositive) Color(0xFF059669) else BravoRed
        )
    }
}

@Composable
fun CartCheckoutScreen(
    cartItems: List<Pair<Product, Int>>,
    cartTotals: CartTotals,
    bravisimaBalance: Int,
    redeemBravisima: Boolean,
    isBravisimaLocked: Boolean = false,
    storeMode: StoreMode,
    darkMode: Boolean,
    onBack: () -> Unit,
    onEmptyCart: () -> Unit,
    onOpenProduct: (String) -> Unit,
    onUpdateQty: (String, Int) -> Unit,
    onToggleRedeem: (Boolean) -> Unit,
    onConfirmCheckout: () -> Unit,
    onExploreCatalog: () -> Unit,
    onAskBravIa: () -> Unit
) {
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("cart_checkout_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 132.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (cartItems.isEmpty()) {
                item(key = "cart_empty_state", contentType = "empty_state") {
                    TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Tu carrito está vacío",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Agrega productos directamente desde los pasillos con un toque rápido.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        AnimatedPurchaseButton(
                            text = "Explorar productos",
                            primaryColor = primaryColor,
                            onClick = onExploreCatalog,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        } else {
            items(
                items = cartItems,
                key = { it.first.sku },
                contentType = { "cart_item_row" }
            ) { (product, qty) ->
                TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    cornerRadius = 18.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    onClick = { onOpenProduct(product.sku) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            ProductArtworkView(product = product)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = product.name,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            DiagonalMetadataStrip(
                                items = listOf(product.category, "RD$${product.price} / ${product.unit}"),
                                slashColor = primaryColor,
                                fontSizeSp = 10.5f
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "RD$ ${formatMoney(product.price * qty)}.00",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = primaryColor
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (qty == 1) Color(0xFFFFE4E6) else MaterialTheme.colorScheme.surface
                                    )
                                    .clickable {
                                        HapticFeedbackManager.onDecrementOrRemove(view, isFullRemove = qty == 1)
                                        onUpdateQty(product.sku, -1)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (qty == 1) Icons.Default.DeleteOutline else Icons.Default.Remove,
                                    contentDescription = "Restar",
                                    tint = if (qty == 1) Color(0xFFBE123C) else primaryColor,
                                    modifier = Modifier.size(15.dp)
                                )
                            }

                            Text(
                                text = qty.toString(),
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(primaryColor)
                                    .clickable {
                                        HapticFeedbackManager.onAddToCart(view)
                                        onUpdateQty(product.sku, 1)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Sumar",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }

            item(key = "cart_summary_box", contentType = "summary") {
                TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    cornerRadius = 22.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Resumen de Compra",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            BravoUnderline(isArca = isArca)
                        }

                        val canRedeemCard = bravisimaBalance > 0 && !isBravisimaLocked
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .clickable(enabled = canRedeemCard) {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onToggleRedeem(!redeemBravisima)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isBravisimaLocked) {
                                        "Tarjeta Bravísima bloqueada"
                                    } else {
                                        "Canjear balance Tarjeta Bravísima"
                                    },
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isBravisimaLocked) BravoRed else MaterialTheme.colorScheme.onSurface
                                )
                                DiagonalMetadataStrip(
                                    items = if (isBravisimaLocked) {
                                        listOf("Desbloquéala en Bravísima", "RD$ ${formatMoney(bravisimaBalance)}.00")
                                    } else {
                                        listOf("Disponible", "RD$ ${formatMoney(bravisimaBalance)}.00")
                                    },
                                    slashColor = if (isBravisimaLocked) BravoRed else primaryColor,
                                    fontSizeSp = 10.5f
                                )
                            }
                            Checkbox(
                                checked = redeemBravisima && canRedeemCard,
                                onCheckedChange = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onToggleRedeem(it)
                                },
                                enabled = canRedeemCard,
                                colors = CheckboxDefaults.colors(checkedColor = primaryColor),
                                modifier = Modifier.testTag("cart_redeem_checkbox")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal (${cartTotals.count} art.)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                "RD$ ${formatMoney(cartTotals.subtotal.roundToInt())}.00",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (cartTotals.redeemed > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Descuento Bravísima", color = Color(0xFF059669))
                                Text(
                                    "-RD$ ${formatMoney(cartTotals.redeemed)}.00",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF059669)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Envío Express / Retorno 1%", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            DiagonalMetadataStrip(
                                items = listOf("GRATIS", "+RD$ ${cartTotals.bravisimaGenerated} Bravísima"),
                                slashColor = Color(0xFF059669),
                                fontSizeSp = 11.5f
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total a pagar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "RD$ ${formatMoney(cartTotals.finalPay.roundToInt())}.00",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 23.sp,
                                color = primaryColor
                            )
                        }

                        AnimatedPurchaseButton(
                            text = "Confirmar Pedido • RD$ ${formatMoney(cartTotals.finalPay.roundToInt())}",
                            icon = Icons.Default.ShoppingCartCheckout,
                            primaryColor = primaryColor,
                            onClick = {
                                HapticFeedbackManager.onCheckoutConfirm(view)
                                onConfirmCheckout()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "confirm_checkout_button"
                        )
                    }
                }
            }

            item(key = "cart_bravia_option", contentType = "assistant_option") {
                TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    cornerRadius = 18.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    onClick = {
                        HapticFeedbackManager.onAssistantTrigger(view)
                        onAskBravIa()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                DiagonalMetadataStrip(
                                    items = listOf("OPCIÓN DE AHORRO", "Brav IA"),
                                    slashColor = primaryColor,
                                    fontSizeSp = 10f
                                )
                                Text(
                                    text = "¿Deseas ajustar este carrito a un presupuesto menor?",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = primaryColor
                        )
                    }
                }
            }
        }
    }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        performCrispHaptic(view, HapticStyle.TICK)
                        onBack()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("cart_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        tint = primaryColor
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "Mi Carrito (${cartTotals.count})",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = isArca)
                }

                if (cartItems.isNotEmpty()) {
                    Surface(
                        onClick = {
                            performCrispHaptic(view, HapticStyle.HEAVY)
                            onEmptyCart()
                        },
                        shape = RoundedCornerShape(999.dp),
                        color = if (darkMode) Color(0xFF4C0519) else Color(0xFFFFE4E6),
                        border = BorderStroke(1.2.dp, Color(0xFFE11D48)),
                        modifier = Modifier.testTag("cart_empty_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = null,
                                tint = if (darkMode) Color(0xFFFDA4AF) else Color(0xFFBE123C),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Vaciar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = if (darkMode) Color(0xFFFDA4AF) else Color(0xFFBE123C),
                                maxLines = 1
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.width(36.dp))
                }
            }
        }
    }
}

private data class RoutePoint(
    val xFraction: Float,
    val yFraction: Float,
    val etaMin: Int,
    val distanceKm: String,
    val speedKmh: Int,
    val streetLabel: String
)

private val SANTO_DOMINGO_ROUTE = listOf(
    RoutePoint(0.18f, 0.23f, 9, "1.8 km", 32, "Saliendo de Bravo Av. Winston Churchill"),
    RoutePoint(0.26f, 0.30f, 8, "1.6 km", 36, "Avanzando por Av. Winston Churchill"),
    RoutePoint(0.35f, 0.37f, 7, "1.4 km", 38, "Cruzando C. Roberto Pastoriza"),
    RoutePoint(0.45f, 0.44f, 6, "1.1 km", 34, "Incorporándose a Av. 27 de Febrero"),
    RoutePoint(0.55f, 0.51f, 5, "0.9 km", 40, "Tomando desvío hacia Piantini"),
    RoutePoint(0.64f, 0.58f, 4, "0.7 km", 35, "Cruzando Av. Abraham Lincoln"),
    RoutePoint(0.73f, 0.65f, 3, "0.4 km", 29, "Entrando a tu cuadra residencial"),
    RoutePoint(0.81f, 0.72f, 2, "0.2 km", 22, "A 200 metros de tu edificio"),
    RoutePoint(0.85f, 0.76f, 1, "0.1 km", 15, "¡Llegando a Tu Dirección en Piantini!")
)

@Composable
fun DeliveryTrackingScreen(
    branchName: String,
    cartItems: List<Pair<Product, Int>>,
    darkMode: Boolean,
    trackedOrder: OrderRecord? = null,
    allOrders: List<OrderRecord> = emptyList(),
    firestoreSyncStatus: String = "Sincronizado con tu cuenta de Google",
    isGuestMode: Boolean = false,
    isUpdatingOrderStatus: Boolean = false,
    realLocationMetrics: RealLocationDeliveryMetrics? = null,
    driverTelemetry: DriverLiveTelemetry = DriverLiveTelemetry(),
    driverChatMessages: List<DriverChatMessage> = emptyList(),
    isDriverTyping: Boolean = false,
    liveDeliveryBanner: LiveDeliveryBannerNotification? = null,
    onRefreshRealLocation: (Boolean) -> Unit = {},
    onTriggerDynamicPush: () -> Unit = {},
    onSendDriverMessage: (String) -> Unit = {},
    onToggleAutoSimulation: () -> Unit = {},
    onRecalculateTraffic: () -> Unit = {},
    onDismissLiveBanner: () -> Unit = {},
    productLookup: (String) -> Product? = { null },
    onBack: () -> Unit,
    onCallDriver: () -> Unit,
    onMessageDriver: () -> Unit,
    onSelectOrder: (String) -> Unit = {},
    onSelectDeliveryStage: (OrderDeliveryStage) -> Unit = {},
    onAdvanceDeliveryStage: () -> Unit = {},
    onOpenProduct: (String) -> Unit = {}
) {
    val view = LocalView.current
    val context = LocalContext.current
    val primaryColor = MaterialTheme.colorScheme.primary

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        onRefreshRealLocation(granted)
    }

    LaunchedEffect(Unit) {
        onRefreshRealLocation(false)
    }

    val activeOrder = trackedOrder ?: allOrders.firstOrNull()
    val deliveryStage = remember(activeOrder?.status) {
        OrderDeliveryStage.fromStatusString(activeOrder?.status)
    }
    val effectiveBranch = realLocationMetrics?.branchName?.takeIf { it.isNotBlank() }
        ?: activeOrder?.branch?.takeIf { it.isNotBlank() }
        ?: branchName
    val orderIdDisplay = activeOrder?.id ?: "ORD-88412"
    val effectiveEtaMinutes = driverTelemetry.dynamicEtaMinutes.takeIf { it > 0 }
        ?: realLocationMetrics?.stageAdjustedEtaMinutes
        ?: deliveryStage.etaMinutes
    val effectiveRoadKm = realLocationMetrics?.roadDistanceKm ?: 2.4

    val animatedProgress by animateFloatAsState(
        targetValue = deliveryStage.progressFraction,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "orderDeliveryProgress"
    )

    val exactRouteProgress = driverTelemetry.routeProgressFraction.coerceIn(0f, 1f)
    val totalSegments = (SANTO_DOMINGO_ROUTE.size - 1).coerceAtLeast(1)
    val scaledPos = exactRouteProgress * totalSegments
    val lowerIdx = scaledPos.toInt().coerceIn(0, SANTO_DOMINGO_ROUTE.lastIndex)
    val upperIdx = (lowerIdx + 1).coerceIn(0, SANTO_DOMINGO_ROUTE.lastIndex)
    val segFraction = (scaledPos - lowerIdx).coerceIn(0f, 1f)
    val lowerPt = SANTO_DOMINGO_ROUTE[lowerIdx]
    val upperPt = SANTO_DOMINGO_ROUTE[upperIdx]
    val targetX = lowerPt.xFraction + (upperPt.xFraction - lowerPt.xFraction) * segFraction
    val targetY = lowerPt.yFraction + (upperPt.yFraction - lowerPt.yFraction) * segFraction

    val animatedX by animateFloatAsState(
        targetValue = targetX,
        animationSpec = tween(durationMillis = 260, easing = LinearEasing),
        label = "driverX"
    )
    val animatedY by animateFloatAsState(
        targetValue = targetY,
        animationSpec = tween(durationMillis = 260, easing = LinearEasing),
        label = "driverY"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 12f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    val trackedProducts = remember(activeOrder?.skus, cartItems) {
        val fromOrder = activeOrder?.skus.orEmpty().mapNotNull { sku ->
            productLookup(sku)?.let { it to 1 }
        }
        if (fromOrder.isNotEmpty()) fromOrder else cartItems
    }

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .testTag("delivery_tracking_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Banner de estado del envío en tiempo real
            item(key = "live_delivery_notification_banner", contentType = "live_banner") {
                LiveDeliveryNotificationBannerCard(
                    banner = liveDeliveryBanner,
                    deliveryStage = deliveryStage,
                    telemetry = driverTelemetry,
                    orderIdDisplay = orderIdDisplay,
                    darkMode = darkMode,
                    primaryColor = primaryColor,
                    onTriggerSystemNotification = {
                        performCrispHaptic(view, HapticStyle.CONFIRM)
                        onTriggerDynamicPush()
                    },
                    onDismiss = onDismissLiveBanner
                )
            }

            if (allOrders.size > 1) {
                item(key = "delivery_order_selector", contentType = "order_selector") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        allOrders.forEach { ord ->
                            val isSelected = ord.id == orderIdDisplay
                            val ordStage = OrderDeliveryStage.fromStatusString(ord.status)
                            Surface(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onSelectOrder(ord.id)
                                },
                                shape = RoundedCornerShape(999.dp),
                                color = if (isSelected) {
                                    primaryColor
                                } else {
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                                },
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (isSelected) primaryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                                ),
                                modifier = Modifier.testTag("order_selector_chip_${ord.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    BravoUnifiedIcon(
                                        iconKey = ordStage.emoji,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else primaryColor,
                                        size = 14.dp
                                    )
                                    Text(
                                        text = "#${ord.id} • ${ordStage.progressPct}%",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.5.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Mapa interactivo de seguimiento con velocidad, tráfico y tiempo estimado
            item(key = "delivery_map", contentType = "map_card") {
                val userLat = realLocationMetrics?.userLat ?: 18.4685
                val userLng = realLocationMetrics?.userLng ?: -69.9442
                val branchLat = realLocationMetrics?.branchLat ?: 18.4719
                val branchLng = realLocationMetrics?.branchLng ?: -69.9388
                val deliveryFeeRd = realLocationMetrics?.deliveryFeeRd ?: 95

                TranslucentCard(
                    darkMode = darkMode,
                    cornerRadius = 24.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("google_maps_real_location_card")
                ) {
                    Column {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Map,
                                    contentDescription = "Mapa GPS en Vivo",
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Mapa GPS en Tiempo Real • Tráfico y Velocidad",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                            }
                            BravoUnderline(isArca = false)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${driverTelemetry.currentStreet} • ${driverTelemetry.lastUpdatedLabel}",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = primaryColor.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.35f)),
                                    modifier = Modifier.testTag("refresh_real_gps_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.MyLocation,
                                            contentDescription = "Actualizar mi ubicación GPS",
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Mi GPS",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = primaryColor
                                        )
                                    }
                                }

                                Surface(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.TICK)
                                        onToggleAutoSimulation()
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (driverTelemetry.isAutoSimulating) {
                                        Color(0xFF059669).copy(alpha = 0.14f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        if (driverTelemetry.isAutoSimulating) Color(0xFF059669) else MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier.testTag("toggle_auto_traffic_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (driverTelemetry.isAutoSimulating) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Alternar actualización automática",
                                            tint = if (driverTelemetry.isAutoSimulating) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = if (driverTelemetry.isAutoSimulating) "Auto-Tráfico Activo" else "Reanudar Ruta",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = if (driverTelemetry.isAutoSimulating) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Surface(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onRecalculateTraffic()
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.testTag("recalculate_traffic_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Traffic,
                                            contentDescription = "Recalcular tráfico en vivo",
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Tráfico Ahora",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onTriggerDynamicPush()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .testTag("dynamic_gps_push_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.NotificationsActive,
                                        contentDescription = "Enviar notificación en vivo",
                                        tint = primaryColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        // Visor del mapa interactivo con respaldo vectorial
                        RealInteractiveDeliveryMapView(
                            darkMode = darkMode,
                            primaryColor = primaryColor,
                            branchName = effectiveBranch,
                            branchLat = branchLat,
                            branchLng = branchLng,
                            userLat = userLat,
                            userLng = userLng,
                            telemetry = driverTelemetry,
                            deliveryStage = deliveryStage,
                            animatedX = animatedX,
                            animatedY = animatedY,
                            pulseRadius = pulseRadius
                        )

                        // Franja de métricas de velocidad, tráfico y llegada
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Velocidad actual
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Speed,
                                            contentDescription = "Velocidad estimada",
                                            tint = primaryColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column {
                                            Text(
                                                text = "${driverTelemetry.currentSpeedKmh} km/h",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 13.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Prom. ${driverTelemetry.avgSpeedKmh} km/h",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                // Estado del tráfico
                                val trafficColor = when (driverTelemetry.trafficLevel) {
                                    "DENSO" -> Color(0xFFD97706)
                                    "MODERADO" -> Color(0xFF059669)
                                    else -> Color(0xFF059669)
                                }
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    modifier = Modifier.weight(1.2f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Traffic,
                                            contentDescription = "Estado del tráfico",
                                            tint = trafficColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column {
                                            Text(
                                                text = when (driverTelemetry.trafficLevel) {
                                                    "DENSO" -> "Tráfico Denso"
                                                    "MODERADO" -> "Tráfico Moderado"
                                                    else -> "Tráfico Fluido"
                                                },
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 12.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = if (driverTelemetry.trafficDelayDeltaMin > 0) "+${driverTelemetry.trafficDelayDeltaMin} min por tráfico" else "Ruta despejada",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 10.sp,
                                                color = trafficColor
                                            )
                                        }
                                    }
                                }

                                // Tiempo estimado
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = primaryColor.copy(alpha = 0.12f),
                                    modifier = Modifier.weight(0.95f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = if (deliveryStage == OrderDeliveryStage.DELIVERED) "Entregado" else "~$effectiveEtaMinutes min",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.5.sp,
                                            color = primaryColor
                                        )
                                        Text(
                                            text = "${driverTelemetry.remainingDistanceKm} km rest.",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            DiagonalMetadataStrip(
                                items = listOf(
                                    "Ruta real: $effectiveRoadKm km",
                                    driverTelemetry.trafficCondition,
                                    "Envío base RD$ $deliveryFeeRd (Gratis Bravísima)"
                                ),
                                slashColor = primaryColor,
                                fontSizeSp = 10.5f
                            )

                            OutlinedButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    runCatching {
                                        val gmapsUri = Uri.parse(
                                            "https://www.google.com/maps/dir/?api=1&origin=$branchLat,$branchLng&destination=$userLat,$userLng&travelmode=driving"
                                        )
                                        val mapIntent = Intent(Intent.ACTION_VIEW, gmapsUri).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(mapIntent)
                                    }
                                },
                                border = BorderStroke(1.2.dp, Color(0xFF059669)),
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("open_google_maps_route_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Map,
                                    contentDescription = null,
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Abrir Navegación Completa en Google Maps ($effectiveRoadKm km • ~$effectiveEtaMinutes min)",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF059669)
                                )
                            }
                        }
                    }
                }
            }

            // Chat directo con el repartidor
            item(key = "driver_ai_live_chat_card", contentType = "driver_chat") {
                DriverAiLiveChatCard(
                    darkMode = darkMode,
                    primaryColor = primaryColor,
                    telemetry = driverTelemetry,
                    messages = driverChatMessages,
                    isDriverTyping = isDriverTyping,
                    onSendMessage = onSendDriverMessage,
                    onCallDriver = onCallDriver,
                    onQuickMessageTap = { quickPrompt ->
                        performCrispHaptic(view, HapticStyle.CONFIRM)
                        onSendDriverMessage(quickPrompt)
                    }
                )
            }

            // Progreso detallado de las etapas de entrega
            item(key = "firestore_realtime_progress_card", contentType = "progress_card") {
                TranslucentCard(
                    darkMode = darkMode,
                    cornerRadius = 24.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .testTag("order_tracking_progress_card")
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (isUpdatingOrderStatus) Icons.Default.Sync else Icons.Default.CloudDone,
                                    contentDescription = null,
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Seguimiento en Tiempo Real • #${orderIdDisplay}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF059669),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = primaryColor.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = activeOrder?.date ?: deliveryStage.updatedDateLabel,
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = primaryColor,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    BravoUnifiedIcon(
                                        iconKey = deliveryStage.emoji,
                                        tint = primaryColor,
                                        size = 20.dp
                                    )
                                    Text(
                                        text = deliveryStage.statusText,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 19.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.testTag("order_delivery_status_label")
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = deliveryStage.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(56.dp)
                            ) {
                                CircularProgressIndicator(
                                    progress = { animatedProgress },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("order_delivery_circular_progress"),
                                    color = if (deliveryStage == OrderDeliveryStage.DELIVERED) {
                                        Color(0xFF059669)
                                    } else {
                                        primaryColor
                                    },
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    strokeWidth = 5.dp
                                )
                                Text(
                                    text = "${deliveryStage.progressPct}%",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                DiagonalMetadataStrip(
                                    items = listOf(
                                        "Progreso de entrega",
                                        "Etapa ${deliveryStage.stepNumber} de ${OrderDeliveryStage.entries.size}",
                                        effectiveBranch
                                    ),
                                    slashColor = primaryColor,
                                    fontSizeSp = 10.5f
                                )
                                Text(
                                    text = "${(animatedProgress * 100).roundToInt()}%",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }

                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .testTag("order_delivery_progress_indicator"),
                                color = if (deliveryStage == OrderDeliveryStage.DELIVERED) {
                                    Color(0xFF059669)
                                } else {
                                    primaryColor
                                },
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OrderDeliveryStage.entries.forEach { stage ->
                                val isReached = stage.stepNumber <= deliveryStage.stepNumber
                                val isCurrent = stage == deliveryStage
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            performCrispHaptic(view, HapticStyle.CONFIRM)
                                            onSelectDeliveryStage(stage)
                                        }
                                        .padding(vertical = 4.dp)
                                        .testTag("order_stage_step_${stage.stepNumber}")
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(if (isCurrent) 30.dp else 26.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    isCurrent -> primaryColor
                                                    isReached -> Color(0xFF059669)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            )
                                            .border(
                                                width = if (isCurrent) 2.dp else 0.dp,
                                                color = if (isCurrent) Color.White else Color.Transparent,
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isReached && !isCurrent) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = stage.shortLabel,
                                                tint = Color.White,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        } else {
                                            BravoUnifiedIcon(
                                                iconKey = stage.emoji,
                                                tint = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                size = if (isCurrent) 15.dp else 13.dp
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = stage.shortLabel,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        fontSize = 10.sp,
                                        color = when {
                                            isCurrent -> primaryColor
                                            isReached -> MaterialTheme.colorScheme.onSurface
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = firestoreSyncStatus,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onAdvanceDeliveryStage()
                                },
                                border = BorderStroke(1.2.dp, primaryColor),
                                shape = RoundedCornerShape(999.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("advance_order_status_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Actualizar etapa de entrega",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.sp,
                                    color = primaryColor
                                )
                            }
                        }
                    }
                }
            }

            if (trackedProducts.isNotEmpty()) {
                item(key = "delivery_order_items_card", contentType = "order_items") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Artículos en este envío (${trackedProducts.size})",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                BravoUnderline(isArca = false)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Cadena de frío activa • Orden #$orderIdDisplay",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFF059669),
                                    textAlign = TextAlign.Center
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                trackedProducts.forEach { (prod, qty) ->
                                    Surface(
                                        onClick = { onOpenProduct(prod.sku) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                        modifier = Modifier.width(128.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Box(
                                                modifier = Modifier.size(54.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                ProductArtworkView(product = prod)
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = prod.name,
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "x$qty • RD$ ${prod.price}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = primaryColor
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        HapticFeedbackManager.onNavigationClick(view)
                        onBack()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("delivery_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        tint = primaryColor
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "Seguimiento en Tiempo Real",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = false)
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (deliveryStage == OrderDeliveryStage.DELIVERED) {
                        Color(0xFFECFDF5)
                    } else {
                        primaryColor.copy(alpha = 0.12f)
                    }
                ) {
                    Text(
                        text = if (deliveryStage == OrderDeliveryStage.DELIVERED) {
                            "Entregado"
                        } else {
                            "${driverTelemetry.currentSpeedKmh} km/h • ~$effectiveEtaMinutes min"
                        },
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        color = if (deliveryStage == OrderDeliveryStage.DELIVERED) {
                            Color(0xFF047857)
                        } else {
                            primaryColor
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LiveDeliveryNotificationBannerCard(
    banner: LiveDeliveryBannerNotification?,
    deliveryStage: OrderDeliveryStage,
    telemetry: DriverLiveTelemetry,
    orderIdDisplay: String,
    darkMode: Boolean,
    primaryColor: Color,
    onTriggerSystemNotification: () -> Unit,
    onDismiss: () -> Unit
) {
    val activeTitle = banner?.title ?: "${deliveryStage.statusText} • Carlos Rodríguez en ruta"
    val activeSubtitle = banner?.subtitle ?: "${telemetry.currentStreet} • ${telemetry.trafficCondition}"
    val activeIconKey = banner?.iconKey ?: deliveryStage.emoji
    val speedKmh = banner?.speedKmh ?: telemetry.currentSpeedKmh
    val etaMin = banner?.etaMinutes ?: telemetry.dynamicEtaMinutes
    val progressFraction = banner?.let { (it.progressPct / 100f).coerceIn(0f, 1f) } ?: deliveryStage.progressFraction

    TranslucentCard(
        darkMode = darkMode,
        cornerRadius = 22.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .testTag("live_delivery_notification_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(primaryColor.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        BravoUnifiedIcon(
                            iconKey = activeIconKey,
                            tint = primaryColor,
                            size = 20.dp
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = "Notificación en vivo",
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "NOTIFICACIÓN LIVE • #$orderIdDisplay",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp,
                                color = Color(0xFF059669)
                            )
                        }
                        Text(
                            text = activeTitle,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = activeSubtitle,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        onClick = onTriggerSystemNotification,
                        shape = RoundedCornerShape(999.dp),
                        color = primaryColor.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "$speedKmh km/h",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.5.sp,
                                color = primaryColor
                            )
                        }
                    }
                    if (banner != null) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(22.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Ocultar aviso",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsBike,
                        contentDescription = null,
                        tint = Color(0xFF059669),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (deliveryStage == OrderDeliveryStage.DELIVERED) "Pedido entregado en tu puerta" else "Llegada estimada en ~$etaMin min • ${telemetry.remainingDistanceKm} km",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "${(progressFraction * 100).roundToInt()}%",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp,
                    color = primaryColor
                )
            }

            LinearProgressIndicator(
                progress = { progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = Color(0xFF059669),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
private fun RealInteractiveDeliveryMapView(
    darkMode: Boolean,
    primaryColor: Color,
    branchName: String,
    branchLat: Double,
    branchLng: Double,
    userLat: Double,
    userLng: Double,
    telemetry: DriverLiveTelemetry,
    deliveryStage: OrderDeliveryStage,
    animatedX: Float,
    animatedY: Float,
    pulseRadius: Float
) {
    var zoomLevel by remember { mutableFloatStateOf(1f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }
    var followDriver by remember { mutableStateOf(true) }

    val animatedZoom by animateFloatAsState(
        targetValue = zoomLevel,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "mapZoom"
    )

    val infiniteFlow = rememberInfiniteTransition(label = "routeFlow")
    val dashPhase by infiniteFlow.animateFloat(
        initialValue = 36f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 950, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dashPhase"
    )

    val mapBgColor = if (darkMode) Color(0xFF0C1320) else Color(0xFFE9EEF5)
    val blockColor = if (darkMode) Color(0xFF131C2E) else Color(0xFFF4F7FB)
    val parkColor = if (darkMode) Color(0xFF102A22) else Color(0xFFD6EFE0)
    val waterColor = if (darkMode) Color(0xFF0E2238) else Color(0xFFCFE6FA)
    val secondaryStreetColor = if (darkMode) Color(0xFF1E293B) else Color(0xFFFFFFFF)
    val primaryAvenueColor = if (darkMode) Color(0xFF283548) else Color(0xFFFFFBEB)
    val avenueBorderColor = if (darkMode) Color(0xFF334155) else Color(0xFFCBD5E1)
    val routeActiveColor = when (telemetry.trafficLevel) {
        "DENSO" -> Color(0xFFF59E0B)
        "MODERADO" -> Color(0xFF10B981)
        else -> Color(0xFF059669)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(310.dp)
            .background(mapBgColor)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    followDriver = false
                    panOffsetX = (panOffsetX + dragAmount.x).coerceIn(-180f, 180f)
                    panOffsetY = (panOffsetY + dragAmount.y).coerceIn(-140f, 140f)
                }
            }
            .testTag("interactive_real_map_webview")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val focusX = if (followDriver && zoomLevel > 1.05f) (0.5f - animatedX) * w * 0.45f else panOffsetX
            val focusY = if (followDriver && zoomLevel > 1.05f) (0.5f - animatedY) * h * 0.45f else panOffsetY

            fun project(xFrac: Float, yFrac: Float): Offset {
                val cx = w * 0.5f
                val cy = h * 0.5f
                val rawX = w * xFrac
                val rawY = h * yFrac
                return Offset(
                    x = cx + (rawX - cx) * animatedZoom + focusX,
                    y = cy + (rawY - cy) * animatedZoom + focusY
                )
            }

            // Manzanas urbanas y áreas verdes (Polígono Central)
            val blocks = listOf(
                Triple(Offset(0.04f, 0.06f), Offset(0.18f, 0.19f), blockColor),
                Triple(Offset(0.26f, 0.05f), Offset(0.45f, 0.19f), blockColor),
                Triple(Offset(0.51f, 0.05f), Offset(0.64f, 0.19f), blockColor),
                Triple(Offset(0.04f, 0.27f), Offset(0.18f, 0.43f), blockColor),
                Triple(Offset(0.26f, 0.27f), Offset(0.45f, 0.43f), blockColor),
                Triple(Offset(0.51f, 0.27f), Offset(0.64f, 0.43f), blockColor),
                Triple(Offset(0.72f, 0.36f), Offset(0.94f, 0.44f), blockColor),
                Triple(Offset(0.35f, 0.54f), Offset(0.64f, 0.70f), blockColor),
                Triple(Offset(0.72f, 0.54f), Offset(0.95f, 0.70f), blockColor),
                Triple(Offset(0.35f, 0.78f), Offset(0.64f, 0.94f), blockColor)
            )
            blocks.forEach { (tl, br, col) ->
                val p1 = project(tl.x, tl.y)
                val p2 = project(br.x, br.y)
                drawRoundRect(
                    color = col,
                    topLeft = p1,
                    size = Size((p2.x - p1.x).coerceAtLeast(4f), (p2.y - p1.y).coerceAtLeast(4f)),
                    cornerRadius = CornerRadius(12f * animatedZoom, 12f * animatedZoom)
                )
            }

            // Parques y áreas verdes
            val park1TL = project(0.05f, 0.55f)
            val park1BR = project(0.29f, 0.89f)
            drawRoundRect(
                color = parkColor,
                topLeft = park1TL,
                size = Size((park1BR.x - park1TL.x).coerceAtLeast(8f), (park1BR.y - park1TL.y).coerceAtLeast(8f)),
                cornerRadius = CornerRadius(18f * animatedZoom, 18f * animatedZoom)
            )

            val park2TL = project(0.71f, 0.07f)
            val park2BR = project(0.94f, 0.30f)
            drawRoundRect(
                color = parkColor,
                topLeft = park2TL,
                size = Size((park2BR.x - park2TL.x).coerceAtLeast(8f), (park2BR.y - park2TL.y).coerceAtLeast(8f)),
                cornerRadius = CornerRadius(18f * animatedZoom, 18f * animatedZoom)
            )

            val lakeTL = project(0.09f, 0.64f)
            val lakeBR = project(0.21f, 0.78f)
            drawRoundRect(
                color = waterColor,
                topLeft = lakeTL,
                size = Size((lakeBR.x - lakeTL.x).coerceAtLeast(4f), (lakeBR.y - lakeTL.y).coerceAtLeast(4f)),
                cornerRadius = CornerRadius(24f * animatedZoom, 24f * animatedZoom)
            )

            // Red de calles secundarias
            val secondaryStreets = listOf(
                Offset(0f, 0.22f) to Offset(1f, 0.22f),
                Offset(0f, 0.74f) to Offset(1f, 0.74f),
                Offset(0.48f, 0f) to Offset(0.48f, 1f),
                Offset(0.32f, 0f) to Offset(0.32f, 1f),
                Offset(0.84f, 0f) to Offset(0.84f, 1f),
                Offset(0.18f, 0.22f) to Offset(0.84f, 0.76f)
            )
            secondaryStreets.forEach { (s, e) ->
                val pStart = project(s.x, s.y)
                val pEnd = project(e.x, e.y)
                drawLine(
                    color = avenueBorderColor,
                    start = pStart,
                    end = pEnd,
                    strokeWidth = 13f * animatedZoom,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = secondaryStreetColor,
                    start = pStart,
                    end = pEnd,
                    strokeWidth = 10f * animatedZoom,
                    cap = StrokeCap.Round
                )
            }

            // Avenidas principales (Churchill, Lincoln, 27 de Febrero)
            val mainAvenues = listOf(
                Offset(0.21f, 0f) to Offset(0.21f, 1f),
                Offset(0.68f, 0f) to Offset(0.68f, 1f),
                Offset(0f, 0.48f) to Offset(1f, 0.48f)
            )
            mainAvenues.forEach { (s, e) ->
                val pStart = project(s.x, s.y)
                val pEnd = project(e.x, e.y)
                drawLine(
                    color = avenueBorderColor,
                    start = pStart,
                    end = pEnd,
                    strokeWidth = 22f * animatedZoom,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = primaryAvenueColor,
                    start = pStart,
                    end = pEnd,
                    strokeWidth = 18f * animatedZoom,
                    cap = StrokeCap.Round
                )
            }

            // Etiquetas de avenidas
            drawIntoCanvas { canvas ->
                val labelPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = if (darkMode) android.graphics.Color.argb(215, 203, 213, 225) else android.graphics.Color.argb(220, 51, 65, 85)
                    textSize = (10.5f * animatedZoom).coerceIn(9f, 15f) * density
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }
                val parkPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = if (darkMode) android.graphics.Color.argb(210, 110, 231, 183) else android.graphics.Color.argb(220, 4, 120, 87)
                    textSize = (9.5f * animatedZoom).coerceIn(8.5f, 13f) * density
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }

                val av27Pos = project(0.35f, 0.465f)
                canvas.nativeCanvas.drawText("Av. 27 de Febrero", av27Pos.x, av27Pos.y, labelPaint)

                val pastorizaPos = project(0.24f, 0.205f)
                canvas.nativeCanvas.drawText("C. Roberto Pastoriza", pastorizaPos.x, pastorizaPos.y, labelPaint)

                val mejiaPos = project(0.36f, 0.725f)
                canvas.nativeCanvas.drawText("Av. Gustavo Mejía Ricart", mejiaPos.x, mejiaPos.y, labelPaint)

                val churchillPos = project(0.03f, 0.38f)
                canvas.nativeCanvas.drawText("Av. Churchill", churchillPos.x, churchillPos.y, labelPaint)

                val lincolnPos = project(0.70f, 0.62f)
                canvas.nativeCanvas.drawText("Av. Lincoln", lincolnPos.x, lincolnPos.y, labelPaint)

                val park1Label = project(0.07f, 0.61f)
                canvas.nativeCanvas.drawText("Parque La Lira", park1Label.x, park1Label.y, parkPaint)

                val park2Label = project(0.73f, 0.16f)
                canvas.nativeCanvas.drawText("Plaza Piantini", park2Label.x, park2Label.y, parkPaint)
            }

            // Trazado de la ruta (tramo recorrido y tramo pendiente)
            val routePoints = SANTO_DOMINGO_ROUTE.map { pt -> project(pt.xFraction, pt.yFraction) }
            if (routePoints.size >= 2) {
                val fullRoutePath = Path().apply {
                    moveTo(routePoints.first().x, routePoints.first().y)
                    for (i in 1 until routePoints.size) {
                        lineTo(routePoints[i].x, routePoints[i].y)
                    }
                }
                // Halo exterior de la ruta
                drawPath(
                    path = fullRoutePath,
                    color = primaryColor.copy(alpha = 0.24f),
                    style = Stroke(width = 18f * animatedZoom, cap = StrokeCap.Round)
                )
                // Carril base de la ruta
                drawPath(
                    path = fullRoutePath,
                    color = routeActiveColor.copy(alpha = 0.35f),
                    style = Stroke(width = 9f * animatedZoom, cap = StrokeCap.Round)
                )
                // Flujo animado de avance
                drawPath(
                    path = fullRoutePath,
                    color = routeActiveColor,
                    style = Stroke(
                        width = 6.5f * animatedZoom,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), dashPhase)
                    )
                )
            }

            // Marcador de sucursal de origen
            val originCenter = project(SANTO_DOMINGO_ROUTE.first().xFraction, SANTO_DOMINGO_ROUTE.first().yFraction)
            drawCircle(
                color = primaryColor.copy(alpha = 0.24f),
                radius = 18f * animatedZoom,
                center = originCenter
            )
            drawCircle(
                color = Color.White,
                radius = 11f * animatedZoom,
                center = originCenter
            )
            drawCircle(
                color = primaryColor,
                radius = 8f * animatedZoom,
                center = originCenter
            )

            // Marcador de dirección de entrega
            val destCenter = project(SANTO_DOMINGO_ROUTE.last().xFraction, SANTO_DOMINGO_ROUTE.last().yFraction)
            drawCircle(
                color = Color(0xFF059669).copy(alpha = 0.26f),
                radius = 20f * animatedZoom,
                center = destCenter
            )
            drawCircle(
                color = Color.White,
                radius = 12f * animatedZoom,
                center = destCenter
            )
            drawCircle(
                color = Color(0xFF059669),
                radius = 8.5f * animatedZoom,
                center = destCenter
            )

            // Posición actual del repartidor con pulso de radar
            val driverCenter = project(animatedX, animatedY)
            // Tramo ya recorrido desde la sucursal
            drawLine(
                color = primaryColor,
                start = originCenter,
                end = driverCenter,
                strokeWidth = 6f * animatedZoom,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = primaryColor.copy(alpha = 0.28f),
                radius = pulseRadius * animatedZoom,
                center = driverCenter
            )
            drawCircle(
                color = Color.White,
                radius = 14f * animatedZoom,
                center = driverCenter
            )
            drawCircle(
                color = primaryColor,
                radius = 10.5f * animatedZoom,
                center = driverCenter
            )
            drawCircle(
                color = Color.White,
                radius = 4f * animatedZoom,
                center = driverCenter
            )

            // Etiquetas flotantes de origen, destino y repartidor
            drawIntoCanvas { canvas ->
                val pillBgPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = if (darkMode) android.graphics.Color.argb(235, 15, 23, 42) else android.graphics.Color.argb(242, 255, 255, 255)
                }
                val pillTextPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = if (darkMode) android.graphics.Color.WHITE else android.graphics.Color.rgb(15, 23, 42)
                    textSize = 10.5f * density
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }

                // Etiqueta de origen
                val originLabel = "🏪 $branchName"
                val oWidth = pillTextPaint.measureText(originLabel) + 18f * density
                val oHeight = 20f * density
                val oRect = android.graphics.RectF(
                    (originCenter.x - oWidth / 2f).coerceIn(8f, w - oWidth - 8f),
                    (originCenter.y - 30f * density).coerceIn(8f, h - oHeight - 8f),
                    (originCenter.x + oWidth / 2f).coerceIn(oWidth + 8f, w - 8f),
                    (originCenter.y - 10f * density).coerceIn(oHeight + 8f, h - 8f)
                )
                canvas.nativeCanvas.drawRoundRect(oRect, 999f, 999f, pillBgPaint)
                canvas.nativeCanvas.drawText(originLabel, oRect.left + 9f * density, oRect.centerY() + 3.8f * density, pillTextPaint)

                // Etiqueta de destino
                val destLabel = "📍 Tu Entrega"
                val dWidth = pillTextPaint.measureText(destLabel) + 18f * density
                val dRect = android.graphics.RectF(
                    (destCenter.x - dWidth / 2f).coerceIn(8f, w - dWidth - 8f),
                    (destCenter.y + 12f * density).coerceIn(8f, h - oHeight - 46f * density),
                    (destCenter.x + dWidth / 2f).coerceIn(dWidth + 8f, w - 8f),
                    (destCenter.y + 32f * density).coerceIn(oHeight + 8f, h - 26f * density)
                )
                canvas.nativeCanvas.drawRoundRect(dRect, 999f, 999f, pillBgPaint)
                canvas.nativeCanvas.drawText(destLabel, dRect.left + 9f * density, dRect.centerY() + 3.8f * density, pillTextPaint)

                // Etiqueta del repartidor
                val driverBgPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = android.graphics.Color.rgb(227, 24, 55)
                }
                val driverTextPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    color = android.graphics.Color.WHITE
                    textSize = 11f * density
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }
                val speedText = "🛵 Carlos • ${telemetry.currentSpeedKmh} km/h"
                val drWidth = driverTextPaint.measureText(speedText) + 20f * density
                val drHeight = 22f * density
                val drLeft = (driverCenter.x - drWidth / 2f).coerceIn(10f, (w - drWidth - 10f).coerceAtLeast(10f))
                val drTop = (driverCenter.y - 36f * density).coerceIn(44f * density, (h - drHeight - 48f * density).coerceAtLeast(44f * density))
                val drRect = android.graphics.RectF(drLeft, drTop, drLeft + drWidth, drTop + drHeight)
                canvas.nativeCanvas.drawRoundRect(drRect, 999f, 999f, driverBgPaint)
                canvas.nativeCanvas.drawText(speedText, drRect.left + 10f * density, drRect.centerY() + 4f * density, driverTextPaint)
            }
        }

        // Indicador superior de vía actual y tráfico
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Storefront,
                    contentDescription = null,
                    tint = primaryColor,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "${telemetry.currentStreet} • Tiempo Real 1:1",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Controles de zoom y centrado del mapa
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 12.dp, top = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                shadowElevation = 6.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = {
                            zoomLevel = (zoomLevel + 0.25f).coerceAtMost(2.25f)
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("map_zoom_in_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Acercar mapa",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier.width(24.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                    )
                    IconButton(
                        onClick = {
                            zoomLevel = (zoomLevel - 0.25f).coerceAtLeast(0.85f)
                            if (zoomLevel <= 1f) {
                                panOffsetX = 0f
                                panOffsetY = 0f
                            }
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("map_zoom_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Remove,
                            contentDescription = "Alejar mapa",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Surface(
                onClick = {
                    followDriver = true
                    zoomLevel = 1.15f
                    panOffsetX = 0f
                    panOffsetY = 0f
                },
                shape = RoundedCornerShape(999.dp),
                color = if (followDriver) primaryColor else MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                shadowElevation = 5.dp,
                border = BorderStroke(
                    1.dp,
                    if (followDriver) primaryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                ),
                modifier = Modifier.testTag("map_center_driver_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MyLocation,
                        contentDescription = "Seguir repartidor",
                        tint = if (followDriver) Color.White else primaryColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = if (followDriver) "Siguiendo" else "Centrar",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 9.5.sp,
                        color = if (followDriver) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Resumen inferior de distancia y llegada
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = Color(0xFF0B0F17).copy(alpha = 0.92f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.DirectionsBike,
                    contentDescription = null,
                    tint = Color(0xFF34D399),
                    modifier = Modifier.size(14.dp)
                )
                DiagonalMetadataStrip(
                    items = listOf(
                        "${telemetry.currentSpeedKmh} km/h",
                        "${telemetry.remainingDistanceKm} km restantes",
                        if (deliveryStage == OrderDeliveryStage.DELIVERED) "Entregado" else "ETA ~${telemetry.dynamicEtaMinutes} min"
                    ),
                    slashColor = Color(0xFF34D399),
                    textColor = Color.White,
                    fontSizeSp = 11f
                )
            }
        }
    }
}

@Composable
private fun DriverAiLiveChatCard(
    darkMode: Boolean,
    primaryColor: Color,
    telemetry: DriverLiveTelemetry,
    messages: List<DriverChatMessage>,
    isDriverTyping: Boolean,
    onSendMessage: (String) -> Unit,
    onCallDriver: () -> Unit,
    onQuickMessageTap: (String) -> Unit
) {
    val view = LocalView.current
    var draftMessage by remember { mutableStateOf("") }

    val quickDriverPrompts = remember {
        listOf(
            "¿Por dónde vienes?",
            "¿Cómo está el tráfico?",
            "Déjalo en recepción",
            "Avísame al llegar",
            "¿Viene fría la compra?"
        )
    }

    TranslucentCard(
        darkMode = darkMode,
        cornerRadius = 24.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .testTag("driver_ai_chat_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Encabezado del repartidor
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(primaryColor.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DirectionsBike,
                            contentDescription = "Repartidor Carlos Rodríguez",
                            tint = primaryColor,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Carlos Rodríguez",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = Color(0xFF059669).copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = "IA En Ruta • ${telemetry.currentSpeedKmh} km/h",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 9.5.sp,
                                    color = Color(0xFF059669),
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }
                        }
                        DiagonalMetadataStrip(
                            items = listOf("Repartidor BravoVa", "4.95 Estrellas", "Placa K-04921"),
                            slashColor = primaryColor,
                            fontSizeSp = 10.5f
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onCallDriver,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF059669).copy(alpha = 0.14f))
                            .testTag("driver_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Llamar a Carlos",
                            tint = Color(0xFF059669),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            onQuickMessageTap("Hola Carlos, ¿por dónde vienes y en cuánto tiempo llegas?")
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(primaryColor.copy(alpha = 0.12f))
                            .testTag("driver_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "Enviar mensaje rápido a Carlos",
                            tint = primaryColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

            // Mensajes rápidos para el repartidor
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                quickDriverPrompts.forEach { prompt ->
                    Surface(
                        onClick = { onQuickMessageTap(prompt) },
                        shape = RoundedCornerShape(999.dp),
                        color = primaryColor.copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.28f))
                    ) {
                        Text(
                            text = prompt,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = primaryColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Historial de mensajes con el repartidor
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                messages.takeLast(5).forEach { msg ->
                    val isUser = msg.sender == "user"
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            ),
                            color = if (isUser) {
                                primaryColor
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                            },
                            modifier = Modifier.fillMaxWidth(0.88f)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isUser) "Tú" else "🛵 Carlos Rodríguez (Repartidor)",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 10.5.sp,
                                        color = if (isUser) Color.White.copy(alpha = 0.9f) else primaryColor
                                    )
                                    Text(
                                        text = "${msg.timestampLabel} • ${msg.speedKmhAtSend} km/h",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 9.5.sp,
                                        color = if (isUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = msg.text,
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.5.sp,
                                    lineHeight = 17.5.sp,
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                if (isDriverTyping) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = primaryColor
                        )
                        Text(
                            text = "Carlos Rodríguez está respondiendo desde la ruta (${telemetry.currentSpeedKmh} km/h)...",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = primaryColor
                        )
                    }
                }
            }

            // Campo de envío de mensaje
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(999.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(999.dp)
                    )
                    .padding(start = 14.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (draftMessage.isEmpty()) {
                        Text(
                            text = "Escribe un mensaje al repartidor Carlos...",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = draftMessage,
                        onValueChange = { draftMessage = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        ),
                        cursorBrush = SolidColor(primaryColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("driver_chat_input")
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        val clean = draftMessage.trim()
                        if (clean.isNotEmpty()) {
                            performCrispHaptic(view, HapticStyle.CONFIRM)
                            draftMessage = ""
                            onSendMessage(clean)
                        }
                    },
                    enabled = draftMessage.trim().isNotEmpty() && !isDriverTyping,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            if (draftMessage.trim().isNotEmpty() && !isDriverTyping) primaryColor
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .testTag("driver_chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Enviar mensaje al repartidor",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

