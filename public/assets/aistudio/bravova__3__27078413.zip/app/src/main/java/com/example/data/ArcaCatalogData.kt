package com.example.data

import com.example.model.CatalogSection
import com.example.model.Product
import com.example.model.StoreMode

object ArcaCatalogData {

    val ARCA_SECTIONS = listOf(
        CatalogSection("Alimentos Secos", "Alimentos Secos", "kibble_bag"),
        CatalogSection("Alimentos Húmedos y Snacks", "Alimentos Húmedos y Snacks", "wet_food"),
        CatalogSection("Salud y Cuidado Veterinario", "Salud y Cuidado Veterinario", "vet_cross"),
        CatalogSection("Hogar y Arena Sanitaria", "Hogar y Arena Sanitaria", "litter_box"),
        CatalogSection("Accesorios y Paseo", "Accesorios y Paseo", "leash"),
        CatalogSection("Juguetes y Confort", "Juguetes y Confort", "pet_toy")
    )

    private fun p(
        sku: String,
        name: String,
        price: Int,
        category: String,
        unit: String,
        isBravo: Boolean,
        artType: String,
        color: String,
        badge: String,
        img: String
    ) = Product(
        sku = sku,
        name = name,
        price = price,
        category = category,
        unit = unit,
        isBravo = isBravo,
        artType = artType,
        colorHex = color,
        badge = badge,
        imageUrl = img
    )

    val ARCA_PRODUCTS: List<Product> = listOf(
        // 1. Alimentos Secos
        p("ARC-001", "Dog Chow Perros Adultos Raza Pequeña (2 kg)", 325, "Alimentos Secos", "2 Kg", false, "pet_kibble", "#DC2626", "DOG CHOW", "https://images.openpetfoodfacts.org/images/products/001/780/010/1851/front_en.4.400.jpg"),
        p("ARC-002", "Dog Chow Perros Adultos Raza Mediana/Grande (4 kg)", 620, "Alimentos Secos", "4 Kg", false, "pet_kibble", "#B91C1C", "DOG CHOW", "https://images.openpetfoodfacts.org/images/products/761/303/448/8244/front_fr.10.400.jpg"),
        p("ARC-003", "Pro Plan Dog Adult OptiLife (3 kg)", 950, "Alimentos Secos", "3 Kg", false, "pet_kibble", "#7C3AED", "PRO PLAN", "https://images.openpetfoodfacts.org/images/products/761/303/511/4746/front_en.8.400.jpg"),
        p("ARC-004", "Pedigree Perro Cachorro (2 kg)", 340, "Alimentos Secos", "2 Kg", false, "pet_kibble", "#EAB308", "PEDIGREE", "https://images.openpetfoodfacts.org/images/products/590/095/101/7247/front_hu.3.400.jpg"),
        p("ARC-005", "Cat Chow Gato Adulto Pescado (1.5 kg)", 295, "Alimentos Secos", "1.5 Kg", false, "pet_kibble", "#0284C7", "CAT CHOW", "https://images.openpetfoodfacts.org/images/products/001/780/016/6331/front_en.3.400.jpg"),
        p("ARC-006", "Whiskas Gato Adulto Carne (1 kg)", 215, "Alimentos Secos", "1 Kg", false, "pet_kibble", "#9333EA", "WHISKAS", "https://images.openpetfoodfacts.org/images/products/599/874/912/9111/front_fr.7.400.jpg"),
        p("ARC-007", "Royal Canin Mini Adult (2 kg)", 980, "Alimentos Secos", "2 Kg", false, "pet_kibble", "#DC2626", "ROYAL CANIN", "https://images.openpetfoodfacts.org/images/products/318/255/070/2423/front_fr.49.400.jpg"),
        p("ARC-008", "Excellent Cat Adult Salmón (1.5 kg)", 410, "Alimentos Secos", "1.5 Kg", false, "pet_kibble", "#EA580C", "EXCELLENT", "https://images.openpetfoodfacts.org/images/products/930/060/510/2439/front_en.4.400.jpg"),
        p("ARC-049", "Bravo Pet Croquetas Perro Adulto (2.5 kg)", 390, "Alimentos Secos", "2.5 Kg", true, "pet_kibble", "#D9232A", "BRAVO PET", "https://cdn.dummyjson.com/product-images/groceries/dog-food/thumbnail.webp"),
        p("ARC-050", "Bravo Pet Gatos Sabor Pescado (1.5 kg)", 245, "Alimentos Secos", "1.5 Kg", true, "pet_kibble", "#0D9488", "BRAVO PET", "https://cdn.dummyjson.com/product-images/groceries/cat-food/thumbnail.webp"),

        // 2. Alimentos Húmedos y Snacks
        p("ARC-009", "Sobre Pedigree Húmedo Pollo en Salsa (100 g)", 45, "Alimentos Húmedos y Snacks", "100 Gr", false, "pet_wet", "#EAB308", "PEDIGREE", "https://images.openpetfoodfacts.org/images/products/002/310/011/7973/front_en.5.400.jpg"),
        p("ARC-010", "Sobre Whiskas Húmedo Atún (85 g)", 42, "Alimentos Húmedos y Snacks", "85 Gr", false, "pet_wet", "#7C3AED", "WHISKAS", "https://images.openpetfoodfacts.org/images/products/306/589/015/3707/front_fr.11.400.jpg"),
        p("ARC-011", "Lata Royal Canin Recovery (195 g)", 220, "Alimentos Húmedos y Snacks", "195 Gr", false, "pet_wet", "#DC2626", "RECOVERY", "https://images.openpetfoodfacts.org/images/products/900/357/931/1462/front_en.15.400.jpg"),
        p("ARC-012", "Snacks Dentastix Pedigree para Raza Mediana", 135, "Alimentos Húmedos y Snacks", "Paquete", false, "pet_snack", "#16A34A", "DENTASTIX", "https://images.openpetfoodfacts.org/images/products/501/039/498/4584/front_hr.41.400.jpg"),
        p("ARC-013", "Premios Biscrok Pedigree (Pack Mediano)", 150, "Alimentos Húmedos y Snacks", "Paquete", false, "pet_snack", "#D97706", "BISCROK", "https://images.openpetfoodfacts.org/images/products/599/874/912/7322/front_bg.3.400.jpg"),
        p("ARC-014", "Catit Creamy Snack para Gatos (Tubos x4)", 190, "Alimentos Húmedos y Snacks", "4 Tubos", false, "pet_snack", "#0D9488", "CATIT", "https://images.openpetfoodfacts.org/images/products/002/251/744/4955/front_en.9.400.jpg"),
        p("ARC-054", "Churu Puré de Pollo Tubo x4 para Gatos", 195, "Alimentos Húmedos y Snacks", "4 Tubos", false, "pet_snack", "#EC4899", "CHURU", "https://images.openpetfoodfacts.org/images/products/085/000/671/5404/front_es.3.400.jpg"),

        // 3. Salud y Cuidado Veterinario
        p("ARC-015", "Antiparasitario NexGard Perros (según peso)", 850, "Salud y Cuidado Veterinario", "1 Pastilla", false, "pet_health", "#15803D", "NEXGARD", "https://images.openproductsfacts.org/images/products/366/110/300/6336/front_pt.5.400.jpg"),
        p("ARC-016", "Pipeta Frontline Plus Perros o Gatos", 650, "Salud y Cuidado Veterinario", "1 Pipeta", false, "pet_health", "#DC2626", "FRONTLINE", "https://images.openproductsfacts.org/images/products/366/110/302/0080/front_pt.8.400.jpg"),
        p("ARC-017", "Champú Antipulgas y Garrapatas Veterinario (500 ml)", 380, "Salud y Cuidado Veterinario", "500 Ml", false, "pet_health", "#2563EB", "CHAMPÚ", "https://images.openproductsfacts.org/images/products/004/566/397/0062/front_xx.13.400.jpg"),
        p("ARC-018", "Cepillo Carda Deslanador para Perros y Gatos", 290, "Salud y Cuidado Veterinario", "1 Unidad", false, "pet_accessory", "#F59E0B", "CEPILLO", "https://images.openproductsfacts.org/images/products/001/027/940/1873/front_pt.5.400.jpg"),
        p("ARC-019", "Toallitas Húmedas Limpiadoras Mascotas (x50)", 220, "Salud y Cuidado Veterinario", "50 Und", false, "paper_wide", "#38BDF8", "TOALLITAS", "https://images.openbeautyfacts.org/images/products/800/184/104/1360/front_en.4.400.jpg"),
        p("ARC-020", "Gotas Limpiadoras de Oídos Otológicas", 350, "Salud y Cuidado Veterinario", "Frasco", false, "pet_health", "#0D9488", "OTOLÓGICAS", "https://images.openbeautyfacts.org/images/products/072/817/701/0553/front_fr.11.400.jpg"),
        p("ARC-076", "Bravecto Masticable Antipulgas Perros 10-20kg", 1450, "Salud y Cuidado Veterinario", "1 Pastilla", false, "pet_health", "#15803D", "3 MESES", "https://images.openpetfoodfacts.org/images/products/501/039/499/6587/front_fr.50.400.jpg"),

        // 4. Hogar y Arena Sanitaria
        p("ARC-021", "Arena Aglutinante para Gatos Eco Clean (10 kg)", 490, "Hogar y Arena Sanitaria", "10 Kg", false, "pouch", "#16A34A", "ECO CLEAN", "https://images.openproductsfacts.org/images/products/000/002/001/4056/front_en.3.400.jpg"),
        p("ARC-022", "Arena Sílice Absorbente Gatos (3.8 L)", 310, "Hogar y Arena Sanitaria", "3.8 L", false, "pouch", "#0284C7", "SÍLICE", "https://images.openproductsfacts.org/images/products/841/223/900/0973/front_es.3.400.jpg"),
        p("ARC-023", "Pads / Pañales Entrenadores Cachorros (Pack x10)", 350, "Hogar y Arena Sanitaria", "10 Und", false, "paper_wide", "#38BDF8", "PADS", "https://images.openproductsfacts.org/images/products/401/540/068/0758/front_fr.3.400.jpg"),
        p("ARC-024", "Bandeja Sanitaria Plástica con Pala", 450, "Hogar y Arena Sanitaria", "1 Set", false, "pet_accessory", "#64748B", "BANDEJA", "https://images.openproductsfacts.org/images/products/007/944/100/4007/front_en.3.400.jpg"),
        p("ARC-104", "Arenero Cerrado con Filtro de Carbón y Puerta", 950, "Hogar y Arena Sanitaria", "1 Set", false, "pet_accessory", "#0D9488", "CERRADO", "https://images.openproductsfacts.org/images/products/848/001/723/8825/front_es.3.400.jpg"),

        // 5. Accesorios y Paseo
        p("ARC-025", "Collar Ajustable de Nylon Estampado", 180, "Accesorios y Paseo", "1 Unidad", false, "pet_accessory", "#E11D48", "COLLAR", "https://images.openproductsfacts.org/images/products/570/318/823/3134/front_fr.3.400.jpg"),
        p("ARC-026", "Correa de Paseo Reflectiva Estándar (1.5 m)", 250, "Accesorios y Paseo", "1.5 m", false, "pet_accessory", "#F97316", "CORREA", "https://images.openproductsfacts.org/images/products/570/055/115/1552/front_en.3.400.jpg"),
        p("ARC-027", "Arnés Antitirones Acolchado Mascotas", 490, "Accesorios y Paseo", "1 Unidad", false, "pet_accessory", "#1D4ED8", "ARNÉS", "https://images.openproductsfacts.org/images/products/570/055/125/0651/front_en.3.400.jpg"),
        p("ARC-116", "Fuente de Agua Eléctrica Silenciosa 2.5L", 1250, "Accesorios y Paseo", "2.5 L", false, "pet_accessory", "#0284C7", "FUENTE", "https://images.openproductsfacts.org/images/products/462/000/508/8399/front_ru.10.400.jpg"),
        p("ARC-133", "Mochila Transportadora Gatos Cúpula Burbuja", 1450, "Accesorios y Paseo", "1 Unidad", false, "pet_accessory", "#EAB308", "BURBUJA", "https://images.openproductsfacts.org/images/products/358/519/045/5610/front_en.4.400.jpg"),

        // 6. Juguetes y Confort
        p("ARC-028", "Pelota de Goma Maciza Resistente a Mordeduras", 150, "Juguetes y Confort", "1 Unidad", false, "pet_toy", "#EF4444", "PELOTA", "https://images.openproductsfacts.org/images/products/931/235/700/5340/front_en.3.400.jpg"),
        p("ARC-029", "Juguete Interactivo Kong Classic (Talla M)", 790, "Juguetes y Confort", "Talla M", false, "pet_toy", "#DC2626", "KONG", "https://images.openproductsfacts.org/images/products/541/436/506/6321/front_fr.4.400.jpg"),
        p("ARC-030", "Cama Acolchada Redonda Mediana para Mascotas", 950, "Juguetes y Confort", "1 Unidad", false, "pet_toy", "#8B5CF6", "CAMA", "https://images.openproductsfacts.org/images/products/703/418/471/1608/front_sv.3.400.jpg"),
        p("ARC-108", "Cama Donut Felpa Antiestrés Suave Talla M", 1150, "Juguetes y Confort", "Talla M", false, "pet_toy", "#EC4899", "DONUT", "https://images.openproductsfacts.org/images/products/084/015/504/7297/front_fr.3.400.jpg"),
        p("ARC-112", "Rascador Torre con Hamaca y Cueva 120cm", 2450, "Juguetes y Confort", "120 cm", false, "pet_toy", "#A16207", "TORRE", "https://images.openproductsfacts.org/images/products/357/507/001/5201/front_fr.4.400.jpg")
    )

    private val allProductsBySku: Map<String, Product> by lazy {
        (BravoCatalogData.BRAVO_PRODUCTS + ARCA_PRODUCTS).associateBy { it.sku }
    }

    fun getAllProducts(): List<Product> = BravoCatalogData.BRAVO_PRODUCTS + ARCA_PRODUCTS

    fun getProductsForStore(store: StoreMode): List<Product> =
        if (store == StoreMode.ARCA) ARCA_PRODUCTS else BravoCatalogData.BRAVO_PRODUCTS

    fun getSectionsForStore(store: StoreMode): List<CatalogSection> =
        if (store == StoreMode.ARCA) ARCA_SECTIONS else BravoCatalogData.BRAVO_SECTIONS

    fun findProductBySku(sku: String): Product? = allProductsBySku[sku]
}
