package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.input.ImeAction
import com.example.model.AccountSubScreen
import com.example.model.CartTotals
import com.example.model.ChatMessage
import com.example.model.FcmTopicSubscription
import com.example.model.FrequentProductStat
import com.example.model.NpuHardwareStatus
import com.example.model.OrderDeliveryStage
import com.example.model.OrderRecord
import com.example.model.PaymentMethod
import com.example.model.Product
import com.example.model.PushNotificationRecord
import com.example.model.ShoppingList
import com.example.model.StoreMode
import com.example.model.SuggestionMailPayload
import com.example.model.UserAddress
import com.example.model.UserProfile
import com.example.ui.components.AnimatedPurchaseButton
import com.example.ui.components.BravoUnderline
import com.example.ui.components.BravoUnifiedIcon
import com.example.ui.components.DiagonalMetadataStrip
import com.example.ui.components.FloatingHeaderCapsule
import com.example.ui.components.FormattedChatText
import com.example.ui.components.HapticFeedbackManager
import com.example.ui.components.HapticStyle
import com.example.ui.components.LocalTranslucentHazeState
import com.example.ui.components.ProductArtworkView
import com.example.ui.components.TranslucentCard
import com.example.ui.components.performCrispHaptic
import com.example.ui.components.translucentBackdropEffect
import com.example.ui.components.translucentBackdropSource
import com.example.ui.theme.ArcaTeal
import com.example.ui.theme.ArcaTealDark
import com.example.ui.theme.BravoAmber
import com.example.ui.theme.BravoRedDark
import com.example.ui.theme.FAVORITE_COLOR_PALETTES
import com.example.ui.theme.PlusJakartaSans
import java.text.NumberFormat
import java.util.Locale
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private fun formatPesos(amount: Int): String {
    return NumberFormat.getNumberInstance(Locale.US).format(amount)
}

@Composable
private fun ChatAttachedImagePreview(
    uriString: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageBitmap by produceState<ImageBitmap?>(initialValue = null, key1 = uriString) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(uriString)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }

    if (imageBitmap != null) {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
        ) {
            Image(
                bitmap = imageBitmap!!,
                contentDescription = "Imagen adjunta por el cliente",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun SuggestionMailDispatchedCard(
    payload: SuggestionMailPayload,
    primaryColor: Color
) {
    val context = LocalContext.current
    val view = LocalView.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF059669).copy(alpha = 0.12f),
        border = BorderStroke(1.3.dp, Color(0xFF059669)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("suggestion_mail_payload_card")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        tint = Color(0xFF059669),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "SUGGESTION_MAIL_PAYLOAD • Enviado",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.5.sp,
                        color = Color(0xFF047857),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color(0xFF059669).copy(alpha = 0.20f)
                ) {
                    Text(
                        text = "${payload.category} • ${payload.priority}",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 9.5.sp,
                        color = Color(0xFF047857),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = "Destino oficial: ${payload.toEmail}",
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "Asunto: ${payload.subject}",
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            DiagonalMetadataStrip(
                items = listOf(payload.activeBranch, payload.activeStore.uppercase(), payload.fromUser),
                slashColor = Color(0xFF059669),
                fontSizeSp = 10f
            )

            OutlinedButton(
                onClick = {
                    performCrispHaptic(view, HapticStyle.CONFIRM)
                    runCatching {
                        val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:${payload.toEmail}")
                            putExtra(Intent.EXTRA_SUBJECT, payload.subject)
                            putExtra(
                                Intent.EXTRA_TEXT,
                                """
                                Reporte / Sugerencia Oficial — Brav IA Soporte
                                ---------------------------------------------
                                Destino: ${payload.toEmail}
                                Cliente: ${payload.fromUser} (${payload.userContact})
                                Sucursal Activa: ${payload.activeBranch}
                                Tienda Activa: ${payload.activeStore}
                                Categoría: ${payload.category} | Prioridad: ${payload.priority}
                                Fecha ISO: ${payload.timestampIso}

                                Resumen Ejecutivo:
                                ${payload.summaryBody}
                                """.trimIndent()
                            )
                        }
                        context.startActivity(mailIntent)
                    }
                },
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.1.dp, Color(0xFF059669)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    tint = Color(0xFF047857),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Abrir copia en cliente de correo (${payload.toEmail})",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.5.sp,
                    color = Color(0xFF047857),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private val SoftAiPaletteColors = listOf(
    Color(0xFFF38B9B), // Rosa suave
    Color(0xFFE86A7C), // Carmesí pastel
    Color(0xFFF69E98), // Coral cálido
    Color(0xFFD9657B), // Rubí suave
    Color(0xFFF2828B)  // Rojo rosado
)

private fun sampleSoftAiRedColor(normalizedPhase: Float): Color {
    val clean = ((normalizedPhase % 1f) + 1f) % 1f
    val scaled = clean * SoftAiPaletteColors.size
    val idx = scaled.toInt() % SoftAiPaletteColors.size
    val nextIdx = (idx + 1) % SoftAiPaletteColors.size
    val fraction = scaled - scaled.toInt()
    return lerp(SoftAiPaletteColors[idx], SoftAiPaletteColors[nextIdx], fraction)
}

/**
 * Logo-inspired illuminating stars animation (matching the BravoVa red/amber 4-point star emblem)
 * displayed next to the personalized thinking text while Brav IA is processing or streaming.
 */
@Composable
private fun BravIaLogoSparklingStars(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "bravia_logo_stars")
    val masterPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "starsMasterPhase"
    )
    val badgePulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "starsBadgePulse"
    )

    Box(
        modifier = modifier
            .size(36.dp)
            .testTag("bravia_sparkling_stars_indicator"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Aura cálida del emblema
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFE31837).copy(alpha = 0.28f * badgePulse),
                        Color(0xFFFFB800).copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.5f),
                    radius = w * 0.54f
                ),
                radius = w * 0.54f,
                center = Offset(w * 0.5f, h * 0.5f)
            )

            // Estrellas de 4 puntas con fases escalonadas
            val starConfigs = listOf(
                floatArrayOf(0.42f, 0.52f, 10.5f, 0.00f),
                floatArrayOf(0.76f, 0.26f, 6.8f, 0.28f),
                floatArrayOf(0.22f, 0.22f, 5.6f, 0.55f),
                floatArrayOf(0.78f, 0.75f, 6.2f, 0.78f)
            )

            starConfigs.forEachIndexed { idx, spec ->
                val cx = w * spec[0]
                val cy = h * spec[1]
                val baseR = spec[2].dp.toPx()
                val angle = masterPhase + spec[3] * (2f * PI).toFloat()
                val twinkle = ((sin(angle) + 1f) * 0.5f).coerceIn(0f, 1f)
                val r = baseR * (0.55f + 0.65f * twinkle)
                val innerR = r * 0.24f

                val starColor = when (idx) {
                    0 -> Color(0xFFFFB800).copy(alpha = 0.65f + 0.35f * twinkle)
                    1 -> Color(0xFFFFD54F).copy(alpha = 0.50f + 0.50f * twinkle)
                    2 -> Color(0xFFFF9800).copy(alpha = 0.45f + 0.55f * twinkle)
                    else -> Color(0xFFFFF59D).copy(alpha = 0.50f + 0.50f * twinkle)
                }

                // Halo de la estrella
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            starColor.copy(alpha = 0.55f * twinkle),
                            Color(0xFFE31837).copy(alpha = 0.20f * twinkle),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy),
                        radius = r * 1.5f
                    ),
                    radius = r * 1.5f,
                    center = Offset(cx, cy)
                )

                val starPath = Path().apply {
                    moveTo(cx, cy - r)
                    quadraticTo(cx + innerR * 0.36f, cy - innerR * 0.36f, cx + r, cy)
                    quadraticTo(cx + innerR * 0.36f, cy + innerR * 0.36f, cx, cy + r)
                    quadraticTo(cx - innerR * 0.36f, cy + innerR * 0.36f, cx - r, cy)
                    quadraticTo(cx - innerR * 0.36f, cy - innerR * 0.36f, cx, cy - r)
                    close()
                }
                drawPath(path = starPath, color = starColor)

                // Núcleo brillante
                drawCircle(
                    color = Color.White.copy(alpha = 0.90f * twinkle),
                    radius = max(1.2f, r * 0.18f),
                    center = Offset(cx, cy)
                )
            }
        }
    }
}

/**
 * Generates personalized thinking phrases that vary with each user message and cycle smoothly
 * while Brav IA is thinking.
 */
@Composable
private fun BravIaPersonalizedThinkingRow(
    userQuery: String,
    initialText: String,
    activeBranch: String,
    messageSeed: Long
) {
    val phrases = remember(userQuery, initialText, activeBranch, messageSeed) {
        val cleanQuery = userQuery.trim().replace("\n", " ")
        val snippet = cleanQuery.take(28).ifBlank { "tu consulta" }
        val lower = cleanQuery.lowercase()
        when {
            lower.contains("pide") || lower.contains("pedir") || lower.contains("orden") || lower.contains("compra") -> listOf(
                initialText,
                "Verificando existencias de «$snippet» en $activeBranch...",
                "Calculando precios exactos en RD$ y retorno Bravísima...",
                "Preparando el resumen de tu pedido en el chat..."
            )
            lower.contains("receta") || lower.contains("paso") || lower.contains("cocinar") || lower.contains("hacer") || lower.contains("mangu") || lower.contains("sancocho") || lower.contains("pasta") || lower.contains("pastelon") -> listOf(
                initialText,
                "Consultando medidas verificadas en la web para «$snippet»...",
                "Detallando tiempos exactos en minutos y temperaturas en °C/°F...",
                "Ajustando los productos a tu presupuesto en $activeBranch..."
            )
            lower.contains("precio") || lower.contains("cuanto") || lower.contains("cuesta") -> listOf(
                initialText,
                "Consultando precios en RD$ para «$snippet» en los 12 pasillos...",
                "Comparando presentaciones Marca Exclusiva Bravo...",
                "Preparando tu respuesta personalizada al detalle..."
            )
            else -> {
                val variants = listOf(
                    listOf(
                        initialText,
                        "Buscando coincidencias para «$snippet» entre los 402 artículos...",
                        "Verificando disponibilidad inmediata en $activeBranch...",
                        "Redactando una respuesta personalizada para ti..."
                    ),
                    listOf(
                        "Revisando nuestros 12 pasillos oficiales para «$snippet»...",
                        initialText,
                        "Consultando precios actualizados en RD$ y detalles...",
                        "Afinando las mejores recomendaciones de Bravo para ti..."
                    )
                )
                variants[( kotlin.math.abs(messageSeed) % variants.size ).toInt()]
            }
        }.distinct()
    }

    var phraseIndex by remember(messageSeed) { mutableIntStateOf(0) }
    LaunchedEffect(phrases, messageSeed) {
        while (true) {
            delay(1350L)
            phraseIndex = (phraseIndex + 1) % phrases.size
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BravIaLogoSparklingStars()

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Brav IA está pensando...",
                fontFamily = PlusJakartaSans,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.5.sp,
                color = Color(0xFFE31837)
            )
            AnimatedContent(
                targetState = phrases[phraseIndex % phrases.size],
                transitionSpec = {
                    fadeIn(animationSpec = tween(260)) togetherWith fadeOut(animationSpec = tween(180))
                },
                label = "thinking_phrase_transition"
            ) { currentPhrase ->
                Text(
                    text = currentPhrase,
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.5.sp,
                    lineHeight = 17.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Contorno luminoso animado para los mensajes de Brav IA.
 * Cuando el asistente está respondiendo activamente, recorre el borde con un haz suave;
 * en mensajes ya completados aplica un reflejo estático sin consumir ciclos de animación.
 */
@Composable
private fun Modifier.glowingRedAiContour(
    isActivelyResponding: Boolean,
    cornerShape: RoundedCornerShape
): Modifier {
    if (!isActivelyResponding) {
        val restColor = SoftAiPaletteColors.first()
        val restSecondary = SoftAiPaletteColors[2]
        return this.drawWithCache {
            val w = size.width
            val h = size.height
            val ambientRadius = max(w, h) * 0.68f
            val ambientBrush = Brush.radialGradient(
                colors = listOf(
                    restColor.copy(alpha = 0.055f),
                    restSecondary.copy(alpha = 0.025f),
                    Color.Transparent
                ),
                center = Offset(w * 0.82f, h * 0.18f),
                radius = ambientRadius
            )
            onDrawWithContent {
                drawCircle(
                    brush = ambientBrush,
                    radius = ambientRadius,
                    center = Offset(w * 0.82f, h * 0.18f)
                )
                drawContent()
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ai_single_line_contour")
    val lineProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "singleLineTraversalProgress"
    )
    val colorPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "softRedColorPhase"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.80f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "softGlowPulse"
    )

    val activeSoftColor = sampleSoftAiRedColor(colorPhase)
    val trailingSoftColor = sampleSoftAiRedColor(colorPhase + 0.22f)

    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val cornerPx = 22.dp.toPx()
        val trailStrokePx = 1.8.dp.toPx()
        val headStrokePx = 2.6.dp.toPx()

        val perimeterPath = Path().apply {
            addRoundRect(
                RoundRect(
                    rect = Rect(0f, 0f, w, h),
                    cornerRadius = CornerRadius(cornerPx, cornerPx)
                )
            )
        }
        val pathMeasure = PathMeasure()
        pathMeasure.setPath(perimeterPath, forceClosed = true)
        val totalLen = pathMeasure.length.coerceAtLeast(1f)

        val singleLineLen = totalLen * 0.28f
        val startDist = (lineProgress * totalLen) % totalLen
        val endDist = startDist + singleLineLen

        val singleLinePath = Path()
        if (endDist <= totalLen) {
            pathMeasure.getSegment(startDist, endDist, singleLinePath, startWithMoveTo = true)
        } else {
            pathMeasure.getSegment(startDist, totalLen, singleLinePath, startWithMoveTo = true)
            pathMeasure.getSegment(0f, endDist - totalLen, singleLinePath, startWithMoveTo = true)
        }

        val headSliceLen = singleLineLen * 0.40f
        val headStartDist = (startDist + singleLineLen - headSliceLen) % totalLen
        val headEndDist = headStartDist + headSliceLen
        val headLinePath = Path()
        if (headEndDist <= totalLen) {
            pathMeasure.getSegment(headStartDist, headEndDist, headLinePath, startWithMoveTo = true)
        } else {
            pathMeasure.getSegment(headStartDist, totalLen, headLinePath, startWithMoveTo = true)
            pathMeasure.getSegment(0f, headEndDist - totalLen, headLinePath, startWithMoveTo = true)
        }

        val headFraction = ((endDist % totalLen) / totalLen)
        val headAngle = headFraction * (2f * PI).toFloat()
        val headCenter = Offset(
            x = (w * 0.5f + cos(headAngle) * (w * 0.48f)).coerceIn(0f, w),
            y = (h * 0.5f + sin(headAngle) * (h * 0.48f)).coerceIn(0f, h)
        )
        val ambientRadius = max(w, h) * 0.72f

        onDrawWithContent {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        activeSoftColor.copy(alpha = 0.15f * glowPulse),
                        trailingSoftColor.copy(alpha = 0.07f * glowPulse),
                        Color.Transparent
                    ),
                    center = headCenter,
                    radius = ambientRadius
                ),
                radius = ambientRadius,
                center = headCenter
            )
            drawContent()
            drawPath(
                path = singleLinePath,
                color = trailingSoftColor.copy(alpha = 0.45f * glowPulse),
                style = Stroke(width = trailStrokePx, cap = StrokeCap.Round)
            )
            drawPath(
                path = headLinePath,
                color = activeSoftColor.copy(alpha = 0.85f * glowPulse),
                style = Stroke(width = headStrokePx, cap = StrokeCap.Round)
            )
        }
    }
}

private fun parseRecipeStepsFromText(rawText: String): List<String> {
    val lines = rawText.lines()
    val steps = mutableListOf<String>()
    val stepRegex = Regex("""^\s*(?:\*\*?)?(?:Paso\s*\d+|Step\s*\d+|\d+[\.\)])(?:\*\*?)?[:\-\s]+(.+)$""", RegexOption.IGNORE_CASE)
    for (line in lines) {
        val cleanLine = line.trim()
        val match = stepRegex.find(cleanLine)
        if (match != null) {
            val stepBody = match.groupValues[1].replace("**", "").trim()
            if (stepBody.length > 8) {
                steps.add(stepBody)
            }
        }
    }
    return steps
}

@Composable
fun BravIaChatScreen(
    storeMode: StoreMode,
    darkMode: Boolean,
    messages: List<ChatMessage>,
    isGenerating: Boolean,
    budgetAmount: Int,
    cartTotals: CartTotals,
    activeBranch: String = "Bravo Winston Churchill",
    estimatedEtaMinutes: Int = 12,
    areMenusVisible: Boolean = true,
    npuStatus: NpuHardwareStatus = NpuHardwareStatus(),
    onToggleNpuMode: () -> Unit = {},
    pendingImageUri: String? = null,
    onSelectImageUri: (String?) -> Unit = {},
    productLookup: (String) -> Product?,
    onBack: () -> Unit,
    onOpenCart: () -> Unit,
    onOpenMyLists: () -> Unit = {},
    onBudgetChange: (Int) -> Unit,
    onBuildCartForBudget: () -> Unit,
    onAdjustCartToBudget: () -> Unit,
    onSendPrompt: (String) -> Unit,
    onPauseGeneration: () -> Unit = {},
    onAddBundleForMessage: (Long) -> Unit,
    onSaveBundleAsList: (Long) -> Unit = {},
    onRequestOrderConfirmation: (Long) -> Unit = {},
    onConfirmOrderFromChat: (Long) -> Unit = {},
    onCancelOrderConfirmation: (Long) -> Unit = {},
    onAddSingleProduct: (String) -> Unit,
    onOpenProduct: (String) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val isArca = storeMode == StoreMode.ARCA
    val primaryColor = if (isArca) ArcaTeal else MaterialTheme.colorScheme.primary
    val darkPrimaryColor = if (isArca) ArcaTealDark else BravoRedDark
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSelectImageUri(uri.toString())
        }
    }

    var isLiveVoiceModeActive by remember { mutableStateOf(false) }
    var isVoicePaused by remember { mutableStateOf(false) }
    var isListeningMic by remember { mutableStateOf(false) }
    var isSpeakingTts by remember { mutableStateOf(false) }
    var voiceStatusLabel by remember { mutableStateOf("Micrófono listo • Habla libremente sin interrupciones") }
    var lastSpokenMessageId by remember { mutableStateOf(messages.lastOrNull()?.id ?: -1L) }

    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }
    var activeRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }

    DisposableEffect(context) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale("es", "DO")
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeakingTts = true
                    }
                    override fun onDone(utteranceId: String?) {
                        isSpeakingTts = false
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeakingTts = false
                    }
                })
            }
        }
        ttsEngine = engine
        onDispose {
            runCatching {
                activeRecognizer?.cancel()
                activeRecognizer?.destroy()
            }
            engine?.stop()
            engine?.shutdown()
        }
    }

    fun stopAllVoiceOutputAndRecording() {
        ttsEngine?.stop()
        isSpeakingTts = false
        runCatching {
            activeRecognizer?.stopListening()
            activeRecognizer?.cancel()
        }
        isListeningMic = false
    }

    fun speakOutLoud(textToSpeak: String) {
        if (isListeningMic || isVoicePaused) return
        val cleanSpeech = textToSpeak
            .replace("**", "")
            .replace("*", "")
            .replace("#", "")
            .trim()
        if (cleanSpeech.isNotEmpty()) {
            isSpeakingTts = true
            ttsEngine?.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "bravia_tts")
        }
    }

    val latestMessage = messages.lastOrNull()
    LaunchedEffect(latestMessage?.id, latestMessage?.isLoading, isGenerating, isLiveVoiceModeActive, isVoicePaused, isListeningMic) {
        if (isLiveVoiceModeActive &&
            !isVoicePaused &&
            !isListeningMic &&
            latestMessage != null &&
            latestMessage.sender == "ai" &&
            !latestMessage.isLoading &&
            !isGenerating &&
            latestMessage.id != lastSpokenMessageId
        ) {
            lastSpokenMessageId = latestMessage.id
            speakOutLoud(latestMessage.text)
        }
    }

    fun startSpeechRecognition() {
        ttsEngine?.stop()
        isSpeakingTts = false
        isVoicePaused = false
        lastSpokenMessageId = messages.lastOrNull()?.id ?: -1L

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            voiceStatusLabel = "Modo voz activo • Elige o escribe tu consulta"
            return
        }
        try {
            runCatching {
                activeRecognizer?.cancel()
                activeRecognizer?.destroy()
            }
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            activeRecognizer = recognizer
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-DO")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    ttsEngine?.stop()
                    isSpeakingTts = false
                    isListeningMic = true
                    voiceStatusLabel = "Escuchando tu voz... (puedes hablar ahora)"
                }
                override fun onBeginningOfSpeech() {
                    ttsEngine?.stop()
                    isSpeakingTts = false
                    isListeningMic = true
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListeningMic = false
                }
                override fun onError(error: Int) {
                    isListeningMic = false
                    voiceStatusLabel = if (isVoicePaused) {
                        "Modo voz en pausa • Toca Reanudar cuando gustes"
                    } else {
                        "Listo para escucharte • Toca Hablar o un chip rápido"
                    }
                }
                override fun onResults(results: Bundle?) {
                    isListeningMic = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()?.trim().orEmpty()
                    if (spoken.isNotEmpty() && !isVoicePaused) {
                        voiceStatusLabel = "Escuchado: \"$spoken\""
                        onSendPrompt(spoken)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (partial.isNotEmpty()) {
                        voiceStatusLabel = "Escuchando: \"$partial...\""
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer.startListening(recognizerIntent)
        } catch (_: Exception) {
            isListeningMic = false
            voiceStatusLabel = "Voz en vivo lista • Dicta tu receta o consulta"
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        lastSpokenMessageId = messages.lastOrNull()?.id ?: -1L
        ttsEngine?.stop()
        isSpeakingTts = false
        isLiveVoiceModeActive = true
        isVoicePaused = false
        if (granted) {
            startSpeechRecognition()
        } else {
            voiceStatusLabel = "Modo Voz Activo • Toca Hablar o elige una consulta"
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    val quickChips = remember(isArca) {
        if (isArca) {
            listOf(
                "Armar mi pedido" to "Pide por mí un combo esencial para mi mascota en El Arca Petshop listo para confirmar en el chat.",
                "Dieta Perro Adulto" to "Recomiéndame el mejor alimento y snacks para un perro adulto de 15 kg bajo mi presupuesto.",
                "Combo Gatos" to "Arma un combo mensual para mi gato con alimento de salmón, arena sanitaria y paté bajo mi presupuesto.",
                "Salud y Parásitos" to "¿Qué productos de farmacia veterinaria me recomiendas para prevención de pulgas, garrapatas e higiene dental?",
                "Enviar Sugerencia" to "Sugiero agregar más variedad de juguetes interactivos hipoalergénicos para cachorros en El Arca."
            )
        } else {
            listOf(
                "Pasos: Pizza Casera" to "Explícame paso a paso cómo hacer una pizza casera con medidas exactas, temperaturas en °C/°F y presupuesto verificado.",
                "Dieta Sin Lactosa" to "Recomiéndame una receta completa sin lactosa con productos del catálogo e indica sus calorías exactas y presupuesto.",
                "Sin Gluten (Celíacos)" to "Dame una receta 100% libre de gluten con ingredientes verificados del catálogo y sus calorías exactas.",
                "Keto y Calorías" to "Ármame una receta alta en proteína y baja en carbohidratos (Keto) detallando las calorías de cada ingrediente.",
                "Armar mi pedido" to "Hazme el pedido de mi compra habitual del supermercado listo para confirmar aquí en el chat.",
                "Facturación NCF y Horarios" to "Explícame cómo funcionan los comprobantes B01 y B02, los horarios de tienda y el retorno del 1% de la Tarjeta Bravísima.",
                "Enviar Sugerencia" to "Sugiero agregar más opciones de postres artesanales sin azúcar marca Bravo en la sucursal."
            )
        }
    }

    // Iluminación ambiental suave de la interfaz de Brav IA
    val uiAmbientTransition = rememberInfiniteTransition(label = "bravia_interface_ambient_glow")
    val uiColorPhase by uiAmbientTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 11500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "uiAmbientColorPhase"
    )
    val uiOrbitAngle by uiAmbientTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "uiAmbientOrbitAngle"
    )
    val ambientSoftPrimary = sampleSoftAiRedColor(uiColorPhase)
    val ambientSoftSecondary = sampleSoftAiRedColor(uiColorPhase + 0.35f)

    val hazeState = LocalTranslucentHazeState.current
    val density = LocalDensity.current
    val isImeVisible = WindowInsets.ime.getBottom(density) > 0
    var topOverlayHeightPx by remember { mutableIntStateOf(0) }
    val topOverlayPadding by animateDpAsState(
        targetValue = with(density) { topOverlayHeightPx.toDp() },
        animationSpec = tween(durationMillis = 200),
        label = "bravia_top_overlay_padding"
    )
    // Ajusta el margen inferior al abrir el teclado o al ocultar la barra de navegación
    val dynamicInputBottomPadding by animateDpAsState(
        targetValue = when {
            isImeVisible -> 8.dp
            areMenusVisible -> 82.dp
            else -> 12.dp
        },
        animationSpec = tween(durationMillis = 220),
        label = "bravia_input_bottom_padding"
    )

    LaunchedEffect(isImeVisible) {
        if (isImeVisible && messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .testTag("bravia_chat_screen")
    ) {
        // Capa de luz ambiental sobre el fondo del chat
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 0f)
        ) {
            val w = size.width
            val h = size.height
            val baseIntensity = if (darkMode) {
                if (isGenerating) 0.08f else 0.04f
            } else {
                if (isGenerating) 0.22f else 0.13f
            }
            val sweepX = w * (0.5f + 0.34f * cos(uiOrbitAngle))
            val sweepY = h * (0.46f + 0.28f * sin(uiOrbitAngle))

            // Luz ambiental principal
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ambientSoftPrimary.copy(alpha = baseIntensity),
                        ambientSoftSecondary.copy(alpha = baseIntensity * 0.55f),
                        Color.Transparent
                    ),
                    center = Offset(sweepX, sweepY),
                    radius = w * 0.88f
                ),
                radius = w * 0.88f,
                center = Offset(sweepX, sweepY)
            )

            // Reflejo superior
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ambientSoftSecondary.copy(alpha = baseIntensity * 0.85f),
                        Color.Transparent
                    ),
                    center = Offset(w * (0.5f - 0.28f * sin(uiOrbitAngle)), h * 0.12f),
                    radius = w * 0.72f
                ),
                radius = w * 0.72f,
                center = Offset(w * (0.5f - 0.28f * sin(uiOrbitAngle)), h * 0.12f)
            )

            // Reflejo inferior
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ambientSoftPrimary.copy(alpha = baseIntensity * 0.90f),
                        Color.Transparent
                    ),
                    center = Offset(w * (0.5f + 0.25f * cos(uiOrbitAngle)), h * 0.88f),
                    radius = w * 0.76f
                ),
                radius = w * 0.76f,
                center = Offset(w * (0.5f + 0.25f * cos(uiOrbitAngle)), h * 0.88f)
            )
        }

        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .translucentBackdropSource(hazeState, zIndex = 1f),
                contentPadding = PaddingValues(
                    start = 14.dp,
                    end = 14.dp,
                    top = topOverlayPadding + 6.dp,
                    bottom = dynamicInputBottomPadding + 108.dp
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "budget_planner_card", contentType = "budget_header") {
                    TranslucentCard(
                    darkMode = darkMode,
                    isArca = isArca,
                    cornerRadius = 20.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Presupuesto Meta en RD$",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            BravoUnderline(isArca = isArca)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "RD$ ${formatPesos(budgetAmount)}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = primaryColor
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        HapticFeedbackManager.onNavigationClick(view)
                                        onOpenMyLists()
                                    },
                                    border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                    shape = RoundedCornerShape(999.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("bravia_open_lists_pill")
                                ) {
                                    Text("Mis Listas", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = primaryColor)
                                }

                                OutlinedButton(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onBuildCartForBudget()
                                    },
                                    enabled = !isGenerating,
                                    border = BorderStroke(1.5.dp, primaryColor),
                                    shape = RoundedCornerShape(999.dp),
                                    contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("budget_build_button")
                                ) {
                                    Text("Armar", fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold, color = primaryColor)
                                }

                                OutlinedButton(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onAdjustCartToBudget()
                                    },
                                    enabled = !isGenerating,
                                    shape = RoundedCornerShape(999.dp),
                                    contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("budget_adjust_button")
                                ) {
                                    Text("Ajustar", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                                }
                            }
                        }

                        Slider(
                            value = budgetAmount.toFloat(),
                            onValueChange = {
                                val stepped = ((it / 50f).roundToInt() * 50).coerceIn(400, 3500)
                                onBudgetChange(stepped)
                            },
                            valueRange = 400f..3500f,
                            colors = SliderDefaults.colors(
                                thumbColor = primaryColor,
                                activeTrackColor = primaryColor
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                                .testTag("budget_slider")
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                onClick = {
                                    if (!isGenerating) {
                                        HapticFeedbackManager.onAssistantTrigger(view)
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(999.dp),
                                color = primaryColor.copy(alpha = 0.16f),
                                border = BorderStroke(1.2.dp, primaryColor)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PhotoCamera,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "Soporte Visual (Foto / NCF)",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.5.sp,
                                        color = primaryColor
                                    )
                                }
                            }

                            quickChips.forEach { (label, prompt) ->
                                Surface(
                                    onClick = {
                                        if (!isGenerating) {
                                            HapticFeedbackManager.onAssistantTrigger(view)
                                            onSendPrompt(prompt)
                                        }
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    color = primaryColor.copy(alpha = 0.10f),
                                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.28f))
                                ) {
                                    Text(
                                        text = label,
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.5.sp,
                                        color = primaryColor,
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            items(
                items = messages,
                key = { it.id },
                contentType = { "chat_message" }
            ) { msg ->
                val isUser = msg.sender == "user"
                val isLatestAiResponding = !isUser && (msg.isLoading || (isGenerating && msg.id == messages.lastOrNull()?.id))
                val msgIndex = messages.indexOfFirst { it.id == msg.id }
                val precedingUserQuery = remember(msg.id, messages.size) {
                    if (msgIndex > 0) {
                        messages.subList(0, msgIndex).lastOrNull { it.sender == "user" }?.text.orEmpty()
                    } else {
                        ""
                    }
                }
                val recommendedProducts: List<Product> = remember(msg.skus) {
                    msg.skus.mapNotNull { sku -> productLookup(sku) }
                }
                val parsedRecipeSteps = remember(msg.text) {
                    if (isUser) emptyList() else parseRecipeStepsFromText(msg.text)
                }
                val bubbleShape = RoundedCornerShape(
                    topStart = 22.dp,
                    topEnd = 22.dp,
                    bottomStart = if (isUser) 22.dp else 8.dp,
                    bottomEnd = if (isUser) 8.dp else 22.dp
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(if (isUser) 0.85f else 0.96f)
                            .clip(bubbleShape)
                            .background(
                                if (isUser) {
                                    Brush.linearGradient(listOf(primaryColor, darkPrimaryColor))
                                } else {
                                    Brush.linearGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                                            MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
                                        )
                                    )
                                }
                            )
                            .then(
                                if (isUser) {
                                    Modifier
                                } else {
                                    Modifier.glowingRedAiContour(
                                        isActivelyResponding = isLatestAiResponding,
                                        cornerShape = bubbleShape
                                    )
                                }
                            )
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!msg.attachedImageUri.isNullOrBlank()) {
                                ChatAttachedImagePreview(
                                    uriString = msg.attachedImageUri,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(170.dp)
                                )
                            }

                            if (msg.isLoading) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        BravIaPersonalizedThinkingRow(
                                            userQuery = precedingUserQuery,
                                            initialText = msg.text,
                                            activeBranch = activeBranch,
                                            messageSeed = msg.id
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        onClick = {
                                            performCrispHaptic(view, HapticStyle.CONFIRM)
                                            stopAllVoiceOutputAndRecording()
                                            onPauseGeneration()
                                        },
                                        shape = RoundedCornerShape(999.dp),
                                        color = Color(0xFFE31837).copy(alpha = 0.14f),
                                        border = BorderStroke(1.2.dp, Color(0xFFE31837)),
                                        modifier = Modifier.testTag("bravia_pause_card_button")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Pause,
                                                contentDescription = "Pausar respuesta de IA",
                                                tint = Color(0xFFE31837),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "Pausar",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                color = Color(0xFFE31837)
                                            )
                                        }
                                    }
                                }
                            } else {
                                if (isLatestAiResponding) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            BravIaLogoSparklingStars(modifier = Modifier.size(28.dp))
                                            Text(
                                                text = "Respondiendo de forma personalizada para ti...",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                color = Color(0xFFE31837),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Surface(
                                            onClick = {
                                                performCrispHaptic(view, HapticStyle.CONFIRM)
                                                stopAllVoiceOutputAndRecording()
                                                onPauseGeneration()
                                            },
                                            shape = RoundedCornerShape(999.dp),
                                            color = Color(0xFFE31837).copy(alpha = 0.14f),
                                            border = BorderStroke(1.dp, Color(0xFFE31837))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Pause,
                                                    contentDescription = "Pausar",
                                                    tint = Color(0xFFE31837),
                                                    modifier = Modifier.size(13.dp)
                                                )
                                                Text(
                                                    text = "Pausar",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 10.5.sp,
                                                    color = Color(0xFFE31837)
                                                )
                                            }
                                        }
                                    }
                                }
                                FormattedChatText(
                                    rawText = msg.text,
                                    textColor = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                )

                                if (!isUser && msg.suggestionPayload != null) {
                                    SuggestionMailDispatchedCard(
                                        payload = msg.suggestionPayload,
                                        primaryColor = primaryColor
                                    )
                                }

                                if (!isUser && parsedRecipeSteps.isNotEmpty()) {
                                    RecipeStepsVisualCard(
                                        steps = parsedRecipeSteps,
                                        primaryColor = primaryColor,
                                        isSpeaking = isSpeakingTts,
                                        onSpeakSteps = {
                                            performCrispHaptic(view, HapticStyle.CONFIRM)
                                            isVoicePaused = false
                                            speakOutLoud(parsedRecipeSteps.mapIndexed { idx, s -> "Paso ${idx + 1}: $s" }.joinToString(". "))
                                        },
                                        onPauseSpeech = {
                                            performCrispHaptic(view, HapticStyle.TICK)
                                            isVoicePaused = true
                                            stopAllVoiceOutputAndRecording()
                                        }
                                    )
                                }

                                if (!isUser && msg.text.length > 20) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isSpeakingTts) {
                                            Surface(
                                                onClick = {
                                                    performCrispHaptic(view, HapticStyle.TICK)
                                                    isVoicePaused = true
                                                    stopAllVoiceOutputAndRecording()
                                                },
                                                shape = RoundedCornerShape(999.dp),
                                                color = Color(0xFFE31837).copy(alpha = 0.12f),
                                                modifier = Modifier.padding(end = 6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Pause,
                                                        contentDescription = "Pausar narración",
                                                        tint = Color(0xFFE31837),
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Text(
                                                        text = "Pausar voz",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 11.sp,
                                                        color = Color(0xFFE31837)
                                                    )
                                                }
                                            }
                                        }
                                        Surface(
                                            onClick = {
                                                performCrispHaptic(view, HapticStyle.TICK)
                                                isVoicePaused = false
                                                speakOutLoud(msg.text)
                                            },
                                            shape = RoundedCornerShape(999.dp),
                                            color = primaryColor.copy(alpha = 0.10f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                                    contentDescription = "Escuchar respuesta en voz alta",
                                                    tint = primaryColor,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Text(
                                                    text = "Escuchar en voz",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 11.sp,
                                                    color = primaryColor
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (!isUser && recommendedProducts.isNotEmpty()) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "Artículos del Catálogo (${recommendedProducts.size})",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    BravoUnderline(isArca = isArca)
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    recommendedProducts.forEach { prod ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                                                .clickable { onOpenProduct(prod.sku) }
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(modifier = Modifier.size(36.dp)) {
                                                    ProductArtworkView(product = prod)
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = prod.name,
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    DiagonalMetadataStrip(
                                                        items = listOf("RD$ ${prod.price}.00", prod.unit, prod.category),
                                                        slashColor = primaryColor,
                                                        fontSizeSp = 10.5f
                                                    )
                                                }
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .clip(CircleShape)
                                                    .border(1.5.dp, primaryColor, CircleShape)
                                                    .clickable {
                                                        HapticFeedbackManager.onAddToCart(view)
                                                        onAddSingleProduct(prod.sku)
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Add,
                                                    contentDescription = "Agregar ${prod.name}",
                                                    tint = primaryColor,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                val totalCombo = recommendedProducts.sumOf { it.price }
                                val cashbackCombo = totalCombo / 100

                                if (msg.orderConfirmed) {
                                    Surface(
                                        onClick = {
                                            HapticFeedbackManager.onConfirmAction(view)
                                            onConfirmOrderFromChat(msg.id)
                                        },
                                        shape = RoundedCornerShape(16.dp),
                                        color = Color(0xFF059669).copy(alpha = 0.14f),
                                        border = BorderStroke(1.4.dp, Color(0xFF059669)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("chat_order_confirmed_badge_${msg.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Pedido confirmado",
                                                    tint = Color(0xFF059669),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Column {
                                                    Text(
                                                        text = "Pedido Confirmado #${msg.confirmedOrderId ?: "ORD"}",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 13.sp,
                                                        color = Color(0xFF047857)
                                                    )
                                                    Text(
                                                        text = "Toca para ver seguimiento GPS en tiempo real",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.Medium,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "RD$ ${formatPesos(totalCombo)}",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 13.5.sp,
                                                color = Color(0xFF047857)
                                            )
                                        }
                                    }
                                } else if (msg.requiresOrderConfirmation) {
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color(0xFF059669).copy(alpha = 0.10f),
                                        border = BorderStroke(1.5.dp, Color(0xFF059669)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("manual_order_confirmation_card_${msg.id}")
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = "Confirmar Pedido",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 14.5.sp,
                                                    color = Color(0xFF047857)
                                                )
                                                BravoUnderline(isArca = isArca)
                                            }

                                            DiagonalMetadataStrip(
                                                items = listOf(
                                                    activeBranch,
                                                    "${recommendedProducts.size} artículos",
                                                    "ETA GPS ~$estimatedEtaMinutes min"
                                                ),
                                                slashColor = Color(0xFF059669),
                                                fontSizeSp = 10.5f
                                            )

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Total a autorizar (+RD$ $cashbackCombo Bravísima)",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "RD$ ${formatPesos(totalCombo)}.00",
                                                    fontFamily = PlusJakartaSans,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 16.sp,
                                                    color = Color(0xFF047857)
                                                )
                                            }

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedButton(
                                                    onClick = {
                                                        performCrispHaptic(view, HapticStyle.TICK)
                                                        onCancelOrderConfirmation(msg.id)
                                                    },
                                                    shape = RoundedCornerShape(999.dp),
                                                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                                                    modifier = Modifier
                                                        .weight(0.75f)
                                                        .testTag("cancel_chat_order_button_${msg.id}")
                                                ) {
                                                    Text(
                                                        text = "Cancelar",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }

                                                Button(
                                                    onClick = {
                                                        HapticFeedbackManager.onCheckoutConfirm(view)
                                                        onConfirmOrderFromChat(msg.id)
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = Color(0xFF059669),
                                                        contentColor = Color.White
                                                    ),
                                                    shape = RoundedCornerShape(999.dp),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                                    modifier = Modifier
                                                        .weight(1.45f)
                                                        .testTag("confirm_chat_order_button_${msg.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "Confirmar Pedido • RD$ ${formatPesos(totalCombo)}",
                                                        fontFamily = PlusJakartaSans,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 11.5.sp,
                                                        maxLines = 1
                                                    )
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                HapticFeedbackManager.onConfirmAction(view)
                                                onSaveBundleAsList(msg.id)
                                            },
                                            shape = RoundedCornerShape(999.dp),
                                            border = BorderStroke(1.3.dp, primaryColor),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                                            modifier = Modifier
                                                .weight(0.9f)
                                                .testTag("save_as_list_${msg.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.FormatListBulleted,
                                                contentDescription = null,
                                                tint = primaryColor,
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Guardar Lista",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                color = primaryColor,
                                                maxLines = 1
                                            )
                                        }

                                        AnimatedPurchaseButton(
                                            text = "Agregar (${recommendedProducts.size}) • RD$ ${formatPesos(totalCombo)}",
                                            icon = Icons.Default.ShoppingCart,
                                            primaryColor = primaryColor,
                                            onClick = {
                                                HapticFeedbackManager.onAddToCart(view)
                                                onAddBundleForMessage(msg.id)
                                            },
                                            modifier = Modifier.weight(1.3f),
                                            testTag = "add_all_recommended_${msg.id}"
                                        )
                                    }

                                    Surface(
                                        onClick = {
                                            HapticFeedbackManager.onConfirmAction(view)
                                            onRequestOrderConfirmation(msg.id)
                                        },
                                        shape = RoundedCornerShape(999.dp),
                                        color = Color(0xFF059669).copy(alpha = 0.12f),
                                        border = BorderStroke(1.2.dp, Color(0xFF059669)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("request_order_confirmation_button_${msg.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 9.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF059669),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Pedir ahora con Brav IA (RD$ ${formatPesos(totalCombo)})",
                                                fontFamily = PlusJakartaSans,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.5.sp,
                                                color = Color(0xFF047857),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .onSizeChanged { topOverlayHeightPx = it.height }
        ) {
            FloatingHeaderCapsule(darkMode = darkMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            HapticFeedbackManager.onNavigationClick(view)
                            onBack()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("bravia_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = primaryColor
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                    ) {
                        Text(
                            text = if (isArca) "Brav IA • El Arca & Soporte" else "Brav IA • Chef, Asesor & Soporte",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        BravoUnderline(isArca = isArca)
                        Text(
                            text = if (isGenerating) "Verificando web, presupuesto y visión..." else "Recetas Web • Visión Multimodal • RD$ $budgetAmount",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            color = primaryColor,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Surface(
                            onClick = {
                                HapticFeedbackManager.onAssistantTrigger(view)
                                if (!isLiveVoiceModeActive) {
                                    lastSpokenMessageId = messages.lastOrNull()?.id ?: -1L
                                    ttsEngine?.stop()
                                    isSpeakingTts = false
                                    isVoicePaused = false
                                    val hasPerm = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPerm) {
                                        isLiveVoiceModeActive = true
                                        startSpeechRecognition()
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                } else {
                                    stopAllVoiceOutputAndRecording()
                                    isVoicePaused = false
                                    isLiveVoiceModeActive = false
                                }
                            },
                            shape = RoundedCornerShape(999.dp),
                            color = if (isLiveVoiceModeActive) primaryColor else primaryColor.copy(alpha = 0.12f),
                            modifier = Modifier.testTag("bravia_voice_mode_toggle")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Conversación por voz",
                                    tint = if (isLiveVoiceModeActive) Color.White else primaryColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Voz",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.5.sp,
                                    color = if (isLiveVoiceModeActive) Color.White else primaryColor,
                                    maxLines = 1
                                )
                            }
                        }

                        Surface(
                            onClick = {
                                HapticFeedbackManager.onNavigationClick(view)
                                onOpenCart()
                            },
                            shape = RoundedCornerShape(999.dp),
                            color = primaryColor.copy(alpha = 0.12f),
                            modifier = Modifier.testTag("bravia_cart_pill")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "RD$${formatPesos(cartTotals.finalPay.roundToInt())}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.5.sp,
                                    color = primaryColor,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = isLiveVoiceModeActive,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                LiveVoiceConversationBanner(
                    primaryColor = primaryColor,
                    darkMode = darkMode,
                    isListening = isListeningMic,
                    isSpeaking = isSpeakingTts,
                    isPaused = isVoicePaused,
                    statusText = voiceStatusLabel,
                    onTogglePause = {
                        HapticFeedbackManager.onConfirmAction(view)
                        if (!isVoicePaused) {
                            isVoicePaused = true
                            stopAllVoiceOutputAndRecording()
                            voiceStatusLabel = "Modo voz en pausa • Toca Reanudar para continuar"
                        } else {
                            isVoicePaused = false
                            voiceStatusLabel = "Reanudando escucha..."
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                startSpeechRecognition()
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    onTapSpeakAgain = {
                        HapticFeedbackManager.onAssistantTrigger(view)
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) {
                            startSpeechRecognition()
                        } else {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onStopVoice = {
                        HapticFeedbackManager.onNavigationClick(view)
                        stopAllVoiceOutputAndRecording()
                        isVoicePaused = false
                        isLiveVoiceModeActive = false
                    },
                    onQuickVoicePrompt = { spokenPrompt ->
                        HapticFeedbackManager.onAssistantTrigger(view)
                        ttsEngine?.stop()
                        isSpeakingTts = false
                        isVoicePaused = false
                        voiceStatusLabel = "Consulta enviada: \"$spokenPrompt\""
                        onSendPrompt(spokenPrompt)
                    }
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .then(if (isImeVisible) Modifier else Modifier.navigationBarsPadding())
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    bottom = dynamicInputBottomPadding,
                    top = 4.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnimatedVisibility(
                visible = !pendingImageUri.isNullOrBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (!pendingImageUri.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                        border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 540.dp)
                            .testTag("bravia_pending_image_strip")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                ChatAttachedImagePreview(
                                    uriString = pendingImageUri,
                                    modifier = Modifier.size(44.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Imagen adjunta • Brav IA Soporte Multimodal",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.5.sp,
                                        color = primaryColor,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Lista para auditar producto dañado/vencido, factura NCF o alacena",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 10.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.TICK)
                                    onSelectImageUri(null)
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Quitar imagen adjunta",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            val canSendNow = inputText.trim().isNotEmpty() || !pendingImageUri.isNullOrBlank()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 540.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .translucentBackdropEffect(darkMode = darkMode, accentColor = ambientSoftPrimary)
                    .background(
                        if (hazeState != null) {
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    ambientSoftPrimary.copy(alpha = if (darkMode) 0.14f else 0.08f),
                                    Color.Transparent
                                )
                            )
                        } else {
                            Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                                    ambientSoftPrimary.copy(alpha = if (darkMode) 0.16f else 0.09f),
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                                )
                            )
                        }
                    )
                    .border(
                        width = 1.4.dp,
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                ambientSoftPrimary.copy(alpha = if (isGenerating) 0.65f else 0.38f),
                                ambientSoftSecondary.copy(alpha = if (isGenerating) 0.50f else 0.28f),
                                ambientSoftPrimary.copy(alpha = if (isGenerating) 0.65f else 0.38f)
                            )
                        ),
                        shape = RoundedCornerShape(999.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                IconButton(
                    onClick = {
                        HapticFeedbackManager.onAssistantTrigger(view)
                        lastSpokenMessageId = messages.lastOrNull()?.id ?: -1L
                        ttsEngine?.stop()
                        isSpeakingTts = false
                        isVoicePaused = false
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        isLiveVoiceModeActive = true
                        if (hasPerm) {
                            startSpeechRecognition()
                        } else {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .testTag("bravia_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Hablar por micrófono",
                        tint = if (isListeningMic) Color(0xFFE11D48) else primaryColor,
                        modifier = Modifier.size(19.dp)
                    )
                }

                IconButton(
                    onClick = {
                        HapticFeedbackManager.onAssistantTrigger(view)
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .testTag("bravia_attach_photo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Adjuntar foto de producto, factura NCF o alacena",
                        tint = if (!pendingImageUri.isNullOrBlank()) Color(0xFF059669) else primaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (inputText.isEmpty()) {
                        Text(
                            text = when {
                                !pendingImageUri.isNullOrBlank() -> "Describe tu foto o toca Enviar para auditar..."
                                isArca -> "Receta/dieta mascota, foto o sugerencia..."
                                else -> "Receta web, foto NCF/calidad o sugerencia..."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(primaryColor),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                val trimmed = inputText.trim()
                                if (canSendNow && !isGenerating) {
                                    HapticFeedbackManager.onAssistantTrigger(view)
                                    inputText = ""
                                    onSendPrompt(trimmed)
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bravia_input_field")
                    )
                }

                if (isGenerating) {
                    Surface(
                        onClick = {
                            performCrispHaptic(view, HapticStyle.CONFIRM)
                            stopAllVoiceOutputAndRecording()
                            onPauseGeneration()
                        },
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFFE31837),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("bravia_pause_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pausar respuesta de Brav IA",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "Pausar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                    }
                } else {
                    IconButton(
                        onClick = {
                            val trimmed = inputText.trim()
                            if (canSendNow) {
                                HapticFeedbackManager.onAssistantTrigger(view)
                                inputText = ""
                                onSendPrompt(trimmed)
                            }
                        },
                        enabled = canSendNow,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (canSendNow) primaryColor
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .testTag("bravia_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Enviar a Brav IA",
                            tint = Color.White,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun RecipeStepsVisualCard(
    steps: List<String>,
    primaryColor: Color,
    isSpeaking: Boolean = false,
    onSpeakSteps: () -> Unit,
    onPauseSpeech: () -> Unit = {}
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = primaryColor.copy(alpha = 0.08f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.RestaurantMenu,
                    contentDescription = null,
                    tint = primaryColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Guía de voz lista (${steps.size} pasos enumerados arriba)",
                    fontFamily = PlusJakartaSans,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isSpeaking) {
                    Surface(
                        onClick = onPauseSpeech,
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFFE31837).copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, Color(0xFFE31837))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pausar voz de pasos",
                                tint = Color(0xFFE31837),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Pausar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.5.sp,
                                color = Color(0xFFE31837),
                                maxLines = 1
                            )
                        }
                    }
                }
                Surface(
                    onClick = onSpeakSteps,
                    shape = RoundedCornerShape(999.dp),
                    color = primaryColor.copy(alpha = 0.14f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Narrar pasos",
                            tint = primaryColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Narrar Pasos",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.5.sp,
                            color = primaryColor,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveVoiceConversationBanner(
    primaryColor: Color,
    darkMode: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    isPaused: Boolean,
    statusText: String,
    onTogglePause: () -> Unit,
    onTapSpeakAgain: () -> Unit,
    onStopVoice: () -> Unit,
    onQuickVoicePrompt: (String) -> Unit
) {
    val hazeState = LocalTranslucentHazeState.current
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(520, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wavePhase"
    )

    val bannerShape = RoundedCornerShape(20.dp)
    Surface(
        shape = bannerShape,
        color = if (hazeState != null) primaryColor.copy(alpha = 0.06f) else primaryColor.copy(alpha = 0.10f),
        border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(bannerShape)
            .translucentBackdropEffect(darkMode = darkMode, accentColor = primaryColor)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.height(22.dp)
                    ) {
                        val factors = listOf(0.5f, 1f, 0.7f, 0.9f, 0.6f)
                        factors.forEach { f ->
                            val barHeight = if ((isListening || isSpeaking) && !isPaused) {
                                (20.dp * wavePhase * f).coerceAtLeast(6.dp)
                            } else {
                                7.dp
                            }
                            Box(
                                modifier = Modifier
                                    .width(3.5.dp)
                                    .height(barHeight)
                                    .clip(CircleShape)
                                    .background(if (isPaused) MaterialTheme.colorScheme.onSurfaceVariant else primaryColor)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isPaused) "Brav IA Live • En Pausa" else "Brav IA Live • Voz en Tiempo Real",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            color = primaryColor
                        )
                        Text(
                            text = statusText,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = onTogglePause,
                        shape = RoundedCornerShape(999.dp),
                        color = if (isPaused) BravoAmber else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.45f)),
                        modifier = Modifier.testTag("bravia_voice_pause_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = if (isPaused) "Reanudar voz" else "Pausar voz",
                                tint = if (isPaused) Color.White else primaryColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (isPaused) "Reanudar" else "Pausar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.5.sp,
                                color = if (isPaused) Color.White else primaryColor
                            )
                        }
                    }

                    Surface(
                        onClick = onTapSpeakAgain,
                        shape = RoundedCornerShape(999.dp),
                        color = primaryColor
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Hablar",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Hablar",
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.5.sp,
                                color = Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onStopVoice,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.StopCircle,
                            contentDescription = "Cerrar modo voz",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val voiceQuickPrompts = listOf(
                    "🎤 \"Dime los pasos para preparar Mangú\"" to "Dame los pasos exactos y al grano para preparar un Mangú con Los Tres Golpes.",
                    "🎤 \"¿Cómo preparo un Sancocho?\"" to "Explícame paso a paso y directo al grano cómo preparar un Sancocho Dominicano y qué ingredientes necesito.",
                    "🎤 \"Receta rápida con pollo\"" to "Dame los pasos concisos para preparar una receta rápida con pechuga de pollo y arroz Bravo."
                )
                voiceQuickPrompts.forEach { (chipTitle, fullPrompt) ->
                    Surface(
                        onClick = { onQuickVoicePrompt(fullPrompt) },
                        shape = RoundedCornerShape(999.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Text(
                            text = chipTitle,
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = primaryColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

private data class AccountTileItem(
    val subScreen: AccountSubScreen,
    val title: String,
    val icon: ImageVector
)

@Composable
fun AccountGridScreen(
    userProfile: UserProfile,
    activeBranch: String,
    bravisimaBalance: Int,
    cartCount: Int = 0,
    firestoreSyncStatus: String = "Sincronizado con tu cuenta de Google",
    isGuestMode: Boolean = false,
    cacheStatusLabel: String = "Catálogo oficial al día",
    darkMode: Boolean,
    onBack: () -> Unit = {},
    onOpenCart: () -> Unit = {},
    onSignOut: () -> Unit = {},
    onOpenSubScreen: (AccountSubScreen) -> Unit
) {
    val view = LocalView.current
    val primaryColor = MaterialTheme.colorScheme.primary

    val tileRows = remember {
        listOf(
            AccountTileItem(AccountSubScreen.PEDIDOS, "Mis pedidos", Icons.Outlined.LocalShipping),
            AccountTileItem(AccountSubScreen.PERFIL, "Mi perfil", Icons.Outlined.AccountCircle),
            AccountTileItem(AccountSubScreen.PAGOS, "Métodos de pago", Icons.Outlined.CreditCard),
            AccountTileItem(AccountSubScreen.DIRECCIONES, "Direcciones", Icons.Outlined.LocationOn),
            AccountTileItem(AccountSubScreen.LISTAS, "Mis listas", Icons.Outlined.FormatListBulleted),
            AccountTileItem(AccountSubScreen.AJUSTES, "Ajustes", Icons.Outlined.Settings),
            AccountTileItem(AccountSubScreen.SOPORTE, "Soporte", Icons.Outlined.ChatBubbleOutline),
            AccountTileItem(AccountSubScreen.AYUDA, "Ayuda", Icons.Outlined.HelpOutline)
        ).chunked(2)
    }

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("account_grid_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(
                items = tileRows,
                key = { pair -> pair.first().subScreen.key },
                contentType = { "account_tile_row" }
            ) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { tile ->
                        TranslucentCard(
                        darkMode = darkMode,
                        cornerRadius = 24.dp,
                        modifier = Modifier
                            .weight(1f)
                            .height(136.dp)
                            .testTag("account_tile_${tile.subScreen.key}"),
                        onClick = { onOpenSubScreen(tile.subScreen) }
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val wavePath = Path().apply {
                                    moveTo(0f, size.height * 0.45f)
                                    cubicTo(
                                        size.width * 0.35f, size.height * 0.25f,
                                        size.width * 0.65f, size.height * 0.72f,
                                        size.width, size.height * 0.50f
                                    )
                                }
                                drawPath(
                                    path = wavePath,
                                    color = if (darkMode) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0),
                                    style = Stroke(
                                        width = 3.5f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                    )
                                )
                            }

                            Icon(
                                imageVector = tile.icon,
                                contentDescription = tile.title,
                                tint = primaryColor,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 18.dp, end = 18.dp)
                                    .size(34.dp)
                            )

                            Text(
                                text = tile.title,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(start = 16.dp, bottom = 16.dp, end = 12.dp)
                            )
                        }
                    }
                }
            }
        }

        item(key = "firestore_account_sync_card", contentType = "firestore_sync") {
            TranslucentCard(
                darkMode = darkMode,
                cornerRadius = 22.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
                    .testTag("firestore_sync_account_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(primaryColor.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = "Cuenta de Google Sincronizada",
                                tint = primaryColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isGuestMode) "Modo Invitado • Sesión en Dispositivo" else userProfile.email,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (isGuestMode) "$cacheStatusLabel • Sin cuenta Google" else firestoreSyncStatus,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            HapticFeedbackManager.onNavigationClick(view)
                            onSignOut()
                        },
                        border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(999.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("account_sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = if (isGuestMode) "Conectar Google" else "Cerrar sesión",
                            tint = primaryColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isGuestMode) "Conectar Google" else "Salir",
                            fontFamily = PlusJakartaSans,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.5.sp,
                            color = primaryColor
                        )
                    }
                }
            }
        }
    }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        HapticFeedbackManager.onNavigationClick(view)
                        onBack()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        tint = primaryColor
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "Mi cuenta",
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = false)
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("account_cart_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable {
                                HapticFeedbackManager.onNavigationClick(view)
                                onOpenCart()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Carrito",
                            tint = primaryColor,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                    if (cartCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(17.dp)
                                .clip(CircleShape)
                                .background(primaryColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cartCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccountSubScreenView(
    subScreen: AccountSubScreen,
    userProfile: UserProfile,
    activeBranch: String,
    selectedPaletteId: String = "material_you",
    firestoreSyncStatus: String = "Sincronizado con tu cuenta de Google",
    isGuestMode: Boolean = false,
    isOfflineMode: Boolean = false,
    cacheStatusLabel: String = "Catálogo oficial al día",
    npuStatus: NpuHardwareStatus = NpuHardwareStatus(),
    onToggleNpuMode: () -> Unit = {},
    orders: List<OrderRecord>,
    paymentMethods: List<PaymentMethod>,
    addresses: List<UserAddress>,
    shoppingLists: List<ShoppingList>,
    aiPopulatingListId: String? = null,
    frequentStats: List<FrequentProductStat> = emptyList(),
    allProducts: List<Product> = emptyList(),
    productLookup: (String) -> Product? = { null },
    fcmToken: String = "",
    fcmTopics: List<FcmTopicSubscription> = emptyList(),
    pushFeed: List<PushNotificationRecord> = emptyList(),
    darkMode: Boolean,
    notificationsEnabled: Boolean,
    onBack: () -> Unit,
    onRepeatOrder: (String) -> Unit,
    onOpenLiveMap: () -> Unit,
    onOpenOrderTracking: (String) -> Unit = { onOpenLiveMap() },
    onSaveProfile: (String, String, String, String) -> Unit,
    onSelectPaymentMethod: (String) -> Unit,
    onAddPaymentCard: () -> Unit,
    onSelectAddress: (String) -> Unit,
    onLoadListToCart: (String) -> Unit,
    onCreateShoppingList: (name: String, autoPopulateWithAi: Boolean, focusHint: String) -> Unit = { _, _, _ -> },
    onDeleteShoppingList: (String) -> Unit = {},
    onRenameShoppingList: (String, String) -> Unit = { _, _ -> },
    onPopulateListWithAi: (String) -> Unit = {},
    onAddProductToList: (String, String) -> Unit = { _, _ -> },
    onRemoveProductFromList: (String, String) -> Unit = { _, _ -> },
    onAddSingleToCart: (String) -> Unit = {},
    onOpenProduct: (String) -> Unit = {},
    onToggleDarkMode: () -> Unit,
    onSelectPalette: (String) -> Unit = {},
    onToggleNotifications: () -> Unit,
    onToggleFcmTopic: (String, Boolean) -> Unit = { _, _ -> },
    onTriggerOfferPush: () -> Unit = {},
    onTriggerOrderPush: () -> Unit = {},
    onSelectPushNotification: (PushNotificationRecord) -> Unit = {},
    onMarkAllPushRead: () -> Unit = {},
    onRefreshLocalCache: () -> Unit = {},
    submittedSuggestions: List<SuggestionMailPayload> = emptyList(),
    onSubmitSupportSuggestion: (category: String, priority: String, subject: String, body: String) -> Unit = { _, _, _, _ -> },
    onOpenBravIaSupportPrompt: (String) -> Unit = {},
    onUpdateBranch: (String) -> Unit,
    onSignOut: () -> Unit = {},
    onShowToast: (String, String) -> Unit
) {
    val view = LocalView.current
    val primaryColor = MaterialTheme.colorScheme.primary
    var expandedListId by remember { mutableStateOf<String?>("l2") }
    var supportCategory by remember { mutableStateOf("SUGERENCIA_PRODUCTO") }
    var supportPriority by remember { mutableStateOf("ALTA") }
    var supportSubject by remember { mutableStateOf("") }
    var supportBody by remember { mutableStateOf("") }

    val hazeState = LocalTranslucentHazeState.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .testTag("account_subscreen_${subScreen.key}")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .translucentBackdropSource(hazeState, zIndex = 1f),
            contentPadding = PaddingValues(top = 74.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (subScreen) {
                AccountSubScreen.PEDIDOS -> {
                    item(key = "firestore_orders_sync_pill") {
                        TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(18.dp)
                            )
                            DiagonalMetadataStrip(
                                items = listOf("Cuenta Google", firestoreSyncStatus),
                                slashColor = primaryColor,
                                fontSizeSp = 11f
                            )
                        }
                    }
                }

                item(key = "live_order_banner") {
                    val topOrder = orders.firstOrNull()
                    val topStage = OrderDeliveryStage.fromStatusString(topOrder?.status)
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        onClick = {
                            if (topOrder != null) {
                                onOpenOrderTracking(topOrder.id)
                            } else {
                                onOpenLiveMap()
                            }
                        }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        BravoUnifiedIcon(
                                            iconKey = topStage.emoji,
                                            tint = Color(0xFF047857),
                                            size = 16.dp
                                        )
                                        Text(
                                            text = "Pedido #${topOrder?.id ?: "ORD-88412"} • ${topStage.statusText}",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF047857)
                                        )
                                    }
                                    DiagonalMetadataStrip(
                                        items = listOf(
                                            topOrder?.branch ?: "Av. Winston Churchill",
                                            "Avance ${topStage.progressPct}%",
                                            "Seguimiento en vivo"
                                        ),
                                        slashColor = primaryColor,
                                        fontSizeSp = 11f
                                    )
                                }
                                Text(
                                    text = "Ver progreso",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }

                            LinearProgressIndicator(
                                progress = { topStage.progressFraction },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(999.dp)),
                                color = if (topStage == OrderDeliveryStage.DELIVERED) {
                                    Color(0xFF059669)
                                } else {
                                    primaryColor
                                },
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }

                items(items = orders, key = { it.id }) { order ->
                    val orderStage = OrderDeliveryStage.fromStatusString(order.status)
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Orden ${order.id}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (orderStage == OrderDeliveryStage.DELIVERED) {
                                        Color(0xFFECFDF5)
                                    } else {
                                        primaryColor.copy(alpha = 0.12f)
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        val badgeTint = if (orderStage == OrderDeliveryStage.DELIVERED) {
                                            Color(0xFF047857)
                                        } else {
                                            primaryColor
                                        }
                                        BravoUnifiedIcon(
                                            iconKey = orderStage.emoji,
                                            tint = badgeTint,
                                            size = 13.dp
                                        )
                                        Text(
                                            text = "${orderStage.statusText} • ${orderStage.progressPct}%",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = badgeTint
                                        )
                                    }
                                }
                            }
                            DiagonalMetadataStrip(
                                items = listOf(order.date, order.branch, "${order.badgeNum} artículos"),
                                slashColor = primaryColor,
                                fontSizeSp = 11f
                            )
                            LinearProgressIndicator(
                                progress = { orderStage.progressFraction },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(999.dp)),
                                color = if (orderStage == OrderDeliveryStage.DELIVERED) {
                                    Color(0xFF059669)
                                } else {
                                    primaryColor
                                },
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "RD$ ${formatPesos(order.total.roundToInt())}.00",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp,
                                    color = primaryColor
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { onOpenOrderTracking(order.id) },
                                        border = BorderStroke(1.2.dp, primaryColor),
                                        shape = RoundedCornerShape(999.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier
                                            .height(34.dp)
                                            .testTag("track_order_button_${order.id}")
                                    ) {
                                        Text(
                                            text = "Seguir envío",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = primaryColor
                                        )
                                    }
                                    AnimatedPurchaseButton(
                                        text = "Repetir",
                                        icon = null,
                                        primaryColor = primaryColor,
                                        onClick = { onRepeatOrder(order.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            AccountSubScreen.PERFIL -> {
                item(key = "profile_form") {
                    var name by remember(userProfile) { mutableStateOf(userProfile.name) }
                    var phone by remember(userProfile) { mutableStateOf(userProfile.phone) }
                    var rncNit by remember(userProfile) { mutableStateOf(userProfile.rncNit) }
                    var ncfType by remember(userProfile) { mutableStateOf(userProfile.ncfType) }

                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("Nombre completo") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Teléfono móvil (RD)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = rncNit,
                                onValueChange = { rncNit = it },
                                label = { Text("Cédula / RNC") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = ncfType,
                                onValueChange = { ncfType = it },
                                label = { Text("Tipo de Comprobante Fiscal (NCF)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            AnimatedPurchaseButton(
                                text = "Guardar Cambios",
                                icon = null,
                                primaryColor = primaryColor,
                                onClick = { onSaveProfile(name, phone, rncNit, ncfType) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedButton(
                                onClick = {
                                    HapticFeedbackManager.onNavigationClick(view)
                                    onSignOut()
                                },
                                border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.65f)),
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("profile_sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Logout,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isGuestMode) {
                                        "Iniciar sesión con Google (Salir de Modo Invitado)"
                                    } else {
                                        "Cerrar sesión de Google (${userProfile.email})"
                                    },
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            AccountSubScreen.PAGOS -> {
                items(items = paymentMethods, key = { it.id }) { method ->
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        onClick = { onSelectPaymentMethod(method.id) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${method.brand} ${method.bank} •••• ${method.last4}",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                DiagonalMetadataStrip(
                                    items = listOf("Vence ${method.exp}", if (method.isDefault) "Predeterminada" else "Secundaria"),
                                    slashColor = primaryColor,
                                    fontSizeSp = 11f
                                )
                            }
                            if (method.isDefault) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Predeterminada",
                                    tint = Color(0xFF059669)
                                )
                            }
                        }
                    }
                }

                item(key = "add_card_btn") {
                    AnimatedPurchaseButton(
                        text = "+ Vincular Nueva Tarjeta Bancaria",
                        icon = null,
                        primaryColor = primaryColor,
                        onClick = onAddPaymentCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    )
                }
            }

            AccountSubScreen.DIRECCIONES -> {
                items(items = addresses, key = { it.id }) { addr ->
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        onClick = { onSelectAddress(addr.id) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = addr.label,
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                DiagonalMetadataStrip(
                                    items = listOf(addr.street, addr.branch),
                                    slashColor = primaryColor,
                                    fontSizeSp = 11f
                                )
                            }
                            if (addr.isDefault) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Activa",
                                    tint = Color(0xFF059669)
                                )
                            }
                        }
                    }
                }
            }

            AccountSubScreen.LISTAS -> {
                item(key = "bravia_history_hero", contentType = "ai_history_hero") {
                    BravIaHistoryAutoListHeroCard(
                        ordersCount = orders.size,
                        frequentStats = frequentStats,
                        isPopulatingAny = aiPopulatingListId != null,
                        darkMode = darkMode,
                        primaryColor = primaryColor,
                        onCreateAiPresetList = { title, focusHint ->
                            onCreateShoppingList(title, true, focusHint)
                        }
                    )
                }

                item(key = "create_shopping_list_form", contentType = "create_list_form") {
                    CreateShoppingListFormCard(
                        darkMode = darkMode,
                        primaryColor = primaryColor,
                        isPopulatingAny = aiPopulatingListId != null,
                        onCreateList = { name, autoPopulate ->
                            onCreateShoppingList(name, autoPopulate, name)
                        }
                    )
                }

                items(
                    items = shoppingLists,
                    key = { it.id },
                    contentType = { "managed_shopping_list" }
                ) { list ->
                    ManagedShoppingListCard(
                        shoppingList = list,
                        isExpanded = expandedListId == list.id || aiPopulatingListId == list.id,
                        isPopulatingThisList = aiPopulatingListId == list.id,
                        allProducts = allProducts,
                        frequentStats = frequentStats,
                        productLookup = productLookup,
                        darkMode = darkMode,
                        primaryColor = primaryColor,
                        onToggleExpand = {
                            expandedListId = if (expandedListId == list.id) null else list.id
                        },
                        onLoadListToCart = { onLoadListToCart(list.id) },
                        onPopulateWithAi = {
                            expandedListId = list.id
                            onPopulateListWithAi(list.id)
                        },
                        onRenameList = { newName -> onRenameShoppingList(list.id, newName) },
                        onDeleteList = { onDeleteShoppingList(list.id) },
                        onAddProductToList = { sku -> onAddProductToList(list.id, sku) },
                        onRemoveProductFromList = { sku -> onRemoveProductFromList(list.id, sku) },
                        onAddSingleToCart = { sku -> onAddSingleToCart(sku) },
                        onOpenProduct = { sku -> onOpenProduct(sku) }
                    )
                }
            }

            AccountSubScreen.AJUSTES -> {
                val branches = listOf(
                    "Bravo Winston Churchill",
                    "Bravo Enriquillo",
                    "Bravo Núñez de Cáceres",
                    "Bravo Los Próceres",
                    "Bravo San Isidro",
                    "Bravo Santiago"
                )

                item(key = "settings_toggles") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DarkMode,
                                        contentDescription = null,
                                        tint = primaryColor
                                    )
                                    Column {
                                        Text(
                                            text = "Modo oscuro",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp
                                        )
                                        DiagonalMetadataStrip(
                                            items = listOf("Guardado local", if (darkMode) "Activo" else "Inactivo"),
                                            slashColor = primaryColor,
                                            fontSizeSp = 10.5f
                                        )
                                    }
                                }
                                Switch(
                                    checked = darkMode,
                                    onCheckedChange = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onToggleDarkMode()
                                    },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = primaryColor),
                                    modifier = Modifier.testTag("dark_mode_switch")
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = null,
                                        tint = primaryColor
                                    )
                                    Column {
                                        Text(
                                            text = "Alertas de Ofertas y Delivery",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = "Notificaciones de tu pedido en tiempo real",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = notificationsEnabled,
                                    onCheckedChange = {
                                        performCrispHaptic(view, HapticStyle.TICK)
                                        onToggleNotifications()
                                    },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = primaryColor)
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudDone,
                                        contentDescription = null,
                                        tint = primaryColor
                                    )
                                    Column {
                                        Text(
                                            text = "Catálogo de Productos y Modo Sin Conexión",
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.5.sp
                                        )
                                        DiagonalMetadataStrip(
                                            items = listOf(
                                                if (isOfflineMode) "Modo sin conexión activo" else "Sincronizado en el dispositivo",
                                                cacheStatusLabel
                                            ),
                                            slashColor = primaryColor,
                                            fontSizeSp = 10.5f
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onRefreshLocalCache()
                                    },
                                    border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                    shape = RoundedCornerShape(999.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("refresh_local_cache_button")
                                ) {
                                    Text(
                                        text = "Sincronizar",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.sp,
                                        color = primaryColor
                                    )
                                }
                            }
                        }
                    }
                }

                item(key = "fcm_push_controls_and_feed", contentType = "fcm_push_section") {
                    FcmPushControlAndFeedCard(
                        fcmToken = fcmToken,
                        fcmTopics = fcmTopics,
                        pushFeed = pushFeed,
                        darkMode = darkMode,
                        primaryColor = primaryColor,
                        onToggleTopic = onToggleFcmTopic,
                        onTriggerOfferPush = onTriggerOfferPush,
                        onTriggerOrderPush = onTriggerOrderPush,
                        onSelectNotification = onSelectPushNotification,
                        onMarkAllRead = onMarkAllPushRead
                    )
                }

                item(key = "settings_device_dynamic_colors") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .testTag("device_dynamic_color_card")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(primaryColor.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Palette,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(21.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Color Automático del Dispositivo",
                                        fontFamily = PlusJakartaSans,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 15.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Sincronizado con el color elegido en los ajustes de tu Android (Material You) con contraste y legibilidad garantizados.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Activo",
                                tint = primaryColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                item(key = "settings_branches") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Sucursal Preferida",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                                BravoUnderline(isArca = false)
                            }
                            branches.forEach { branch ->
                                val selected = activeBranch == branch
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (selected) primaryColor.copy(alpha = 0.1f)
                                            else Color.Transparent
                                        )
                                        .clickable {
                                            performCrispHaptic(view, HapticStyle.TICK)
                                            onUpdateBranch(branch)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = branch,
                                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                                        color = if (selected) primaryColor else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (selected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = primaryColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AccountSubScreen.SOPORTE -> {
                item(key = "support_multimodal_ai_card") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Brav IA Soporte • Visión Multimodal y Calidad",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.5.sp,
                                    textAlign = TextAlign.Center
                                )
                                BravoUnderline(isArca = false)
                            }
                            Text(
                                text = "Adjunta fotos directamente en Brav IA para auditoría técnica instantánea en $activeBranch:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onOpenBravIaSupportPrompt("Tengo un producto dañado o vencido en mi orden de $activeBranch y deseo reposición sin costo o nota de crédito en mi Tarjeta Bravísima.")
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "1. Reportar Producto Dañado / Vencido (Foto)",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onOpenBravIaSupportPrompt("Quiero auditar mediante OCR una foto de mi factura o ticket NCF (B01/B02) para verificar ITBIS (18%/16%), descuentos y puntos Bravísima.")
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "2. Auditar Factura o Ticket NCF (OCR)",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    performCrispHaptic(view, HapticStyle.CONFIRM)
                                    onOpenBravIaSupportPrompt("Voy a subir una foto de un ingrediente de mi alacena o etiqueta de mascota para buscar su equivalente exacto en el catálogo Bravo o El Arca.")
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.2.dp, primaryColor.copy(alpha = 0.55f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "3. Identificar Alacena o Etiqueta de Mascota",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = primaryColor
                                )
                            }
                        }
                    }
                }

                item(key = "support_suggestion_mailbox_card") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .testTag("support_suggestion_mailbox_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Buzón de Sugerencias y Mejora Continua",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.5.sp,
                                    textAlign = TextAlign.Center
                                )
                                BravoUnderline(isArca = false)
                            }
                            DiagonalMetadataStrip(
                                items = listOf("Destino: bezaleelpatrocino0@gmail.com", activeBranch),
                                slashColor = primaryColor,
                                fontSizeSp = 10.5f
                            )

                            val categories = listOf(
                                "SUGERENCIA_PRODUCTO" to "Producto",
                                "MEJORA_UI_UX" to "Mejora App",
                                "REPORTE_SOPORTE" to "Soporte",
                                "FELICITACION" to "Felicitación"
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                categories.forEach { (code, label) ->
                                    val selected = supportCategory == code
                                    Surface(
                                        onClick = {
                                            performCrispHaptic(view, HapticStyle.TICK)
                                            supportCategory = code
                                        },
                                        shape = RoundedCornerShape(999.dp),
                                        color = if (selected) primaryColor else primaryColor.copy(alpha = 0.10f),
                                        border = BorderStroke(1.dp, primaryColor)
                                    ) {
                                        Text(
                                            text = label,
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = if (selected) Color.White else primaryColor,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            val priorities = listOf("ALTA", "MEDIA", "BAJA")
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Prioridad:",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                priorities.forEach { prio ->
                                    val selected = supportPriority == prio
                                    Surface(
                                        onClick = {
                                            performCrispHaptic(view, HapticStyle.TICK)
                                            supportPriority = prio
                                        },
                                        shape = RoundedCornerShape(999.dp),
                                        color = if (selected) Color(0xFF059669) else Color(0xFF059669).copy(alpha = 0.10f)
                                    ) {
                                        Text(
                                            text = prio,
                                            fontFamily = PlusJakartaSans,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 10.5.sp,
                                            color = if (selected) Color.White else Color(0xFF047857),
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = supportSubject,
                                onValueChange = { supportSubject = it },
                                label = { Text("Asunto ejecutivo (opcional)") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("support_suggestion_subject_input")
                            )

                            OutlinedTextField(
                                value = supportBody,
                                onValueChange = { supportBody = it },
                                label = { Text("Escribe tu sugerencia, producto deseado o reporte...") },
                                minLines = 3,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("support_suggestion_body_input")
                            )

                            AnimatedPurchaseButton(
                                text = "Enviar a bezaleelpatrocino0@gmail.com",
                                icon = Icons.Default.Email,
                                primaryColor = primaryColor,
                                onClick = {
                                    if (supportBody.trim().isNotEmpty()) {
                                        performCrispHaptic(view, HapticStyle.CONFIRM)
                                        onSubmitSupportSuggestion(
                                            supportCategory,
                                            supportPriority,
                                            supportSubject.trim(),
                                            supportBody.trim()
                                        )
                                        supportSubject = ""
                                        supportBody = ""
                                    } else {
                                        onShowToast("info", "Escribe el detalle de tu sugerencia antes de enviar")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "support_send_suggestion_button"
                            )
                        }
                    }
                }

                if (submittedSuggestions.isNotEmpty()) {
                    items(
                        items = submittedSuggestions,
                        key = { it.timestampIso + it.subject }
                    ) { payload ->
                        Box(modifier = Modifier.padding(horizontal = 14.dp)) {
                            SuggestionMailDispatchedCard(
                                payload = payload,
                                primaryColor = primaryColor
                            )
                        }
                    }
                }

                item(key = "support_card") {
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Centro de Atención al Cliente Bravo",
                                    fontFamily = PlusJakartaSans,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                                BravoUnderline(isArca = false)
                            }
                            Text(
                                text = "Horario de atención: Lunes a Sábado de 7:00 AM a 10:00 PM (Domingos cerrados por valores familiares). Delivery express en 8–12 minutos en el polígono central.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { onShowToast("💬", "Conectando con WhatsApp Bravo (809-540-2728)...") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Chatear por WhatsApp", fontWeight = FontWeight.ExtraBold)
                            }
                            AnimatedPurchaseButton(
                                text = "Llamar al (809) 540-2728",
                                icon = null,
                                primaryColor = primaryColor,
                                onClick = { onShowToast("📞", "Marcando a Servicio al Cliente (809-540-2728)...") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            AccountSubScreen.AYUDA -> {
                val faqs = listOf(
                    "¿Cómo funciona el 1% de la Tarjeta Bravísima?" to "Retorno exacto del 1% (RD$ 1.00 por cada RD$ 100.00 de compra), canje directo en carrito o caja presentando el código de barras ${userProfile.bravisimaNumber}.",
                    "¿Cuáles son los horarios y tiempos de entrega?" to "Lunes a Sábado de 7:00 AM a 10:00 PM (Domingos cerrados por valores familiares). Delivery express en 8-12 minutos en el polígono central.",
                    "¿Cómo funciona la Facturación Fiscal (NCF)?" to "Emitimos Comprobantes B01 (Crédito Fiscal para empresas/RNC) y B02 (Consumidor Final) con desglose exacto de ITBIS (18%/16%).",
                    "¿Qué hace Brav IA y Brav IA Soporte?" to "Brav IA verifica recetas en vivo en la web con medidas exactas, cumple matemáticamente tu presupuesto en RD$, audita fotos de productos/facturas NCF y envía sugerencias a bezaleelpatrocino0@gmail.com."
                )
                items(items = faqs, key = { it.first }) { (q, a) ->
                    TranslucentCard(
                        darkMode = darkMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = q,
                                fontFamily = PlusJakartaSans,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = a,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

        FloatingHeaderCapsule(
            darkMode = darkMode,
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = {
                        HapticFeedbackManager.onNavigationClick(view)
                        onBack()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("account_sub_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver a Mi Cuenta",
                        tint = primaryColor
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = subScreen.title,
                        fontFamily = PlusJakartaSans,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    BravoUnderline(isArca = false)
                }

                Spacer(modifier = Modifier.size(36.dp))
            }
        }
    }
}
